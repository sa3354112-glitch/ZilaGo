import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/theme/app_theme.dart';
import 'core/routes/app_routes.dart';
import 'viewmodels/splash_viewmodel.dart';
import 'viewmodels/onboarding_viewmodel.dart';
import 'viewmodels/auth_viewmodel.dart';

/// ZilaGo Main Entry - Phase 2 Complete Auth Flow
/// Clean Architecture + MVVM + Provider
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // TODO: await Firebase.initializeApp() after flutterfire configure
  runApp(const ZilaGoApp());
}

class ZilaGoApp extends StatelessWidget {
  const ZilaGoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SplashViewModel()),
        ChangeNotifierProvider(create: (_) => OnboardingViewModel()),
        ChangeNotifierProvider(create: (_) => AuthViewModel()),
      ],
      child: MaterialApp(
        title: 'ZilaGo - Apni Zila, Apni Sawari',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.darkTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.dark,
        initialRoute: AppRoutes.splash,
        routes: AppRoutes.routes,
      ),
    );
  }
}
