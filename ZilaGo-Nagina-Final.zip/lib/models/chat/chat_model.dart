
import 'package:cloud_firestore/cloud_firestore.dart';

class ChatMessageModel {
  final String id;
  final String rideId;
  final String senderId;
  final String senderType; // customer, driver
  final String message;
  final String type; // text, location
  final DateTime createdAt;
  final bool isRead;
  ChatMessageModel({required this.id, required this.rideId, required this.senderId, required this.senderType, required this.message, required this.type, required this.createdAt, required this.isRead});
  Map<String, dynamic> toJson() => {'id': id, 'rideId': rideId, 'senderId': senderId, 'senderType': senderType, 'message': message, 'type': type, 'createdAt': Timestamp.fromDate(createdAt), 'isRead': isRead};
  factory ChatMessageModel.fromFirestore(doc) { final d=doc.data() as Map<String,dynamic>; return ChatMessageModel(id: doc.id, rideId: d['rideId'], senderId: d['senderId'], senderType: d['senderType'], message: d['message'], type: d['type'], createdAt: (d['createdAt'] as Timestamp).toDate(), isRead: d['isRead'] ?? false); }
}
