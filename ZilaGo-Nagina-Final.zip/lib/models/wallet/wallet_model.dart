
import 'package:cloud_firestore/cloud_firestore.dart';

class WalletModel {
  final String userId;
  final double balance;
  final double totalEarned;
  final double totalSpent;
  final DateTime updatedAt;
  WalletModel({required this.userId, required this.balance, required this.totalEarned, required this.totalSpent, required this.updatedAt});
  Map<String, dynamic> toJson() => {'userId': userId, 'balance': balance, 'totalEarned': totalEarned, 'totalSpent': totalSpent, 'updatedAt': Timestamp.fromDate(updatedAt)};
  factory WalletModel.fromJson(Map<String, dynamic> json) => WalletModel(userId: json['userId'], balance: (json['balance'] as num).toDouble(), totalEarned: (json['totalEarned'] as num? ?? 0).toDouble(), totalSpent: (json['totalSpent'] as num? ?? 0).toDouble(), updatedAt: (json['updatedAt'] as Timestamp).toDate());
}

class WalletTx {
  final String id; final String userId; final double amount; final String type; final String reason; final DateTime createdAt;
  WalletTx({required this.id, required this.userId, required this.amount, required this.type, required this.reason, required this.createdAt});
  factory WalletTx.fromFirestore(doc) { final d=doc.data() as Map<String,dynamic>; return WalletTx(id: doc.id, userId: d['userId'], amount: (d['amount'] as num).toDouble(), type: d['type'], reason: d['reason'], createdAt: (d['createdAt'] as Timestamp).toDate());}
}
