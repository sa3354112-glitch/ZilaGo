/// Onboarding Model
class OnboardingModel {
  final String title;
  final String description;
  final String image; // asset or icon name
  final List<ColorHex> gradientColors; // for UI

  OnboardingModel({
    required this.title,
    required this.description,
    required this.image,
    required this.gradientColors,
  });
}

// Simple placeholder for gradient
class ColorHex {
  final int value;
  const ColorHex(this.value);
}
