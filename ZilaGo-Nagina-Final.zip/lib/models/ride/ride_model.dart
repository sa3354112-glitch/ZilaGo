import 'package:cloud_firestore/cloud_firestore.dart';
import 'ride_category_model.dart';
import 'place_model.dart';
import '../../core/constants/map_constants.dart';

enum RideStatus { searching, accepted, arriving, started, completed, cancelled }

class DriverModel {
  final String id;
  final String name;
  final String phone;
  final String photoUrl;
  final double rating;
  final int totalRides;
  final String vehicleNumber;
  final String vehicleModel;
  final RideCategoryType vehicleType;
  final double lat;
  final double lng;
  final bool isOnline;

  DriverModel({
    required this.id,
    required this.name,
    required this.phone,
    required this.photoUrl,
    required this.rating,
    required this.totalRides,
    required this.vehicleNumber,
    required this.vehicleModel,
    required this.vehicleType,
    required this.lat,
    required this.lng,
    this.isOnline = true,
  });

  factory DriverModel.mock(int index, RideCategoryType type) {
    return DriverModel(
      id: 'driver_$index',
      name: ['Ramesh Kumar', 'Salim Ahmed', 'Pappu Singh', 'Irfan Ali', 'Suresh Yadav'][index % 5],
      phone: '98765${10000 + index}',
      photoUrl: '',
      rating: 4.2 + (index % 8) * 0.1,
      totalRides: 150 + index * 12,
      vehicleNumber: 'UP21 ${['AB', 'CD', 'EF'][index % 3]} ${1000 + index}',
      vehicleModel: type == RideCategoryType.bike ? 'Bajaj Pulsar' : type == RideCategoryType.auto ? 'Bajaj Auto' : 'Maruti Swift',
      vehicleType: type,
      lat: 29.4457 + (index * 0.001 - 0.002),
      lng: 78.4425 + (index * 0.001 - 0.002),
    );
  }
}

class RideModel {
  final String id;
  final String userId;
  final PlaceModel pickup;
  final PlaceModel destination;
  final RideCategoryModel category;
  final RideStatus status;
  final double distanceKm;
  final double durationMin;
  final double fare;
  final DriverModel? driver;
  final DateTime createdAt;
  final DateTime? acceptedAt;
  final DateTime? completedAt;
  final String? cancelReason;

  RideModel({
    required this.id,
    required this.userId,
    required this.pickup,
    required this.destination,
    required this.category,
    required this.status,
    required this.distanceKm,
    required this.durationMin,
    required this.fare,
    this.driver,
    required this.createdAt,
    this.acceptedAt,
    this.completedAt,
    this.cancelReason,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'userId': userId,
        'pickup': pickup.toJson(),
        'destination': destination.toJson(),
        'category': category.type.name,
        'status': status.name,
        'distanceKm': distanceKm,
        'durationMin': durationMin,
        'fare': fare,
        'driverId': driver?.id,
        'createdAt': Timestamp.fromDate(createdAt),
        'acceptedAt': acceptedAt != null ? Timestamp.fromDate(acceptedAt!) : null,
        'completedAt': completedAt != null ? Timestamp.fromDate(completedAt!) : null,
        'cancelReason': cancelReason,
      };

  RideModel copyWith({RideStatus? status, DriverModel? driver, DateTime? acceptedAt, DateTime? completedAt, String? cancelReason}) {
    return RideModel(
      id: id,
      userId: userId,
      pickup: pickup,
      destination: destination,
      category: category,
      status: status ?? this.status,
      distanceKm: distanceKm,
      durationMin: durationMin,
      fare: fare,
      driver: driver ?? this.driver,
      createdAt: createdAt,
      acceptedAt: acceptedAt ?? this.acceptedAt,
      completedAt: completedAt ?? this.completedAt,
      cancelReason: cancelReason ?? this.cancelReason,
    );
  }
}
