import 'package:cloud_firestore/cloud_firestore.dart';
import '../core/constants/map_constants.dart';

/// Place Model - Pickup & Destination
class PlaceModel {
  final String id;
  final String name;
  final String address;
  final double lat;
  final double lng;
  final String? placeType; // home, work, other
  final bool isFavorite;

  PlaceModel({
    required this.id,
    required this.name,
    required this.address,
    required this.lat,
    required this.lng,
    this.placeType,
    this.isFavorite = false,
  });

  factory PlaceModel.fromNaginaLocality(Map<String, dynamic> data) {
    return PlaceModel(
      id: data['name'].toString().toLowerCase().replaceAll(' ', '_'),
      name: data['name'],
      address: '${data['name']}, Nagina, Bijnor, UP',
      lat: data['lat'],
      lng: data['lng'],
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'address': address,
        'lat': lat,
        'lng': lng,
        'placeType': placeType,
        'isFavorite': isFavorite,
      };

  factory PlaceModel.fromJson(Map<String, dynamic> json) => PlaceModel(
        id: json['id'],
        name: json['name'],
        address: json['address'],
        lat: (json['lat'] as num).toDouble(),
        lng: (json['lng'] as num).toDouble(),
        placeType: json['placeType'],
        isFavorite: json['isFavorite'] ?? false,
      );

  // For Google Maps LatLng
  double get latitude => lat;
  double get longitude => lng;
}

/// Favorite Place Model
class FavoritePlaceModel extends PlaceModel {
  FavoritePlaceModel({
    required super.id,
    required super.name,
    required super.address,
    required super.lat,
    required super.lng,
    required String placeType,
  }) : super(placeType: placeType, isFavorite: true);
}
