import 'package:cloud_firestore/cloud_firestore.dart';
import '../core/constants/map_constants.dart';

/// Ride Category Model
class RideCategoryModel {
  final RideCategoryType type;
  final String name;
  final String icon;
  final String desc;
  final String capacity;
  final double baseFare;
  final double perKm;
  final double perMin;
  final String eta;
  final bool isSelected;

  RideCategoryModel({
    required this.type,
    required this.name,
    required this.icon,
    required this.desc,
    required this.capacity,
    required this.baseFare,
    required this.perKm,
    required this.perMin,
    required this.eta,
    this.isSelected = false,
  });

  factory RideCategoryModel.fromType(RideCategoryType type, {bool selected = false}) {
    final data = RideCategoryConstants.categories[type]!;
    return RideCategoryModel(
      type: type,
      name: data['name'],
      icon: data['icon'],
      desc: data['desc'],
      capacity: data['capacity'],
      baseFare: data['baseFare'],
      perKm: data['perKm'],
      perMin: data['perMin'],
      eta: data['eta'],
      isSelected: selected,
    );
  }

  double calculateFare(double distanceKm, double durationMin) {
    return baseFare + (perKm * distanceKm) + (perMin * durationMin);
  }

  RideCategoryModel copyWith({bool? isSelected}) => RideCategoryModel(
        type: type,
        name: name,
        icon: icon,
        desc: desc,
        capacity: capacity,
        baseFare: baseFare,
        perKm: perKm,
        perMin: perMin,
        eta: eta,
        isSelected: isSelected ?? this.isSelected,
      );
}
