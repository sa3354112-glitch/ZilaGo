/// Base Model Structure - For Clean Architecture
/// Phase 1: Placeholder for future models
class BaseModel {
  final String id;
  final DateTime createdAt;

  BaseModel({
    required this.id,
    required this.createdAt,
  });
}

/// User Model - Scaffold for Phase 2
class UserModel extends BaseModel {
  final String name;
  final String phone;
  final String? email;

  UserModel({
    required super.id,
    required super.createdAt,
    required this.name,
    required this.phone,
    this.email,
  });

  // TODO Phase 2: fromJson / toJson for Firestore
}
