import 'package:cloud_firestore/cloud_firestore.dart';

enum AdminRole { superAdmin, cityAdmin, support, finance }

class AdminUserModel {
  final String id;
  final String email;
  final String name;
  final AdminRole role;
  final List<String> assignedCities;
  final bool isActive;
  final DateTime createdAt;
  final DateTime lastLoginAt;

  AdminUserModel({required this.id, required this.email, required this.name, required this.role, required this.assignedCities, required this.isActive, required this.createdAt, required this.lastLoginAt});

  Map<String, dynamic> toJson() => {'id': id, 'email': email, 'name': name, 'role': role.name, 'assignedCities': assignedCities, 'isActive': isActive, 'createdAt': Timestamp.fromDate(createdAt), 'lastLoginAt': Timestamp.fromDate(lastLoginAt)};

  factory AdminUserModel.fromJson(Map<String, dynamic> json) => AdminUserModel(id: json['id'], email: json['email'], name: json['name'], role: AdminRole.values.firstWhere((e) => e.name == json['role']), assignedCities: List<String>.from(json['assignedCities'] ?? []), isActive: json['isActive'] ?? true, createdAt: (json['createdAt'] as Timestamp).toDate(), lastLoginAt: (json['lastLoginAt'] as Timestamp).toDate());
}

class DashboardStatsModel {
  final int totalCustomers;
  final int totalDrivers;
  final int onlineDrivers;
  final int activeRides;
  final int todayRides;
  final double todayEarnings;
  final double totalEarnings;
  final double commissionEarned;
  final int pendingKyc;
  final int openTickets;

  DashboardStatsModel({required this.totalCustomers, required this.totalDrivers, required this.onlineDrivers, required this.activeRides, required this.todayRides, required this.todayEarnings, required this.totalEarnings, required this.commissionEarned, required this.pendingKyc, required this.openTickets});

  factory DashboardStatsModel.fromMap(Map<String, dynamic> map) => DashboardStatsModel(totalCustomers: map['totalCustomers'] ?? 0, totalDrivers: map['totalDrivers'] ?? 0, onlineDrivers: map['onlineDrivers'] ?? 0, activeRides: map['activeRides'] ?? 0, todayRides: map['todayRides'] ?? 0, todayEarnings: (map['todayEarnings'] as num?)?.toDouble() ?? 0, totalEarnings: (map['totalEarnings'] as num?)?.toDouble() ?? 0, commissionEarned: (map['commissionEarned'] as num?)?.toDouble() ?? 0, pendingKyc: map['pendingKyc'] ?? 0, openTickets: map['openTickets'] ?? 0);
}

class CouponModel {
  final String id;
  final String code;
  final String description;
  final double discountPercent;
  final double maxDiscount;
  final double minFare;
  final int totalUses;
  final int usedCount;
  final DateTime expiryDate;
  final bool isActive;
  final List<String> applicableCities;
  final DateTime createdAt;

  CouponModel({required this.id, required this.code, required this.description, required this.discountPercent, required this.maxDiscount, required this.minFare, required this.totalUses, required this.usedCount, required this.expiryDate, required this.isActive, required this.applicableCities, required this.createdAt});

  Map<String, dynamic> toJson() => {'id': id, 'code': code, 'description': description, 'discountPercent': discountPercent, 'maxDiscount': maxDiscount, 'minFare': minFare, 'totalUses': totalUses, 'usedCount': usedCount, 'expiryDate': Timestamp.fromDate(expiryDate), 'isActive': isActive, 'applicableCities': applicableCities, 'createdAt': Timestamp.fromDate(createdAt)};

  factory CouponModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return CouponModel(id: doc.id, code: data['code'], description: data['description'], discountPercent: (data['discountPercent'] as num).toDouble(), maxDiscount: (data['maxDiscount'] as num).toDouble(), minFare: (data['minFare'] as num).toDouble(), totalUses: data['totalUses'], usedCount: data['usedCount'], expiryDate: (data['expiryDate'] as Timestamp).toDate(), isActive: data['isActive'], applicableCities: List<String>.from(data['applicableCities'] ?? []), createdAt: (data['createdAt'] as Timestamp).toDate());
  }
}

class WalletTransactionModel {
  final String id;
  final String userId;
  final String userType;
  final double amount;
  final String type; // credit, debit
  final String reason; // ride, referral, incentive, withdrawal
  final String? rideId;
  final DateTime createdAt;

  WalletTransactionModel({required this.id, required this.userId, required this.userType, required this.amount, required this.type, required this.reason, this.rideId, required this.createdAt});

  factory WalletTransactionModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return WalletTransactionModel(id: doc.id, userId: data['userId'], userType: data['userType'], amount: (data['amount'] as num).toDouble(), type: data['type'], reason: data['reason'], rideId: data['rideId'], createdAt: (data['createdAt'] as Timestamp).toDate());
  }
}

class FareRuleModel {
  final String id;
  final String cityId;
  final String vehicleType;
  final double baseFare;
  final double perKm;
  final double perMin;
  final double minFare;
  final double commissionPercent;
  final Map<String, dynamic> peakHours; // {"18-21": 1.5}
  final bool isActive;
  final DateTime updatedAt;

  FareRuleModel({required this.id, required this.cityId, required this.vehicleType, required this.baseFare, required this.perKm, required this.perMin, required this.minFare, required this.commissionPercent, required this.peakHours, required this.isActive, required this.updatedAt});

  Map<String, dynamic> toJson() => {'id': id, 'cityId': cityId, 'vehicleType': vehicleType, 'baseFare': baseFare, 'perKm': perKm, 'perMin': perMin, 'minFare': minFare, 'commissionPercent': commissionPercent, 'peakHours': peakHours, 'isActive': isActive, 'updatedAt': Timestamp.fromDate(updatedAt)};

  factory FareRuleModel.fromFirestore(DocumentSnapshot doc) {
    final d = doc.data() as Map<String, dynamic>;
    return FareRuleModel(id: doc.id, cityId: d['cityId'], vehicleType: d['vehicleType'], baseFare: (d['baseFare'] as num).toDouble(), perKm: (d['perKm'] as num).toDouble(), perMin: (d['perMin'] as num).toDouble(), minFare: (d['minFare'] as num).toDouble(), commissionPercent: (d['commissionPercent'] as num).toDouble(), peakHours: Map<String, dynamic>.from(d['peakHours'] ?? {}), isActive: d['isActive'], updatedAt: (d['updatedAt'] as Timestamp).toDate());
  }

  double calculateFare(double distance, double duration, DateTime now) {
    double fare = baseFare + (perKm * distance) + (perMin * duration);
    int hour = now.hour;
    for (var entry in peakHours.entries) {
      final parts = entry.key.split('-');
      if (parts.length == 2) {
        int start = int.parse(parts[0]);
        int end = int.parse(parts[1]);
        if (hour >= start && hour < end) {
          fare *= (entry.value as num).toDouble();
          break;
        }
      }
    }
    return fare < minFare ? minFare : fare;
  }
}

class SupportTicketModel {
  final String id;
  final String userId;
  final String userType;
  final String subject;
  final String description;
  final String status; // open, in_progress, resolved, closed
  final String priority; // low, medium, high
  final String? assignedTo;
  final DateTime createdAt;
  final DateTime updatedAt;

  SupportTicketModel({required this.id, required this.userId, required this.userType, required this.subject, required this.description, required this.status, required this.priority, this.assignedTo, required this.createdAt, required this.updatedAt});

  factory SupportTicketModel.fromFirestore(DocumentSnapshot doc) {
    final d = doc.data() as Map<String, dynamic>;
    return SupportTicketModel(id: doc.id, userId: d['userId'], userType: d['userType'], subject: d['subject'], description: d['description'], status: d['status'], priority: d['priority'], assignedTo: d['assignedTo'], createdAt: (d['createdAt'] as Timestamp).toDate(), updatedAt: (d['updatedAt'] as Timestamp).toDate());
  }
}

class CityModel {
  final String id;
  final String name;
  final String state;
  final double lat;
  final double lng;
  final double radiusKm;
  final bool isActive;
  final double commissionPercent;
  final DateTime createdAt;

  CityModel({required this.id, required this.name, required this.state, required this.lat, required this.lng, required this.radiusKm, required this.isActive, required this.commissionPercent, required this.createdAt});

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'state': state, 'lat': lat, 'lng': lng, 'radiusKm': radiusKm, 'isActive': isActive, 'commissionPercent': commissionPercent, 'createdAt': Timestamp.fromDate(createdAt)};

  factory CityModel.fromFirestore(DocumentSnapshot doc) {
    final d = doc.data() as Map<String, dynamic>;
    return CityModel(id: doc.id, name: d['name'], state: d['state'], lat: (d['lat'] as num).toDouble(), lng: (d['lng'] as num).toDouble(), radiusKm: (d['radiusKm'] as num).toDouble(), isActive: d['isActive'], commissionPercent: (d['commissionPercent'] as num).toDouble(), createdAt: (d['createdAt'] as Timestamp).toDate());
  }
}

class ReferralModel {
  final String id;
  final String referrerId;
  final String referredId;
  final String status;
  final double referrerReward;
  final double referredReward;
  final DateTime createdAt;
  final DateTime? completedAt;

  ReferralModel({required this.id, required this.referrerId, required this.referredId, required this.status, required this.referrerReward, required this.referredReward, required this.createdAt, this.completedAt});
}
