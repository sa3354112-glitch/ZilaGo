import 'package:cloud_firestore/cloud_firestore.dart';

enum KycStatus { pending, underReview, approved, rejected }
enum KycDocumentType { aadhaar, license, rc, insurance, profilePhoto }

class KycDocumentModel {
  final KycDocumentType type;
  final String documentNumber;
  final String frontImageUrl;
  final String? backImageUrl;
  final KycStatus status;
  final String? rejectionReason;
  final DateTime uploadedAt;
  final DateTime? verifiedAt;

  KycDocumentModel({
    required this.type,
    required this.documentNumber,
    required this.frontImageUrl,
    this.backImageUrl,
    this.status = KycStatus.pending,
    this.rejectionReason,
    required this.uploadedAt,
    this.verifiedAt,
  });

  Map<String, dynamic> toJson() => {
        'type': type.name,
        'documentNumber': documentNumber,
        'frontImageUrl': frontImageUrl,
        'backImageUrl': backImageUrl,
        'status': status.name,
        'rejectionReason': rejectionReason,
        'uploadedAt': Timestamp.fromDate(uploadedAt),
        'verifiedAt': verifiedAt != null ? Timestamp.fromDate(verifiedAt!) : null,
      };

  factory KycDocumentModel.fromJson(Map<String, dynamic> json) => KycDocumentModel(
        type: KycDocumentType.values.firstWhere((e) => e.name == json['type']),
        documentNumber: json['documentNumber'],
        frontImageUrl: json['frontImageUrl'],
        backImageUrl: json['backImageUrl'],
        status: KycStatus.values.firstWhere((e) => e.name == json['status'], orElse: () => KycStatus.pending),
        rejectionReason: json['rejectionReason'],
        uploadedAt: (json['uploadedAt'] as Timestamp).toDate(),
        verifiedAt: json['verifiedAt'] != null ? (json['verifiedAt'] as Timestamp).toDate() : null,
      );
}

class DriverKycModel {
  final String driverId;
  final KycDocumentModel? aadhaar;
  final KycDocumentModel? license;
  final KycDocumentModel? rc;
  final KycDocumentModel? insurance;
  final String? profilePhotoUrl;
  final KycStatus overallStatus;
  final double completionPercentage;

  DriverKycModel({
    required this.driverId,
    this.aadhaar,
    this.license,
    this.rc,
    this.insurance,
    this.profilePhotoUrl,
    this.overallStatus = KycStatus.pending,
    this.completionPercentage = 0,
  });

  Map<String, dynamic> toJson() => {
        'driverId': driverId,
        'aadhaar': aadhaar?.toJson(),
        'license': license?.toJson(),
        'rc': rc?.toJson(),
        'insurance': insurance?.toJson(),
        'profilePhotoUrl': profilePhotoUrl,
        'overallStatus': overallStatus.name,
        'completionPercentage': completionPercentage,
      };

  bool get isComplete => aadhaar != null && license != null && rc != null && insurance != null && profilePhotoUrl != null;
  bool get isApproved => overallStatus == KycStatus.approved;
}
