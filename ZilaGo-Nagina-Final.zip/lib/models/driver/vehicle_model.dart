import 'package:cloud_firestore/cloud_firestore.dart';
import '../../core/constants/map_constants.dart';

enum VehicleType { bike, auto, eRickshaw, cab, xl }

class VehicleModel {
  final String id;
  final String driverId;
  final VehicleType type;
  final String vehicleNumber;
  final String modelName;
  final String color;
  final int year;
  final int seatingCapacity;
  final String rcNumber;
  final String insuranceNumber;
  final DateTime insuranceExpiry;
  final DateTime rcExpiry;
  final bool isActive;
  final bool isVerified;
  final List<String> imageUrls;
  final DateTime createdAt;

  VehicleModel({
    required this.id,
    required this.driverId,
    required this.type,
    required this.vehicleNumber,
    required this.modelName,
    required this.color,
    required this.year,
    required this.seatingCapacity,
    required this.rcNumber,
    required this.insuranceNumber,
    required this.insuranceExpiry,
    required this.rcExpiry,
    this.isActive = true,
    this.isVerified = false,
    this.imageUrls = const [],
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'driverId': driverId,
        'type': type.name,
        'vehicleNumber': vehicleNumber,
        'modelName': modelName,
        'color': color,
        'year': year,
        'seatingCapacity': seatingCapacity,
        'rcNumber': rcNumber,
        'insuranceNumber': insuranceNumber,
        'insuranceExpiry': Timestamp.fromDate(insuranceExpiry),
        'rcExpiry': Timestamp.fromDate(rcExpiry),
        'isActive': isActive,
        'isVerified': isVerified,
        'imageUrls': imageUrls,
        'createdAt': Timestamp.fromDate(createdAt),
      };

  factory VehicleModel.fromJson(Map<String, dynamic> json) => VehicleModel(
        id: json['id'],
        driverId: json['driverId'],
        type: VehicleType.values.firstWhere((e) => e.name == json['type']),
        vehicleNumber: json['vehicleNumber'],
        modelName: json['modelName'],
        color: json['color'],
        year: json['year'],
        seatingCapacity: json['seatingCapacity'],
        rcNumber: json['rcNumber'],
        insuranceNumber: json['insuranceNumber'],
        insuranceExpiry: (json['insuranceExpiry'] as Timestamp).toDate(),
        rcExpiry: (json['rcExpiry'] as Timestamp).toDate(),
        isActive: json['isActive'] ?? true,
        isVerified: json['isVerified'] ?? false,
        imageUrls: List<String>.from(json['imageUrls'] ?? []),
        createdAt: (json['createdAt'] as Timestamp).toDate(),
      );

  RideCategoryType get toRideCategory {
    switch (type) {
      case VehicleType.bike:
        return RideCategoryType.bike;
      case VehicleType.auto:
        return RideCategoryType.auto;
      case VehicleType.eRickshaw:
        return RideCategoryType.miniMetro;
      case VehicleType.cab:
        return RideCategoryType.cab;
      case VehicleType.xl:
        return RideCategoryType.xl;
    }
  }
}
