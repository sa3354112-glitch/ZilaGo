import 'package:cloud_firestore/cloud_firestore.dart';
import '../ride/place_model.dart';
import '../ride/ride_category_model.dart';
import 'vehicle_model.dart';

enum DriverRideStatus { requested, accepted, arrived, started, completed, cancelledByDriver, cancelledByUser }

class DriverRideRequestModel {
  final String id;
  final String userId;
  final String userName;
  final String userPhone;
  final String? userPhotoUrl;
  final PlaceModel pickup;
  final PlaceModel destination;
  final RideCategoryModel category;
  final double distanceKm;
  final double durationMin;
  final double fare;
  final double? userRating;
  final DriverRideStatus status;
  final DateTime requestedAt;
  final DateTime? acceptedAt;
  final DateTime? arrivedAt;
  final DateTime? startedAt;
  final DateTime? completedAt;
  final String? driverId;

  DriverRideRequestModel({
    required this.id,
    required this.userId,
    required this.userName,
    required this.userPhone,
    this.userPhotoUrl,
    required this.pickup,
    required this.destination,
    required this.category,
    required this.distanceKm,
    required this.durationMin,
    required this.fare,
    this.userRating,
    required this.status,
    required this.requestedAt,
    this.acceptedAt,
    this.arrivedAt,
    this.startedAt,
    this.completedAt,
    this.driverId,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'userId': userId,
        'userName': userName,
        'userPhone': userPhone,
        'userPhotoUrl': userPhotoUrl,
        'pickup': pickup.toJson(),
        'destination': destination.toJson(),
        'category': category.type.name,
        'distanceKm': distanceKm,
        'durationMin': durationMin,
        'fare': fare,
        'userRating': userRating,
        'status': status.name,
        'requestedAt': Timestamp.fromDate(requestedAt),
        'acceptedAt': acceptedAt != null ? Timestamp.fromDate(acceptedAt!) : null,
        'arrivedAt': arrivedAt != null ? Timestamp.fromDate(arrivedAt!) : null,
        'startedAt': startedAt != null ? Timestamp.fromDate(startedAt!) : null,
        'completedAt': completedAt != null ? Timestamp.fromDate(completedAt!) : null,
        'driverId': driverId,
      };

  factory DriverRideRequestModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return DriverRideRequestModel(
      id: doc.id,
      userId: data['userId'],
      userName: data['userName'],
      userPhone: data['userPhone'],
      userPhotoUrl: data['userPhotoUrl'],
      pickup: PlaceModel.fromJson(data['pickup']),
      destination: PlaceModel.fromJson(data['destination']),
      category: RideCategoryModel.fromType(RideCategoryType.values.firstWhere((e) => e.name == data['category'])),
      distanceKm: (data['distanceKm'] as num).toDouble(),
      durationMin: (data['durationMin'] as num).toDouble(),
      fare: (data['fare'] as num).toDouble(),
      userRating: (data['userRating'] as num?)?.toDouble(),
      status: DriverRideStatus.values.firstWhere((e) => e.name == data['status']),
      requestedAt: (data['requestedAt'] as Timestamp).toDate(),
      acceptedAt: data['acceptedAt'] != null ? (data['acceptedAt'] as Timestamp).toDate() : null,
      arrivedAt: data['arrivedAt'] != null ? (data['arrivedAt'] as Timestamp).toDate() : null,
      startedAt: data['startedAt'] != null ? (data['startedAt'] as Timestamp).toDate() : null,
      completedAt: data['completedAt'] != null ? (data['completedAt'] as Timestamp).toDate() : null,
      driverId: data['driverId'],
    );
  }
}

class EarningsModel {
  final String driverId;
  final double todayEarnings;
  final double weeklyEarnings;
  final double monthlyEarnings;
  final double totalEarnings;
  final int todayRides;
  final int totalRides;
  final double balance;
  final DateTime lastUpdated;

  EarningsModel({
    required this.driverId,
    required this.todayEarnings,
    required this.weeklyEarnings,
    required this.monthlyEarnings,
    required this.totalEarnings,
    required this.todayRides,
    required this.totalRides,
    required this.balance,
    required this.lastUpdated,
  });

  Map<String, dynamic> toJson() => {
        'driverId': driverId,
        'todayEarnings': todayEarnings,
        'weeklyEarnings': weeklyEarnings,
        'monthlyEarnings': monthlyEarnings,
        'totalEarnings': totalEarnings,
        'todayRides': todayRides,
        'totalRides': totalRides,
        'balance': balance,
        'lastUpdated': Timestamp.fromDate(lastUpdated),
      };

  factory EarningsModel.fromJson(Map<String, dynamic> json) => EarningsModel(
        driverId: json['driverId'],
        todayEarnings: (json['todayEarnings'] as num).toDouble(),
        weeklyEarnings: (json['weeklyEarnings'] as num).toDouble(),
        monthlyEarnings: (json['monthlyEarnings'] as num).toDouble(),
        totalEarnings: (json['totalEarnings'] as num).toDouble(),
        todayRides: json['todayRides'],
        totalRides: json['totalRides'],
        balance: (json['balance'] as num).toDouble(),
        lastUpdated: (json['lastUpdated'] as Timestamp).toDate(),
      );
}

class RatingModel {
  final String id;
  final String driverId;
  final String userId;
  final String userName;
  final double rating;
  final String? review;
  final DateTime createdAt;

  RatingModel({required this.id, required this.driverId, required this.userId, required this.userName, required this.rating, this.review, required this.createdAt});

  factory RatingModel.fromJson(Map<String, dynamic> json) => RatingModel(
        id: json['id'],
        driverId: json['driverId'],
        userId: json['userId'],
        userName: json['userName'],
        rating: (json['rating'] as num).toDouble(),
        review: json['review'],
        createdAt: (json['createdAt'] as Timestamp).toDate(),
      );
}
