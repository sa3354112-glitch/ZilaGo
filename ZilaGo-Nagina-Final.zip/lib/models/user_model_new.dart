import 'package:cloud_firestore/cloud_firestore.dart';

/// User Model - Firestore Ready
enum UserType { customer, driver }

class UserModel {
  final String uid;
  final String name;
  final String phone;
  final String? email;
  final UserType userType;
  final String? photoUrl;
  final bool isProfileComplete;
  final DateTime createdAt;
  final DateTime? updatedAt;

  // Driver specific
  final String? vehicleNumber;
  final String? licenseNumber;
  final String? area;

  UserModel({
    required this.uid,
    required this.name,
    required this.phone,
    this.email,
    required this.userType,
    this.photoUrl,
    this.isProfileComplete = false,
    required this.createdAt,
    this.updatedAt,
    this.vehicleNumber,
    this.licenseNumber,
    this.area,
  });

  Map<String, dynamic> toJson() => {
        'uid': uid,
        'name': name,
        'phone': phone,
        'email': email,
        'userType': userType.name,
        'photoUrl': photoUrl,
        'isProfileComplete': isProfileComplete,
        'createdAt': Timestamp.fromDate(createdAt),
        'updatedAt': updatedAt != null ? Timestamp.fromDate(updatedAt!) : null,
        'vehicleNumber': vehicleNumber,
        'licenseNumber': licenseNumber,
        'area': area,
      };

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        uid: json['uid'],
        name: json['name'],
        phone: json['phone'],
        email: json['email'],
        userType: UserType.values.firstWhere((e) => e.name == json['userType'], orElse: () => UserType.customer),
        photoUrl: json['photoUrl'],
        isProfileComplete: json['isProfileComplete'] ?? false,
        createdAt: (json['createdAt'] as Timestamp).toDate(),
        updatedAt: json['updatedAt'] != null ? (json['updatedAt'] as Timestamp).toDate() : null,
        vehicleNumber: json['vehicleNumber'],
        licenseNumber: json['licenseNumber'],
        area: json['area'],
      );

  UserModel copyWith({
    String? name,
    String? email,
    String? photoUrl,
    bool? isProfileComplete,
    String? vehicleNumber,
    String? licenseNumber,
    String? area,
  }) {
    return UserModel(
      uid: uid,
      name: name ?? this.name,
      phone: phone,
      email: email ?? this.email,
      userType: userType,
      photoUrl: photoUrl ?? this.photoUrl,
      isProfileComplete: isProfileComplete ?? this.isProfileComplete,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
      vehicleNumber: vehicleNumber ?? this.vehicleNumber,
      licenseNumber: licenseNumber ?? this.licenseNumber,
      area: area ?? this.area,
    );
  }
}
