/// ZilaGo Core Constants - Production Config
class AppConstants {
  AppConstants._();

  static const String appName = 'ZilaGo';
  static const String tagline = 'Apni Zila, Apni Sawari';
  static const String taglineEnglish = 'Your District, Your Ride';

  static const Duration splashDuration = Duration(seconds: 3);
  static const Duration animationDuration = Duration(milliseconds: 800);

  // Location
  static const String primaryCity = 'Nagina';
  static const String district = 'Bijnor';
  static const String state = 'Uttar Pradesh';

  // Firebase Collections
  static const String usersCollection = 'users';
  static const String driversCollection = 'drivers';
  static const String ridesCollection = 'rides';
  static const String otpCollection = 'otps';

  // Storage Keys
  static const String keyOnboardingSeen = 'onboarding_seen';
  static const String keyUserType = 'user_type';
  static const String keyIsLoggedIn = 'is_logged_in';

  // Validation
  static const int phoneLength = 10;
  static const int otpLength = 6;
  static const int minPasswordLength = 6;
}

class AppStrings {
  AppStrings._();
  static const String onboarding1Title = 'Apni Zila Ki Sawari';
  static const String onboarding1Desc = 'Nagina, Bijnor ke liye bani local ride service. Fast, safe aur affordable.';
  static const String onboarding2Title = 'Local Drivers, Apne Log';
  static const String onboarding2Desc = 'Aapke sheher ke trusted drivers, jo har gali ko jaante hain.';
  static const String onboarding3Title = 'Ek Tap Par Ride';
  static const String onboarding3Desc = 'Auto, E-Rickshaw, Bike ya Cab - sab kuch ZilaGo par.';
}
