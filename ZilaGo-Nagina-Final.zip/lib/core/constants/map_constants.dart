import 'package:flutter/material.dart';

/// Map & Ride Constants - Phase 3
class MapConstants {
  MapConstants._();

  // Nagina center
  static const double naginaLat = 29.4457;
  static const double naginaLng = 78.4425;
  static const double defaultZoom = 14.5;
  static const double trackingZoom = 16.5;

  // Google Maps styling - Dark theme JSON (simplified, use in controller)
  static const String darkMapStyle = '''[
    {"elementType":"geometry","stylers":[{"color":"#242f3e"}]},
    {"elementType":"labels.text.stroke","stylers":[{"color":"#242f3e"}]},
    {"elementType":"labels.text.fill","stylers":[{"color":"#746855"}]}
  ]''';
}

/// Ride Categories - Premium
enum RideCategoryType { bike, auto, miniMetro, cab, xl }

class RideCategoryConstants {
  static const Map<RideCategoryType, Map<String, dynamic>> categories = {
    RideCategoryType.bike: {
      'name': 'Bike',
      'icon': '🏍️',
      'desc': 'Fast & affordable',
      'capacity': '1 rider',
      'baseFare': 15.0,
      'perKm': 8.0,
      'perMin': 1.0,
      'eta': '2 min',
    },
    RideCategoryType.auto: {
      'name': 'Auto',
      'icon': '🛺',
      'desc': 'Local Nagina favorite',
      'capacity': '3 riders',
      'baseFare': 30.0,
      'perKm': 12.0,
      'perMin': 1.5,
      'eta': '3 min',
    },
    RideCategoryType.miniMetro: {
      'name': 'Mini Metro',
      'icon': '🚐',
      'desc': 'E-Rickshaw',
      'capacity': '4 riders',
      'baseFare': 20.0,
      'perKm': 10.0,
      'perMin': 1.2,
      'eta': '4 min',
    },
    RideCategoryType.cab: {
      'name': 'Cab',
      'icon': '🚕',
      'desc': 'Comfortable ride',
      'capacity': '4 riders',
      'baseFare': 80.0,
      'perKm': 18.0,
      'perMin': 2.0,
      'eta': '5 min',
    },
    RideCategoryType.xl: {
      'name': 'XL',
      'icon': '🚙',
      'desc': 'Spacious for family',
      'capacity': '6 riders',
      'baseFare': 120.0,
      'perKm': 22.0,
      'perMin': 2.5,
      'eta': '6 min',
    },
  };
}

/// Nagina Localities for autocomplete
class NaginaPlaces {
  static const List<Map<String, dynamic>> localities = [
    {'name': 'Bus Stand, Nagina', 'lat': 29.444, 'lng': 78.440},
    {'name': 'Kotwali, Nagina', 'lat': 29.447, 'lng': 78.438},
    {'name': 'Puraini, Nagina', 'lat': 29.450, 'lng': 78.445},
    {'name': 'Laddawala, Nagina', 'lat': 29.442, 'lng': 78.442},
    {'name': 'Railway Station, Nagina', 'lat': 29.438, 'lng': 78.435},
    {'name': 'Dhampur Road, Nagina', 'lat': 29.452, 'lng': 78.450},
    {'name': 'Bijnor Road', 'lat': 29.460, 'lng': 78.460},
    {'name': 'Afzalgarh Road', 'lat': 29.430, 'lng': 78.430},
  ];

  static const List<Map<String, String>> favoriteTypes = [
    {'id': 'home', 'name': 'Home', 'icon': 'home'},
    {'id': 'work', 'name': 'Work', 'icon': 'work'},
    {'id': 'other', 'name': 'Other', 'icon': 'place'},
  ];
}
