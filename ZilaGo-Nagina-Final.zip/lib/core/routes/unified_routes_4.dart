import 'package:flutter/material.dart';
import '../views/splash/splash_view.dart';
import '../views/onboarding/onboarding_view.dart';
import '../views/auth/customer_login_view.dart';
import '../views/auth/driver_login_view.dart';
import '../views/auth/otp_view.dart';
import '../views/auth/email_login_view.dart';
import '../views/auth/forgot_password_view.dart';
import '../views/auth/profile_setup_view.dart';
import '../views/home/home_view.dart';
import '../views/home/customer/customer_home_view.dart';
import '../views/home/history/ride_history_view.dart';
import '../views/home/history/favorite_places_view.dart';
import '../views/driver/dashboard/driver_dashboard_view.dart';
import '../views/driver/kyc/driver_kyc_view.dart';
import '../views/driver/earnings/driver_earnings_view.dart';
import '../views/driver/ride/driver_history_view.dart';
import '../views/driver/profile/driver_profile_view.dart';
import '../views/admin/auth/admin_login_view.dart';
import '../views/admin/dashboard/admin_dashboard_view.dart';
import '../views/wallet/wallet_view.dart';
import '../views/chat/chat_view.dart';
import '../views/ratings/rating_view.dart';
import '../views/referral/referral_view.dart';
import '../views/settings/settings_view.dart';
import '../views/role_selector_view.dart';
import '../main_final.dart';

class UnifiedRoutes {
  UnifiedRoutes._();

  // Common
  static const String splash = '/';
  static const String onboarding = '/onboarding';
  static const String roleSelector = '/role-selector';

  // Customer
  static const String customerLogin = '/customer-login';
  static const String driverLogin = '/driver-login';
  static const String otp = '/otp';
  static const String emailLogin = '/email-login';
  static const String forgotPassword = '/forgot-password';
  static const String profileSetup = '/profile-setup';
  static const String home = '/home';
  static const String customerHome = '/customer-home';
  static const String rideHistory = '/ride-history';
  static const String favoritePlaces = '/favorite-places';
  static const String wallet = '/wallet';
  static const String chat = '/chat';
  static const String rating = '/rating';
  static const String referral = '/referral';
  static const String settings = '/settings';

  // Driver
  static const String driverDashboard = '/driver-dashboard';
  static const String driverKyc = '/driver-kyc';
  static const String driverEarnings = '/driver-earnings';
  static const String driverRideHistory = '/driver-ride-history';
  static const String driverProfile = '/driver-profile';

  // Admin
  static const String adminLogin = '/admin-login';
  static const String adminDashboard = '/admin-dashboard';

  static Map<String, WidgetBuilder> routes = {
    splash: (_) => const UnifiedSplashView(),
    onboarding: (_) => const OnboardingView(),
    roleSelector: (_) => const RoleSelectorView(),
    customerLogin: (_) => const CustomerLoginView(),
    driverLogin: (_) => const DriverLoginView(),
    otp: (_) => const OtpView(),
    emailLogin: (_) => const EmailLoginView(),
    forgotPassword: (_) => const ForgotPasswordView(),
    profileSetup: (_) => const ProfileSetupView(),
    home: (_) => const CustomerHomeView(),
    customerHome: (_) => const CustomerHomeView(),
    rideHistory: (_) => const RideHistoryView(),
    favoritePlaces: (_) => const FavoritePlacesView(),
    adminLogin: (_) => const AdminLoginView(),
    adminDashboard: (_) => const AdminDashboardView(),
    settings: (_) => const SettingsView(),
  };

  static Route<dynamic>? onGenerateRoute(RouteSettings settings) {
    final args = settings.arguments;
    final driverId = args is String ? args : 'driver_123';
    final mapArgs = args is Map ? args : {};

    switch (settings.name) {
      case driverDashboard:
        return MaterialPageRoute(builder: (_) => DriverDashboardView(driverId: driverId));
      case driverKyc:
        return MaterialPageRoute(builder: (_) => DriverKycView(driverId: driverId));
      case driverEarnings:
        return MaterialPageRoute(builder: (_) => DriverEarningsView(driverId: driverId));
      case driverRideHistory:
        return MaterialPageRoute(builder: (_) => DriverRideHistoryView(driverId: driverId));
      case driverProfile:
        return MaterialPageRoute(builder: (_) => DriverProfileView(driverId: driverId));
      case wallet:
        return MaterialPageRoute(builder: (_) => WalletView(userId: driverId));
      case chat:
        final rideId = mapArgs['rideId'] ?? 'ride_123';
        final senderId = mapArgs['senderId'] ?? driverId;
        final senderType = mapArgs['senderType'] ?? 'customer';
        return MaterialPageRoute(builder: (_) => ChatView(rideId: rideId, senderId: senderId, senderType: senderType));
      case rating:
        final rideId = mapArgs['rideId'] ?? 'ride_123';
        final dId = mapArgs['driverId'] ?? driverId;
        final uId = mapArgs['userId'] ?? 'user_123';
        final uName = mapArgs['userName'] ?? 'User';
        return MaterialPageRoute(builder: (_) => RatingView(rideId: rideId, driverId: dId, userId: uId, userName: uName));
      case referral:
        return MaterialPageRoute(builder: (_) => ReferralView(userId: driverId));
      default:
        return null;
    }
  }
}
