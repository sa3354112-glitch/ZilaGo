import 'package:flutter/material.dart';
import 'views/splash/splash_view.dart';
import 'views/onboarding/onboarding_view.dart';
import 'views/auth/customer_login_view.dart';
import 'views/auth/driver_login_view.dart';
import 'views/auth/otp_view.dart';
import 'views/auth/email_login_view.dart';
import 'views/auth/forgot_password_view.dart';
import 'views/auth/profile_setup_view.dart';
import 'views/home/home_view.dart';

class AppRoutes {
  AppRoutes._();

  static const String splash = '/';
  static const String onboarding = '/onboarding';
  static const String customerLogin = '/customer-login';
  static const String driverLogin = '/driver-login';
  static const String otp = '/otp';
  static const String emailLogin = '/email-login';
  static const String forgotPassword = '/forgot-password';
  static const String profileSetup = '/profile-setup';
  static const String home = '/home';

  static Map<String, WidgetBuilder> routes = {
    splash: (_) => const SplashView(),
    onboarding: (_) => const OnboardingView(),
    customerLogin: (_) => const CustomerLoginView(),
    driverLogin: (_) => const DriverLoginView(),
    otp: (_) => const OtpView(),
    emailLogin: (_) => const EmailLoginView(),
    forgotPassword: (_) => const ForgotPasswordView(),
    profileSetup: (_) => const ProfileSetupView(),
    home: (_) => const HomeView(),
  };
}
