import 'package:flutter/material.dart';
import '../../core/routes/app_routes.dart';

/// Updated App Routes - Phase 3 Added
/// Do not rewrite - extend existing routes
class AppRoutesPhase3 {
  static const String customerHome = '/customer-home';
  static const String search = '/customer-search';
  static const String rideHistory = '/ride-history';
  static const String favoritePlaces = '/favorite-places';
  static const String tripDetails = '/trip-details';
}
