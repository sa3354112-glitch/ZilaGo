import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/theme/app_theme.dart';
import 'core/routes/app_routes.dart';
import 'views/home/customer/customer_home_view.dart';
import 'views/home/history/ride_history_view.dart';
import 'views/home/history/favorite_places_view.dart';
import 'viewmodels/splash_viewmodel.dart';
import 'viewmodels/onboarding_viewmodel.dart';
import 'viewmodels/auth_viewmodel.dart';
import 'viewmodels/home/customer_home_viewmodel.dart';
import 'views/splash/splash_view.dart';
import 'views/onboarding/onboarding_view.dart';
import 'views/auth/customer_login_view.dart';
import 'views/auth/driver_login_view.dart';
import 'views/auth/otp_view.dart';
import 'views/auth/email_login_view.dart';
import 'views/auth/forgot_password_view.dart';
import 'views/auth/profile_setup_view.dart';
import 'views/home/home_view.dart';

/// ZilaGo Main - Phase 3 Customer Home Module Complete
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ZilaGoAppPhase3());
}

class ZilaGoAppPhase3 extends StatelessWidget {
  const ZilaGoAppPhase3({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SplashViewModel()),
        ChangeNotifierProvider(create: (_) => OnboardingViewModel()),
        ChangeNotifierProvider(create: (_) => AuthViewModel()),
        ChangeNotifierProvider(create: (_) => CustomerHomeViewModel()),
      ],
      child: MaterialApp(
        title: 'ZilaGo - Apni Zila, Apni Sawari',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.darkTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.dark,
        initialRoute: AppRoutes.splash,
        routes: {
          ...AppRoutes.routes,
          '/customer-home': (_) => const CustomerHomeView(),
          '/ride-history': (_) => const RideHistoryView(),
          '/favorite-places': (_) => const FavoritePlacesView(),
          // Override home to customer home for Phase 3
          '/home': (_) => const CustomerHomeView(),
        },
      ),
    );
  }
}
