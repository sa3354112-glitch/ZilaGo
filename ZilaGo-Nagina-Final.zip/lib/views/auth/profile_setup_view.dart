import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../widgets/primary_button.dart';
import '../../widgets/custom_text_field.dart';
import '../../viewmodels/auth_viewmodel.dart';
import '../../models/user_model_new.dart';
import '../../utils/validators.dart';
import '../../utils/helpers.dart';

/// Profile Setup - After Auth, before Home
class ProfileSetupView extends StatefulWidget {
  const ProfileSetupView({super.key});

  @override
  State<ProfileSetupView> createState() => _ProfileSetupViewState();
}

class _ProfileSetupViewState extends State<ProfileSetupView> {
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _vehicleCtrl = TextEditingController();
  final _licenseCtrl = TextEditingController();
  final _areaCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    final user = context.read<AuthViewModel>().currentUser;
    if (user != null) {
      _nameCtrl.text = user.name;
      _emailCtrl.text = user.email ?? '';
      _vehicleCtrl.text = user.vehicleNumber ?? '';
      _licenseCtrl.text = user.licenseNumber ?? '';
      _areaCtrl.text = user.area ?? '';
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _vehicleCtrl.dispose();
    _licenseCtrl.dispose();
    _areaCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authVM = context.watch<AuthViewModel>();
    final isDriver = authVM.selectedUserType == UserType.driver;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text('Setup Profile', style: AppTextStyles.h3)),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(isDriver ? 'Driver Profile Setup' : 'Complete Your Profile', style: AppTextStyles.h1),
                const SizedBox(height: 8),
                Text(isDriver ? 'Add vehicle details to start earning' : 'Tell us about yourself', style: AppTextStyles.body),
                const SizedBox(height: 32),
                Center(
                  child: Stack(
                    children: [
                      Container(
                        width: 100,
                        height: 100,
                        decoration: BoxDecoration(color: AppColors.surface, shape: BoxShape.circle, border: Border.all(color: AppColors.border)),
                        child: const Icon(Icons.person_rounded, size: 50, color: AppColors.textTertiary),
                      ),
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: const BoxDecoration(color: AppColors.primaryOrange, shape: BoxShape.circle),
                          child: const Icon(Icons.camera_alt_rounded, size: 16, color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 32),
                CustomTextField(controller: _nameCtrl, label: 'Full Name *', hint: 'Enter your name', prefixIcon: Icons.person_rounded, validator: AppValidators.validateName),
                const SizedBox(height: 16),
                CustomTextField(controller: _emailCtrl, label: 'Email (Optional)', hint: 'you@example.com', prefixIcon: Icons.email_rounded, keyboardType: TextInputType.emailAddress),
                const SizedBox(height: 16),
                if (isDriver) ...[
                  CustomTextField(controller: _vehicleCtrl, label: 'Vehicle Number *', hint: 'UP21 AB 1234', prefixIcon: Icons.directions_car_rounded, validator: (v) => v == null || v.isEmpty ? 'Required' : null),
                  const SizedBox(height: 16),
                  CustomTextField(controller: _licenseCtrl, label: 'License Number *', hint: 'DL1234567890', prefixIcon: Icons.card_membership_rounded, validator: (v) => v == null || v.isEmpty ? 'Required' : null),
                  const SizedBox(height: 16),
                  CustomTextField(controller: _areaCtrl, label: 'Operating Area', hint: 'Nagina, Kotwali, etc', prefixIcon: Icons.location_on_rounded),
                  const SizedBox(height: 16),
                ],
                const SizedBox(height: 24),
                PrimaryButton(
                  text: 'Complete Profile & Continue',
                  isLoading: authVM.isLoading,
                  onPressed: () async {
                    if (!_formKey.currentState!.validate()) return;
                    final success = await authVM.completeProfile(
                      name: _nameCtrl.text.trim(),
                      email: _emailCtrl.text.trim().isEmpty ? null : _emailCtrl.text.trim(),
                      vehicleNo: _vehicleCtrl.text.trim().isEmpty ? null : _vehicleCtrl.text.trim(),
                      license: _licenseCtrl.text.trim().isEmpty ? null : _licenseCtrl.text.trim(),
                      area: _areaCtrl.text.trim().isEmpty ? null : _areaCtrl.text.trim(),
                    );
                    if (success && context.mounted) {
                      AppHelpers.showSuccessSnackBar(context, 'Profile completed!');
                      Navigator.pushReplacementNamed(context, '/home');
                    } else if (context.mounted) {
                      AppHelpers.showErrorSnackBar(context, authVM.errorMessage ?? 'Failed to save profile');
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
