import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../widgets/primary_button.dart';
import '../../widgets/custom_text_field.dart';
import '../../viewmodels/auth_viewmodel.dart';
import '../../utils/validators.dart';
import '../../utils/helpers.dart';

/// Email Login - Firebase Email Auth
class EmailLoginView extends StatefulWidget {
  const EmailLoginView({super.key});

  @override
  State<EmailLoginView> createState() => _EmailLoginViewState();
}

class _EmailLoginViewState extends State<EmailLoginView> {
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _obscure = true;
  bool _isSignUp = false;
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passCtrl.dispose();
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authVM = context.watch<AuthViewModel>();
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pop(context)), title: Text(_isSignUp ? 'Create Account' : 'Email Login', style: AppTextStyles.h3)),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (_isSignUp) ...[
                  CustomTextField(controller: _nameCtrl, label: 'Full Name', hint: 'Enter your name', prefixIcon: Icons.person_rounded, validator: AppValidators.validateName),
                  const SizedBox(height: 16),
                  CustomTextField(controller: _phoneCtrl, label: 'Phone', hint: '10-digit number', prefixIcon: Icons.phone_rounded, keyboardType: TextInputType.phone, maxLength: 10, validator: AppValidators.validatePhone),
                  const SizedBox(height: 16),
                ],
                CustomTextField(controller: _emailCtrl, label: 'Email', hint: 'you@example.com', prefixIcon: Icons.email_rounded, keyboardType: TextInputType.emailAddress, validator: AppValidators.validateEmail),
                const SizedBox(height: 16),
                CustomTextField(
                  controller: _passCtrl,
                  label: 'Password',
                  hint: 'Minimum 6 characters',
                  prefixIcon: Icons.lock_rounded,
                  suffixIcon: _obscure ? Icons.visibility_off_rounded : Icons.visibility_rounded,
                  onSuffixTap: () => setState(() => _obscure = !_obscure),
                  obscureText: _obscure,
                  validator: AppValidators.validatePassword,
                ),
                if (!_isSignUp) ...[
                  const SizedBox(height: 8),
                  Align(alignment: Alignment.centerRight, child: TextButton(onPressed: () => Navigator.pushNamed(context, '/forgot-password'), child: Text('Forgot Password?', style: AppTextStyles.bodySmall.copyWith(color: AppColors.primaryOrange)))),
                ],
                const SizedBox(height: 24),
                PrimaryButton(
                  text: _isSignUp ? 'Create Account' : 'Login',
                  isLoading: authVM.isLoading,
                  onPressed: () async {
                    if (!_formKey.currentState!.validate()) return;
                    AppHelpers.hideKeyboard(context);
                    bool success;
                    if (_isSignUp) {
                      success = await authVM.signUpWithEmail(_emailCtrl.text.trim(), _passCtrl.text.trim(), _nameCtrl.text.trim(), _phoneCtrl.text.trim());
                    } else {
                      success = await authVM.loginWithEmail(_emailCtrl.text.trim(), _passCtrl.text.trim());
                    }
                    if (success && context.mounted) {
                      if (authVM.currentUser?.isProfileComplete == false) {
                        Navigator.pushReplacementNamed(context, '/profile-setup');
                      } else {
                        Navigator.pushReplacementNamed(context, '/home');
                      }
                    } else if (context.mounted && authVM.errorMessage != null) {
                      AppHelpers.showErrorSnackBar(context, authVM.errorMessage!);
                    }
                  },
                ),
                const SizedBox(height: 16),
                Center(
                  child: TextButton(
                    onPressed: () => setState(() => _isSignUp = !_isSignUp),
                    child: RichText(
                      text: TextSpan(
                        text: _isSignUp ? 'Already have account? ' : "Don't have account? ",
                        style: AppTextStyles.bodySmall,
                        children: [TextSpan(text: _isSignUp ? 'Login' : 'Sign Up', style: AppTextStyles.bodySmall.copyWith(color: AppColors.primaryOrange, fontWeight: FontWeight.w600))],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
