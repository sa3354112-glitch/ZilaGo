import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../widgets/primary_button.dart';
import '../../widgets/custom_text_field.dart';
import '../../viewmodels/auth_viewmodel.dart';
import '../../utils/validators.dart';
import '../../utils/helpers.dart';

/// Forgot Password - Firebase Reset Email
class ForgotPasswordView extends StatefulWidget {
  const ForgotPasswordView({super.key});

  @override
  State<ForgotPasswordView> createState() => _ForgotPasswordViewState();
}

class _ForgotPasswordViewState extends State<ForgotPasswordView> {
  final _emailCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _emailCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authVM = context.watch<AuthViewModel>();
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pop(context))),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(color: AppColors.primaryOrange.withOpacity(0.15), borderRadius: BorderRadius.circular(16)),
                  child: const Icon(Icons.lock_reset_rounded, color: AppColors.primaryOrange, size: 32),
                ),
                const SizedBox(height: 24),
                Text('Forgot Password?', style: AppTextStyles.h1),
                const SizedBox(height: 8),
                Text('Enter your email and we will send you a password reset link', style: AppTextStyles.body),
                const SizedBox(height: 32),
                CustomTextField(controller: _emailCtrl, label: 'Email', hint: 'you@example.com', prefixIcon: Icons.email_rounded, keyboardType: TextInputType.emailAddress, validator: AppValidators.validateEmail),
                const SizedBox(height: 24),
                PrimaryButton(
                  text: 'Send Reset Link',
                  isLoading: authVM.isLoading,
                  onPressed: () async {
                    if (!_formKey.currentState!.validate()) return;
                    final success = await authVM.sendPasswordReset(_emailCtrl.text.trim());
                    if (success && context.mounted) {
                      AppHelpers.showSuccessSnackBar(context, 'Reset link sent to ${_emailCtrl.text}');
                      Navigator.pop(context);
                    } else if (context.mounted) {
                      AppHelpers.showErrorSnackBar(context, authVM.errorMessage ?? 'Failed to send email');
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
