import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../widgets/primary_button.dart';
import '../../widgets/otp_input_field.dart';
import '../../viewmodels/auth_viewmodel.dart';
import '../../utils/helpers.dart';

/// OTP Verification View - Firebase Phone Auth
class OtpView extends StatefulWidget {
  const OtpView({super.key});

  @override
  State<OtpView> createState() => _OtpViewState();
}

class _OtpViewState extends State<OtpView> {
  final _otpCtrl = TextEditingController();

  @override
  void dispose() {
    _otpCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final phone = ModalRoute.of(context)?.settings.arguments as String? ?? 'Your number';
    final authVM = context.watch<AuthViewModel>();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pop(context))),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Verify OTP', style: AppTextStyles.h1),
              const SizedBox(height: 8),
              Text('Code sent to +91 $phone', style: AppTextStyles.body),
              const SizedBox(height: 32),
              OtpInputField(
                controller: _otpCtrl,
                onCompleted: (val) async {
                  final success = await authVM.verifyOTP(val, context);
                  if (success && context.mounted) {
                    if (authVM.currentUser?.isProfileComplete == false) {
                      Navigator.pushReplacementNamed(context, '/profile-setup');
                    } else {
                      Navigator.pushReplacementNamed(context, '/home');
                    }
                  } else if (context.mounted) {
                    AppHelpers.showErrorSnackBar(context, authVM.errorMessage ?? 'Invalid OTP');
                  }
                },
              ),
              const SizedBox(height: 24),
              PrimaryButton(
                text: 'Verify & Continue',
                isLoading: authVM.isLoading,
                onPressed: () async {
                  if (_otpCtrl.text.length != 6) {
                    AppHelpers.showErrorSnackBar(context, 'Enter 6-digit OTP');
                    return;
                  }
                  final success = await authVM.verifyOTP(_otpCtrl.text.trim(), context);
                  if (success && context.mounted) {
                    if (authVM.currentUser?.isProfileComplete == false) {
                      Navigator.pushReplacementNamed(context, '/profile-setup');
                    } else {
                      Navigator.pushReplacementNamed(context, '/home');
                    }
                  } else if (context.mounted) {
                    AppHelpers.showErrorSnackBar(context, authVM.errorMessage ?? 'Verification failed');
                  }
                },
              ),
              const SizedBox(height: 16),
              Center(
                child: TextButton(
                  onPressed: () {
                    AppHelpers.showSnackBar(context, 'OTP resent to +91 $phone');
                    authVM.sendOTP(phone);
                  },
                  child: Text('Resend OTP', style: AppTextStyles.label.copyWith(color: AppColors.primaryOrange)),
                ),
              ),
              if (authVM.errorMessage != null) ...[
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: AppColors.error.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                  child: Row(children: [const Icon(Icons.error_rounded, color: AppColors.error, size: 20), const SizedBox(width: 8), Expanded(child: Text(authVM.errorMessage!, style: AppTextStyles.bodySmall.copyWith(color: AppColors.error)))]),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
