import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../widgets/primary_button.dart';
import '../../widgets/custom_text_field.dart';
import '../../viewmodels/auth_viewmodel.dart';
import '../../models/user_model_new.dart';
import '../../utils/validators.dart';
import '../../utils/helpers.dart';

/// Driver Login View
class DriverLoginView extends StatefulWidget {
  const DriverLoginView({super.key});

  @override
  State<DriverLoginView> createState() => _DriverLoginViewState();
}

class _DriverLoginViewState extends State<DriverLoginView> {
  final _phoneCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    Future.microtask(() => context.read<AuthViewModel>().setUserType(UserType.driver));
  }

  @override
  Widget build(BuildContext context) {
    final authVM = context.watch<AuthViewModel>();
    final w = MediaQuery.of(context).size.width;
    final pad = w < 360 ? 16.0 : 24.0;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pushReplacementNamed(context, '/customer-login')),
        title: Text('Driver Login', style: AppTextStyles.h3),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(pad),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: AppColors.primaryOrange.withOpacity(0.1), borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.primaryOrange.withOpacity(0.3))),
                  child: Row(
                    children: [
                      const Icon(Icons.info_rounded, color: AppColors.primaryOrange),
                      const SizedBox(width: 12),
                      Expanded(child: Text('Earn Rs 1500+ daily in Nagina. Zero commission first month!', style: AppTextStyles.bodySmall.copyWith(color: AppColors.primaryOrangeLight))),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                Text('Driver Partner Login', style: AppTextStyles.h1),
                const SizedBox(height: 8),
                Text('Login to start earning in your zila', style: AppTextStyles.body),
                const SizedBox(height: 32),
                CustomTextField(
                  controller: _phoneCtrl,
                  label: 'Phone Number',
                  hint: 'Enter driver mobile number',
                  prefixIcon: Icons.phone_rounded,
                  keyboardType: TextInputType.phone,
                  maxLength: 10,
                  validator: AppValidators.validatePhone,
                ),
                const SizedBox(height: 24),
                PrimaryButton(
                  text: 'Send OTP',
                  icon: Icons.local_taxi_rounded,
                  isLoading: authVM.isLoading,
                  onPressed: () async {
                    if (!_formKey.currentState!.validate()) return;
                    AppHelpers.hideKeyboard(context);
                    await authVM.sendOTP(_phoneCtrl.text.trim());
                    if (authVM.verificationId != null && context.mounted) {
                      Navigator.pushNamed(context, '/otp', arguments: _phoneCtrl.text.trim());
                    } else if (context.mounted && authVM.errorMessage != null) {
                      AppHelpers.showErrorSnackBar(context, authVM.errorMessage!);
                    }
                  },
                ),
                const SizedBox(height: 16),
                Center(child: TextButton(onPressed: () => Navigator.pushNamed(context, '/email-login'), child: Text('Login with Email instead', style: AppTextStyles.bodySmall.copyWith(color: AppColors.primaryOrange)))),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
