import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../widgets/primary_button.dart';
import '../../widgets/custom_text_field.dart';
import '../../widgets/social_login_button.dart';
import '../../viewmodels/auth_viewmodel.dart';
import '../../models/user_model_new.dart';
import '../../utils/validators.dart';
import '../../utils/helpers.dart';

/// Customer Login - Phone + Email + Google
class CustomerLoginView extends StatefulWidget {
  const CustomerLoginView({super.key});

  @override
  State<CustomerLoginView> createState() => _CustomerLoginViewState();
}

class _CustomerLoginViewState extends State<CustomerLoginView> {
  final _phoneCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _phoneCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authVM = context.watch<AuthViewModel>();
    final w = MediaQuery.of(context).size.width;
    final pad = w < 360 ? 16.0 : 24.0;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(pad),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 20),
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(gradient: AppColors.logoGradient, borderRadius: BorderRadius.circular(16)),
                  child: const Center(child: Text('Z', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Colors.white))),
                ),
                const SizedBox(height: 24),
                Text('Welcome to ZilaGo', style: AppTextStyles.h1),
                const SizedBox(height: 8),
                Text('Nagina ki apni ride service', style: AppTextStyles.body),
                const SizedBox(height: 32),

                // User Type Toggle
                Container(
                  decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12)),
                  child: Row(
                    children: [
                      Expanded(
                        child: _TypeChip(
                          label: 'Customer',
                          selected: authVM.selectedUserType == UserType.customer,
                          onTap: () => authVM.setUserType(UserType.customer),
                        ),
                      ),
                      Expanded(
                        child: _TypeChip(
                          label: 'Driver',
                          selected: authVM.selectedUserType == UserType.driver,
                          onTap: () => Navigator.pushReplacementNamed(context, '/driver-login'),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                CustomTextField(
                  controller: _phoneCtrl,
                  label: 'Phone Number',
                  hint: 'Enter 10-digit number',
                  prefixIcon: Icons.phone_rounded,
                  keyboardType: TextInputType.phone,
                  maxLength: 10,
                  validator: AppValidators.validatePhone,
                ),
                const SizedBox(height: 20),
                PrimaryButton(
                  text: 'Send OTP',
                  isLoading: authVM.isLoading,
                  onPressed: () async {
                    if (!_formKey.currentState!.validate()) return;
                    AppHelpers.hideKeyboard(context);
                    await authVM.sendOTP(_phoneCtrl.text.trim());
                    if (authVM.verificationId != null && context.mounted) {
                      Navigator.pushNamed(context, '/otp', arguments: _phoneCtrl.text.trim());
                    } else if (authVM.errorMessage != null && context.mounted) {
                      AppHelpers.showErrorSnackBar(context, authVM.errorMessage!);
                    }
                  },
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    const Expanded(child: Divider(color: AppColors.border)),
                    Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Text('OR', style: AppTextStyles.bodySmall)),
                    const Expanded(child: Divider(color: AppColors.border)),
                  ],
                ),
                const SizedBox(height: 16),
                SocialLoginButton(
                  text: 'Continue with Email',
                  icon: Icons.email_rounded,
                  onPressed: () => Navigator.pushNamed(context, '/email-login'),
                ),
                const SizedBox(height: 12),
                SocialLoginButton(
                  text: 'Continue with Google',
                  icon: Icons.g_mobiledata_rounded,
                  onPressed: () async {
                    final success = await authVM.loginWithGoogle();
                    if (success && context.mounted) {
                      if (authVM.currentUser?.isProfileComplete == false) {
                        Navigator.pushReplacementNamed(context, '/profile-setup');
                      } else {
                        Navigator.pushReplacementNamed(context, '/home');
                      }
                    } else if (context.mounted && authVM.errorMessage != null) {
                      AppHelpers.showErrorSnackBar(context, authVM.errorMessage!);
                    }
                  },
                ),
                const SizedBox(height: 24),
                Center(
                  child: Text('By continuing, you agree to our Terms & Privacy Policy', style: AppTextStyles.bodySmall, textAlign: TextAlign.center),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TypeChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _TypeChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: selected ? AppColors.primaryOrange : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(child: Text(label, style: AppTextStyles.label.copyWith(color: selected ? Colors.white : AppColors.textSecondary))),
      ),
    );
  }
}
