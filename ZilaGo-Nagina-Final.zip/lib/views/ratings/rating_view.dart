
import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../services/payments/rating_service.dart';
class RatingView extends StatefulWidget {
  final String rideId; final String driverId; final String userId; final String userName;
  const RatingView({super.key, required this.rideId, required this.driverId, required this.userId, required this.userName});
  @override
  State<RatingView> createState() => _RatingViewState();
}
class _RatingViewState extends State<RatingView> {
  double _rating = 5;
  final _reviewCtrl = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text('Rate Ride', style: AppTextStyles.h3)),
      body: Padding(padding: const EdgeInsets.all(24), child: Column(children: [
        const Icon(Icons.star_rounded, size: 64, color: Colors.amber),
        const SizedBox(height: 16),
        Text('How was your ride?', style: AppTextStyles.h2),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(5, (i) => IconButton(icon: Icon(Icons.star, color: i < _rating ? Colors.amber : AppColors.surfaceVariant, size: 36), onPressed: () => setState(()=> _rating = (i+1).toDouble())))),
        TextField(controller: _reviewCtrl, maxLines: 3, decoration: InputDecoration(hintText: 'Review (optional)', filled: true, fillColor: AppColors.surface, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none))),
        const Spacer(),
        SizedBox(width: double.infinity, height: 54, child: ElevatedButton(onPressed: () async { await RatingService().submitRating(rideId: widget.rideId, driverId: widget.driverId, userId: widget.userId, userName: widget.userName, rating: _rating, review: _reviewCtrl.text); if(mounted) Navigator.pop(context); }, style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryOrange), child: Text('Submit', style: AppTextStyles.button))),
      ])),
    );
  }
}
