
import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../services/wallet/wallet_service.dart';
class WalletView extends StatelessWidget {
  final String userId;
  const WalletView({super.key, required this.userId});
  @override
  Widget build(BuildContext context) {
    final service = WalletService();
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text('Wallet', style: AppTextStyles.h2)),
      body: StreamBuilder(
        stream: service.streamWallet(userId),
        builder: (context, snap) {
          final wallet = snap.data;
          return Column(children: [
            Container(margin: const EdgeInsets.all(16), padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: AppColors.primaryGradient, borderRadius: BorderRadius.circular(16)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Balance', style: AppTextStyles.bodySmall.copyWith(color: Colors.white70)), Text('Rs \${wallet?.balance.toStringAsFixed(0) ?? '0'}', style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w800, color: Colors.white))])),
            Expanded(child: StreamBuilder(stream: service.streamTransactions(userId), builder: (context, txSnap){ final txs = txSnap.data ?? []; return ListView.builder(padding: const EdgeInsets.all(16), itemCount: txs.length, itemBuilder: (c,i){ final tx = txs[i]; return ListTile(tileColor: AppColors.surface, leading: Icon(tx.type=='credit'? Icons.arrow_downward: Icons.arrow_upward, color: tx.type=='credit'? AppColors.success: AppColors.error), title: Text(tx.reason), subtitle: Text(tx.createdAt.toString()), trailing: Text('Rs \${tx.amount}'));});})),
          ]);
        },
      ),
    );
  }
}
