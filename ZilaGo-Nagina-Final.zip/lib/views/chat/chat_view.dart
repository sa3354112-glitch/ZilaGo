
import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../services/chat/chat_service.dart';
class ChatView extends StatefulWidget {
  final String rideId; final String senderId; final String senderType;
  const ChatView({super.key, required this.rideId, required this.senderId, required this.senderType});
  @override
  State<ChatView> createState() => _ChatViewState();
}
class _ChatViewState extends State<ChatView> {
  final _ctrl = TextEditingController();
  final _service = ChatService();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text('Chat', style: AppTextStyles.h3)),
      body: Column(children: [
        Expanded(child: StreamBuilder(stream: _service.streamMessages(widget.rideId), builder: (context, snap){ final msgs = snap.data ?? []; return ListView.builder(padding: const EdgeInsets.all(16), itemCount: msgs.length, itemBuilder: (c,i){ final m = msgs[i]; final isMe = m.senderId==widget.senderId; return Align(alignment: isMe? Alignment.centerRight: Alignment.centerLeft, child: Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: isMe? AppColors.primaryOrange: AppColors.surface, borderRadius: BorderRadius.circular(12)), child: Text(m.message)));});})),
        Container(padding: const EdgeInsets.all(12), color: AppColors.surface, child: Row(children: [Expanded(child: TextField(controller: _ctrl, decoration: InputDecoration(hintText: 'Message...', filled: true, fillColor: AppColors.background, border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none)))), IconButton(icon: const Icon(Icons.send, color: AppColors.primaryOrange), onPressed: (){ if(_ctrl.text.trim().isNotEmpty){ _service.sendMessage(rideId: widget.rideId, senderId: widget.senderId, senderType: widget.senderType, message: _ctrl.text.trim()); _ctrl.clear(); }})])),
      ]),
    );
  }
}
