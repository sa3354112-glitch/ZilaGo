import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../widgets/primary_button.dart';
import '../../viewmodels/auth_viewmodel.dart';
import '../../utils/helpers.dart';

/// Home Placeholder with Profile + Logout
class HomeView extends StatelessWidget {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    final authVM = context.watch<AuthViewModel>();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('ZilaGo', style: AppTextStyles.h2.copyWith(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout_rounded),
            onPressed: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  backgroundColor: AppColors.surface,
                  title: Text('Logout?', style: AppTextStyles.h3),
                  content: Text('Are you sure you want to logout?', style: AppTextStyles.body),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                    TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Logout', style: TextStyle(color: AppColors.error))),
                  ],
                ),
              );
              if (confirm == true) {
                await authVM.logout();
                if (context.mounted) {
                  Navigator.pushNamedAndRemoveUntil(context, '/customer-login', (_) => false);
                  AppHelpers.showSuccessSnackBar(context, 'Logged out successfully');
                }
              }
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(gradient: AppColors.cardGradient, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 56,
                          height: 56,
                          decoration: const BoxDecoration(gradient: AppColors.logoGradient, shape: BoxShape.circle),
                          child: Center(child: Text(authVM.currentUser?.name.isNotEmpty == true ? authVM.currentUser!.name[0].toUpperCase() : 'U', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: Colors.white))),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(authVM.currentUser?.name ?? 'User', style: AppTextStyles.h3),
                              Text(authVM.currentUser?.phone ?? '', style: AppTextStyles.bodySmall),
                              Container(
                                margin: const EdgeInsets.only(top: 6),
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(color: AppColors.primaryOrange.withOpacity(0.15), borderRadius: BorderRadius.circular(6)),
                                child: Text(authVM.currentUser?.userType.name.toUpperCase() ?? 'CUSTOMER', style: AppTextStyles.taglineSmall.copyWith(color: AppColors.primaryOrange)),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
                child: Column(
                  children: [
                    const Icon(Icons.check_circle_rounded, size: 48, color: AppColors.success),
                    const SizedBox(height: 12),
                    Text('Authentication Complete!', style: AppTextStyles.h2),
                    const SizedBox(height: 8),
                    Text('Phase 2 Done - Ready for Ride Booking Features', style: AppTextStyles.bodySmall, textAlign: TextAlign.center),
                  ],
                ),
              ),
              const Spacer(),
              PrimaryButton(
                text: 'Logout',
                isOutlined: true,
                icon: Icons.logout_rounded,
                onPressed: () async {
                  await authVM.logout();
                  if (context.mounted) Navigator.pushNamedAndRemoveUntil(context, '/customer-login', (_) => false);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
