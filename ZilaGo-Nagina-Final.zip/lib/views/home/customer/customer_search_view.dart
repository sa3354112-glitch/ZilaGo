import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/constants/map_constants.dart';
import '../../models/ride/place_model.dart';
import '../../viewmodels/home/customer_home_viewmodel.dart';
import '../../widgets/home/search_widgets.dart';

class CustomerSearchView extends StatefulWidget {
  final bool isPickup;
  final CustomerHomeViewModel vm;
  const CustomerSearchView({super.key, required this.isPickup, required this.vm});

  @override
  State<CustomerSearchView> createState() => _CustomerSearchViewState();
}

class _CustomerSearchViewState extends State<CustomerSearchView> {
  final _searchCtrl = TextEditingController();
  List<PlaceModel> _filtered = [];

  @override
  void initState() {
    super.initState();
    _filtered = NaginaPlaces.localities.map((e) => PlaceModel.fromNaginaLocality(e)).toList();
    _searchCtrl.addListener(() {
      final q = _searchCtrl.text.toLowerCase();
      setState(() {
        _filtered = NaginaPlaces.localities
            .map((e) => PlaceModel.fromNaginaLocality(e))
            .where((p) => p.name.toLowerCase().contains(q))
            .toList();
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        title: Text(widget.isPickup ? 'Pickup location' : 'Destination', style: AppTextStyles.h3),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(70),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchCtrl,
              autofocus: true,
              decoration: InputDecoration(
                hintText: 'Search in Nagina...',
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true,
                fillColor: AppColors.surface,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
          ),
        ),
      ),
      body: ListView.separated(
        itemCount: _filtered.length + 1,
        separatorBuilder: (_, __) => const Divider(color: AppColors.divider, height: 1),
        itemBuilder: (context, index) {
          if (index == 0) {
            return ListTile(
              leading: Container(width: 36, height: 36, decoration: BoxDecoration(color: AppColors.primaryOrange.withOpacity(0.15), shape: BoxShape.circle), child: const Icon(Icons.my_location_rounded, color: AppColors.primaryOrange, size: 18)),
              title: Text('Current Location', style: AppTextStyles.label),
              subtitle: Text(widget.vm.currentPlace?.address ?? 'Nagina, Bijnor', style: AppTextStyles.bodySmall),
              onTap: () {
                if (widget.vm.currentPlace != null) {
                  if (widget.isPickup) {
                    widget.vm.setPickup(widget.vm.currentPlace!);
                  } else {
                    widget.vm.setDestination(widget.vm.currentPlace!);
                    widget.vm.goToCategorySelection();
                  }
                  Navigator.pop(context);
                }
              },
            );
          }
          final place = _filtered[index - 1];
          return SearchLocationTile(
            place: place,
            isPickup: widget.isPickup,
            onTap: () {
              if (widget.isPickup) {
                widget.vm.setPickup(place);
              } else {
                widget.vm.setDestination(place);
                widget.vm.goToCategorySelection();
              }
              Navigator.pop(context);
            },
          );
        },
      ),
    );
  }
}
