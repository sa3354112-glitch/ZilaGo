import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/constants/map_constants.dart';
import '../../viewmodels/home/customer_home_viewmodel.dart';
import '../../widgets/home/ride_category_card.dart';
import '../../widgets/home/search_widgets.dart';
import '../../widgets/home/driver_widgets.dart';
import '../../models/ride/place_model.dart';
import 'customer_search_view.dart';
import 'customer_tracking_view.dart';

/// Customer Home View - Main Maps + Bottom Sheet Flow
class CustomerHomeView extends StatelessWidget {
  const CustomerHomeView({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => CustomerHomeViewModel(),
      child: const _CustomerHomeContent(),
    );
  }
}

class _CustomerHomeContent extends StatelessWidget {
  const _CustomerHomeContent();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<CustomerHomeViewModel>();
    final screenH = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          // Google Map
          GoogleMap(
            initialCameraPosition: const CameraPosition(target: LatLng(MapConstants.naginaLat, MapConstants.naginaLng), zoom: MapConstants.defaultZoom),
            onMapCreated: vm.setMapController,
            markers: vm.markers,
            polylines: vm.polylines,
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
            zoomControlsEnabled: false,
            mapToolbarEnabled: false,
            compassEnabled: false,
          ),

          // Top Bar
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(color: AppColors.surface, shape: BoxShape.circle, boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 10)]),
                    child: IconButton(icon: const Icon(Icons.menu_rounded), onPressed: () => Scaffold.of(context).openDrawer()),
                  ),
                  const Spacer(),
                  Container(
                    decoration: BoxDecoration(color: AppColors.surface, shape: BoxShape.circle),
                    child: IconButton(icon: const Icon(Icons.history_rounded), onPressed: () => Navigator.pushNamed(context, '/ride-history')),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    decoration: BoxDecoration(color: AppColors.surface, shape: BoxShape.circle),
                    child: IconButton(icon: const Icon(Icons.my_location_rounded), onPressed: () {}),
                  ),
                ],
              ),
            ),
          ),

          // Bottom Sheet
          DraggableScrollableSheet(
            initialChildSize: vm.bottomSheetIndex == 0 ? 0.35 : 0.55,
            minChildSize: 0.3,
            maxChildSize: 0.85,
            builder: (context, scrollController) {
              return Container(
                decoration: const BoxDecoration(color: AppColors.backgroundLight, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
                child: SingleChildScrollView(
                  controller: scrollController,
                  child: _buildBottomSheetContent(context, vm),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildBottomSheetContent(BuildContext context, CustomerHomeViewModel vm) {
    switch (vm.bottomSheetIndex) {
      case 0:
        return _SearchBottomSheet(vm: vm);
      case 1:
        return _CategoryBottomSheet(vm: vm);
      case 2:
        return _ConfirmBottomSheet(vm: vm);
      case 3:
        return _SearchingBottomSheet(vm: vm);
      case 4:
        return CustomerTrackingView(vm: vm);
      default:
        return _SearchBottomSheet(vm: vm);
    }
  }
}

// ========== Bottom Sheets ==========

class _SearchBottomSheet extends StatelessWidget {
  final CustomerHomeViewModel vm;
  const _SearchBottomSheet({required this.vm});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)))),
          const SizedBox(height: 16),
          Text('Where to go?', style: AppTextStyles.h2),
          const SizedBox(height: 16),
          // Pickup
          GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CustomerSearchView(isPickup: true, vm: vm))),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
              decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
              child: Row(
                children: [
                  Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.primaryOrange, shape: BoxShape.circle)),
                  const SizedBox(width: 12),
                  Expanded(child: Text(vm.pickupPlace?.name ?? 'Current Location', style: AppTextStyles.label)),
                  const Icon(Icons.swap_vert_rounded, size: 20, color: AppColors.textTertiary),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          // Destination
          GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CustomerSearchView(isPickup: false, vm: vm))),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
              decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: vm.destinationPlace == null ? AppColors.border : AppColors.primaryOrange)),
              child: Row(
                children: [
                  Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.primaryPurple, shape: BoxShape.circle)),
                  const SizedBox(width: 12),
                  Expanded(child: Text(vm.destinationPlace?.name ?? 'Where to?', style: AppTextStyles.label.copyWith(color: vm.destinationPlace == null ? AppColors.textTertiary : AppColors.textPrimary))),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          // Favorites
          Row(
            children: [
              FavoritePlaceChip(label: 'Home', icon: Icons.home_rounded, onTap: () {}),
              const SizedBox(width: 8),
              FavoritePlaceChip(label: 'Work', icon: Icons.work_rounded, onTap: () {}),
              const SizedBox(width: 8),
              FavoritePlaceChip(label: 'Bus Stand', icon: Icons.directions_bus_rounded, onTap: () {}),
            ],
          ),
          const SizedBox(height: 16),
          // Recent places
          Text('Recent places', style: AppTextStyles.taglineSmall),
          const SizedBox(height: 8),
          ...NaginaPlaces.localities.take(3).map((loc) {
            final place = PlaceModel.fromNaginaLocality(loc);
            return SearchLocationTile(place: place, isPickup: false, onTap: () { vm.setDestination(place); vm.goToCategorySelection(); });
          }),
        ],
      ),
    );
  }
}

class _CategoryBottomSheet extends StatelessWidget {
  final CustomerHomeViewModel vm;
  const _CategoryBottomSheet({required this.vm});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              IconButton(icon: const Icon(Icons.arrow_back_rounded), onPressed: () => vm.goToSearch()),
              Text('${vm.distanceKm.toStringAsFixed(1)} km • ${vm.durationMin.toStringAsFixed(0)} min', style: AppTextStyles.bodySmall),
              const Spacer(),
              TextButton(onPressed: vm.swapPickupDestination, child: const Text('Swap')),
            ],
          ),
          const SizedBox(height: 12),
          Text('Choose your ride', style: AppTextStyles.h2),
          const SizedBox(height: 16),
          ...vm.rideCategories.map((cat) {
            final fare = cat.calculateFare(vm.distanceKm, vm.durationMin);
            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: RideCategoryCard(category: cat, estimatedFare: fare, onTap: () => vm.selectCategory(cat.type)),
            );
          }),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            height: 54,
            child: ElevatedButton(
              onPressed: () => vm.goToConfirmation(),
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryOrange, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              child: Text('Continue • ₹${vm.estimatedFare.toStringAsFixed(0)}', style: AppTextStyles.button),
            ),
          ),
        ],
      ),
    );
  }
}

class _ConfirmBottomSheet extends StatelessWidget {
  final CustomerHomeViewModel vm;
  const _ConfirmBottomSheet({required this.vm});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => vm.setBottomSheetIndex(1)), Text('Confirm Ride', style: AppTextStyles.h2)]),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
            child: Column(
              children: [
                Row(children: [const Icon(Icons.circle, size: 12, color: AppColors.primaryOrange), const SizedBox(width: 8), Expanded(child: Text(vm.pickupPlace?.name ?? '', style: AppTextStyles.label))]),
                const Padding(padding: EdgeInsets.only(left: 5), child: SizedBox(height: 20, child: VerticalDivider(color: AppColors.border))),
                Row(children: [const Icon(Icons.location_on, size: 14, color: AppColors.primaryPurple), const SizedBox(width: 8), Expanded(child: Text(vm.destinationPlace?.name ?? '', style: AppTextStyles.label))]),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(vm.selectedCategory?.name ?? '', style: AppTextStyles.h3), Text('${vm.selectedCategory?.icon} ${vm.selectedCategory?.capacity}', style: AppTextStyles.bodySmall)]),
                Text('₹${vm.estimatedFare.toStringAsFixed(0)}', style: AppTextStyles.h1.copyWith(color: AppColors.primaryOrange)),
              ],
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            height: 54,
            child: ElevatedButton(
              onPressed: () => vm.bookRide('user_123'),
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryOrange, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              child: Text('Book ${vm.selectedCategory?.name} • ₹${vm.estimatedFare.toStringAsFixed(0)}', style: AppTextStyles.button),
            ),
          ),
        ],
      ),
    );
  }
}

class _SearchingBottomSheet extends StatelessWidget {
  final CustomerHomeViewModel vm;
  const _SearchingBottomSheet({required this.vm});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          const SizedBox(height: 8),
          Text('Finding your driver...', style: AppTextStyles.h2),
          Text('We are searching nearby ${vm.selectedCategory?.name} drivers in Nagina', style: AppTextStyles.bodySmall, textAlign: TextAlign.center),
          const SizedBox(height: 8),
          const DriverSearchingAnimation(),
          const SizedBox(height: 16),
          LinearProgressIndicator(backgroundColor: AppColors.surfaceVariant, valueColor: const AlwaysStoppedAnimation(AppColors.primaryOrange)),
          const SizedBox(height: 16),
          TextButton(onPressed: () => vm.cancelCurrentRide('User cancelled searching'), child: Text('Cancel Search', style: AppTextStyles.label.copyWith(color: AppColors.error))),
        ],
      ),
    );
  }
}
