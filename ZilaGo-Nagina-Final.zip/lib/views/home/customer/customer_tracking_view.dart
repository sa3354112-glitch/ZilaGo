import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../viewmodels/home/customer_home_viewmodel.dart';
import '../../widgets/home/driver_widgets.dart';

class CustomerTrackingView extends StatelessWidget {
  final CustomerHomeViewModel vm;
  const CustomerTrackingView({super.key, required this.vm});

  @override
  Widget build(BuildContext context) {
    final ride = vm.currentRide;
    if (ride == null) return const SizedBox();

    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Driver arriving header
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(color: AppColors.success.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
                child: Row(
                  children: [
                    Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.success, shape: BoxShape.circle)),
                    const SizedBox(width: 6),
                    Text(ride.status.name == 'accepted' ? 'Driver accepted • ${ride.driver?.vehicleNumber}' : 'Driver arriving', style: AppTextStyles.taglineSmall.copyWith(color: AppColors.success)),
                  ],
                ),
              ),
              const Spacer(),
              Text('${ride.durationMin.toStringAsFixed(0)} min away', style: AppTextStyles.bodySmall),
            ],
          ),
          const SizedBox(height: 16),
          // Map preview mini
          Container(
            height: 120,
            decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: GoogleMap(
                initialCameraPosition: CameraPosition(target: LatLng(vm.currentLatLng.latitude, vm.currentLatLng.longitude), zoom: 15),
                markers: vm.markers,
                polylines: vm.polylines,
                zoomControlsEnabled: false,
                liteModeEnabled: true,
                onMapCreated: (_) {},
              ),
            ),
          ),
          const SizedBox(height: 16),
          if (ride.driver != null)
            DriverInfoCard(
              driver: ride.driver!,
              fare: ride.fare,
              onCall: () {},
              onCancel: () => _showCancelDialog(context),
            ),
          const SizedBox(height: 16),
          // Trip details
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12)),
            child: Column(
              children: [
                Row(children: [const Icon(Icons.circle, size: 10, color: AppColors.primaryOrange), const SizedBox(width: 8), Expanded(child: Text(ride.pickup.name, style: AppTextStyles.bodySmall.copyWith(color: AppColors.textPrimary)))]),
                const SizedBox(height: 8),
                Row(children: [const Icon(Icons.location_on, size: 12, color: AppColors.primaryPurple), const SizedBox(width: 8), Expanded(child: Text(ride.destination.name, style: AppTextStyles.bodySmall.copyWith(color: AppColors.textPrimary)))]),
                const Divider(color: AppColors.divider, height: 24),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('${ride.distanceKm.toStringAsFixed(1)} km', style: AppTextStyles.bodySmall), Text('₹${ride.fare.toStringAsFixed(0)} • ${ride.category.name}', style: AppTextStyles.label)]),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showCancelDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.backgroundLight,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Cancel ride?', style: AppTextStyles.h2),
            const SizedBox(height: 12),
            ...['Driver is late', 'Changed plans', 'Wrong location', 'Other'].map((reason) => ListTile(
                  title: Text(reason, style: AppTextStyles.label),
                  onTap: () {
                    vm.cancelCurrentRide(reason);
                    Navigator.pop(context);
                    Navigator.pop(context);
                  },
                )),
          ],
        ),
      ),
    );
  }
}
