import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../repositories/ride/ride_repository.dart';
import '../../models/ride/ride_model.dart';

class RideHistoryView extends StatefulWidget {
  const RideHistoryView({super.key});

  @override
  State<RideHistoryView> createState() => _RideHistoryViewState();
}

class _RideHistoryViewState extends State<RideHistoryView> {
  final _repo = RideRepository();
  List<RideModel> _rides = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final rides = await _repo.getRideHistory('user_123');
    setState(() {
      _rides = rides;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text('Ride History', style: AppTextStyles.h2)),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primaryOrange))
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: _rides.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, i) {
                final ride = _rides[i];
                return Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(color: AppColors.success.withOpacity(0.15), borderRadius: BorderRadius.circular(6)),
                            child: Text(ride.status.name.toUpperCase(), style: AppTextStyles.taglineSmall.copyWith(color: AppColors.success, fontSize: 10)),
                          ),
                          Text('₹${ride.fare.toStringAsFixed(0)}', style: AppTextStyles.h3.copyWith(color: AppColors.primaryOrange)),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(children: [const Icon(Icons.circle, size: 10, color: AppColors.primaryOrange), const SizedBox(width: 8), Expanded(child: Text(ride.pickup.name, style: AppTextStyles.bodySmall.copyWith(color: AppColors.textPrimary)))]),
                      const SizedBox(height: 6),
                      Row(children: [const Icon(Icons.location_on, size: 12, color: AppColors.primaryPurple), const SizedBox(width: 8), Expanded(child: Text(ride.destination.name, style: AppTextStyles.bodySmall.copyWith(color: AppColors.textPrimary)))]),
                      const Divider(color: AppColors.divider, height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('${ride.category.icon} ${ride.category.name} • ${ride.distanceKm.toStringAsFixed(1)} km', style: AppTextStyles.bodySmall),
                          Text('${ride.createdAt.day}/${ride.createdAt.month} • ${ride.durationMin.toStringAsFixed(0)} min', style: AppTextStyles.bodySmall),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
