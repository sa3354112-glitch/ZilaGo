import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../models/ride/place_model.dart';
import '../../repositories/ride/ride_repository.dart';

class FavoritePlacesView extends StatefulWidget {
  const FavoritePlacesView({super.key});

  @override
  State<FavoritePlacesView> createState() => _FavoritePlacesViewState();
}

class _FavoritePlacesViewState extends State<FavoritePlacesView> {
  final _repo = RideRepository();
  List<PlaceModel> _favorites = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final favs = await _repo.getFavoritePlaces('user_123');
    setState(() {
      _favorites = favs;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text('Favorite Places', style: AppTextStyles.h2)),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  ..._favorites.map((place) => Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
                        child: Row(
                          children: [
                            Container(width: 40, height: 40, decoration: BoxDecoration(color: place.placeType == 'home' ? AppColors.primaryOrange.withOpacity(0.15) : AppColors.primaryPurple.withOpacity(0.15), shape: BoxShape.circle), child: Icon(place.placeType == 'home' ? Icons.home_rounded : Icons.work_rounded, color: place.placeType == 'home' ? AppColors.primaryOrange : AppColors.primaryPurple, size: 20)),
                            const SizedBox(width: 12),
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(place.name, style: AppTextStyles.label), Text(place.address, style: AppTextStyles.bodySmall)])),
                            const Icon(Icons.edit_rounded, size: 18, color: AppColors.textTertiary),
                          ],
                        ),
                      )),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: OutlinedButton.icon(
                      onPressed: () {},
                      icon: const Icon(Icons.add_rounded),
                      label: Text('Add New Place', style: AppTextStyles.label),
                      style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.border), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
