import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/routes/unified_routes.dart';

class RoleSelectorView extends StatelessWidget {
  const RoleSelectorView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const SizedBox(height: 40),
              Container(width: 80, height: 80, decoration: BoxDecoration(gradient: AppColors.logoGradient, borderRadius: BorderRadius.circular(20)), child: const Center(child: Text('Z', style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, color: Colors.white)))),
              const SizedBox(height: 16),
              Text('ZilaGo', style: AppTextStyles.logoLarge),
              Text('Apni Zila, Apni Sawari', style: AppTextStyles.tagline),
              const SizedBox(height: 40),
              Text('Continue as', style: AppTextStyles.h2),
              const SizedBox(height: 20),
              _RoleCard(icon: Icons.person_rounded, title: 'Customer', subtitle: 'Book rides in Nagina', color: AppColors.primaryOrange, onTap: () => Navigator.pushNamed(context, UnifiedRoutes.customerLogin)),
              const SizedBox(height: 12),
              _RoleCard(icon: Icons.local_taxi_rounded, title: 'Driver Partner', subtitle: 'Earn ₹1500+ daily', color: AppColors.success, onTap: () => Navigator.pushNamed(context, UnifiedRoutes.driverLogin)),
              const SizedBox(height: 12),
              _RoleCard(icon: Icons.admin_panel_settings_rounded, title: 'Admin', subtitle: 'Manage ZilaGo', color: AppColors.primaryPurple, onTap: () => Navigator.pushNamed(context, UnifiedRoutes.adminLogin)),
              const Spacer(),
              Text('Made for Nagina, Bijnor • UP 246762', style: AppTextStyles.bodySmall),
            ],
          ),
        ),
      ),
    );
  }
}

class _RoleCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;
  const _RoleCard({required this.icon, required this.title, required this.subtitle, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: color.withOpacity(0.3))),
        child: Row(
          children: [
            Container(width: 48, height: 48, decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: color, size: 24)),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: AppTextStyles.h3.copyWith(fontSize: 16)), Text(subtitle, style: AppTextStyles.bodySmall)])),
            const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: AppColors.textTertiary),
          ],
        ),
      ),
    );
  }
}
