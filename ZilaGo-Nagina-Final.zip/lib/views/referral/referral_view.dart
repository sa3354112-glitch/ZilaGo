
import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../services/payments/referral_service.dart';
class ReferralView extends StatefulWidget {
  final String userId;
  const ReferralView({super.key, required this.userId});
  @override
  State<ReferralView> createState() => _ReferralViewState();
}
class _ReferralViewState extends State<ReferralView> {
  String _code = '';
  @override
  void initState(){ super.initState(); ReferralService().getOrCreateReferralCode(widget.userId).then((c)=> setState(()=> _code=c)); }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text('Refer & Earn', style: AppTextStyles.h2)),
      body: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
        Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: AppColors.primaryGradient, borderRadius: BorderRadius.circular(16)), child: Column(children: [Text('Invite Friends', style: AppTextStyles.h2.copyWith(color: Colors.white)), Text('You get Rs50', style: AppTextStyles.bodySmall.copyWith(color: Colors.white70)), const SizedBox(height: 12), Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)), child: Text(_code, style: AppTextStyles.h3.copyWith(color: AppColors.primaryOrange)))])),
      ])),
    );
  }
}
