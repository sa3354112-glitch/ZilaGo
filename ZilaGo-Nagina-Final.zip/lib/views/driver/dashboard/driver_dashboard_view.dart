import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_text_styles.dart';
import '../../../widgets/primary_button.dart';
import '../../../viewmodels/driver/driver_dashboard_viewmodel.dart';
import '../../../services/driver/driver_location_service.dart';
import '../../../models/driver/driver_ride_model.dart';

class DriverDashboardView extends StatefulWidget {
  final String driverId;
  const DriverDashboardView({super.key, required this.driverId});

  @override
  State<DriverDashboardView> createState() => _DriverDashboardViewState();
}

class _DriverDashboardViewState extends State<DriverDashboardView> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() => context.read<DriverDashboardViewModel>().initDriver(widget.driverId));
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<DriverDashboardViewModel>();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('ZilaGo Driver', style: AppTextStyles.h2.copyWith(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(icon: const Icon(Icons.account_balance_wallet_rounded), onPressed: () => Navigator.pushNamed(context, '/driver-earnings')),
          IconButton(icon: const Icon(Icons.person_rounded), onPressed: () => Navigator.pushNamed(context, '/driver-profile')),
        ],
      ),
      body: vm.isLoading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primaryOrange))
          : Column(
              children: [
                // Online/Offline Toggle Card
                Container(
                  margin: const EdgeInsets.all(16),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(gradient: vm.isOnline ? LinearGradient(colors: [AppColors.success.withOpacity(0.2), AppColors.surface]) : null, color: vm.isOnline ? null : AppColors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: vm.isOnline ? AppColors.success : AppColors.border)),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(vm.isOnline ? 'You are Online' : 'You are Offline', style: AppTextStyles.h3.copyWith(color: vm.isOnline ? AppColors.success : AppColors.textPrimary)),
                            const SizedBox(height: 4),
                            Text(vm.isOnline ? 'Receiving ride requests in Nagina' : 'Go online to receive rides', style: AppTextStyles.bodySmall),
                            if (vm.earnings != null) ...[
                              const SizedBox(height: 8),
                              Text('Today: ₹${vm.earnings!.todayEarnings.toStringAsFixed(0)} • ${vm.earnings!.todayRides} rides', style: AppTextStyles.label.copyWith(color: AppColors.primaryOrange)),
                            ],
                          ],
                        ),
                      ),
                      Switch(
                        value: vm.isOnline,
                        activeColor: AppColors.success,
                        onChanged: (_) => vm.toggleOnline(widget.driverId),
                      ),
                    ],
                  ),
                ),

                // Current Ride or Requests
                Expanded(
                  child: StreamBuilder<DriverRideRequestModel?>(
                    stream: vm.streamCurrentRide(widget.driverId),
                    builder: (context, snapshot) {
                      final currentRide = snapshot.data;
                      if (currentRide != null) {
                        vm.setCurrentRide(currentRide);
                        return _CurrentRideView(ride: currentRide, driverId: widget.driverId);
                      }
                      // No current ride - show incoming requests
                      return StreamBuilder<List<DriverRideRequestModel>>(
                        stream: vm.streamRequests(widget.driverId),
                        builder: (context, reqSnapshot) {
                          final requests = reqSnapshot.data ?? [];
                          if (!vm.isOnline) {
                            return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.power_settings_new_rounded, size: 64, color: AppColors.textTertiary), const SizedBox(height: 12), Text('Go online to get rides', style: AppTextStyles.h3), Text('Nagina area', style: AppTextStyles.bodySmall)]));
                          }
                          if (requests.isEmpty) {
                            return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [const SizedBox(width: 60, height: 60, child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primaryOrange)), const SizedBox(height: 16), Text('Searching for rides...', style: AppTextStyles.h3), Text('Stay online in Nagina', style: AppTextStyles.bodySmall)]));
                          }
                          return ListView.builder(
                            padding: const EdgeInsets.all(16),
                            itemCount: requests.length,
                            itemBuilder: (context, i) {
                              final req = requests[i];
                              return _RideRequestCard(ride: req, onAccept: () => vm.acceptRide(req.id, widget.driverId), onReject: () {});
                            },
                          );
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }
}

class _RideRequestCard extends StatelessWidget {
  final DriverRideRequestModel ride;
  final VoidCallback onAccept;
  final VoidCallback onReject;
  const _RideRequestCard({required this.ride, required this.onAccept, required this.onReject});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.primaryOrange.withOpacity(0.3))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(children: [Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.success, shape: BoxShape.circle)), const SizedBox(width: 6), Text('${ride.distanceKm.toStringAsFixed(1)} km • ${ride.durationMin.toStringAsFixed(0)} min', style: AppTextStyles.bodySmall)]),
              Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: AppColors.primaryOrange.withOpacity(0.15), borderRadius: BorderRadius.circular(20)), child: Text('₹${ride.fare.toStringAsFixed(0)}', style: AppTextStyles.label.copyWith(color: AppColors.primaryOrange))),
            ],
          ),
          const SizedBox(height: 12),
          Row(children: [const Icon(Icons.circle, size: 12, color: AppColors.primaryOrange), const SizedBox(width: 8), Expanded(child: Text(ride.pickup.name, style: AppTextStyles.label))]),
          const Padding(padding: EdgeInsets.only(left: 5), child: SizedBox(height: 16, child: VerticalDivider(color: AppColors.border))),
          Row(children: [const Icon(Icons.location_on, size: 14, color: AppColors.primaryPurple), const SizedBox(width: 8), Expanded(child: Text(ride.destination.name, style: AppTextStyles.label))]),
          const Divider(color: AppColors.divider, height: 20),
          Row(
            children: [
              CircleAvatar(radius: 16, backgroundColor: AppColors.surfaceVariant, child: Text(ride.userName.isNotEmpty ? ride.userName[0] : 'U', style: const TextStyle(color: Colors.white))),
              const SizedBox(width: 8),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(ride.userName, style: AppTextStyles.label.copyWith(fontSize: 13)), if (ride.userRating != null) Row(children: [const Icon(Icons.star_rounded, size: 12, color: Colors.amber), Text('${ride.userRating}', style: AppTextStyles.bodySmall)])])),
              const SizedBox(width: 8),
              OutlinedButton(onPressed: onReject, style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.border)), child: Text('Reject', style: AppTextStyles.bodySmall)),
              const SizedBox(width: 8),
              ElevatedButton(onPressed: onAccept, style: ElevatedButton.styleFrom(backgroundColor: AppColors.success), child: Text('Accept', style: AppTextStyles.bodySmall.copyWith(color: Colors.white))),
            ],
          ),
        ],
      ),
    );
  }
}

class _CurrentRideView extends StatelessWidget {
  final DriverRideRequestModel ride;
  final String driverId;
  const _CurrentRideView({required this.ride, required this.driverId});

  @override
  Widget build(BuildContext context) {
    final vm = context.read<DriverDashboardViewModel>();
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(color: AppColors.primaryOrange.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
            child: Text('Status: ${ride.status.name.toUpperCase()} • ₹${ride.fare.toStringAsFixed(0)}', style: AppTextStyles.label.copyWith(color: AppColors.primaryOrange)),
          ),
          const SizedBox(height: 16),
          // Customer info
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
            child: Row(
              children: [
                CircleAvatar(radius: 24, backgroundColor: AppColors.surfaceVariant, child: Text(ride.userName.isNotEmpty ? ride.userName[0] : 'U')),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(ride.userName, style: AppTextStyles.h3), Text(ride.userPhone, style: AppTextStyles.bodySmall)])),
                IconButton(icon: const Icon(Icons.call_rounded, color: AppColors.success), onPressed: () {}),
              ],
            ),
          ),
          const SizedBox(height: 12),
          // Route
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12)),
            child: Column(
              children: [
                Row(children: [const Icon(Icons.my_location_rounded, size: 16, color: AppColors.primaryOrange), const SizedBox(width: 8), Expanded(child: Text(ride.pickup.name, style: AppTextStyles.label))]),
                const SizedBox(height: 12),
                Row(children: [const Icon(Icons.location_on_rounded, size: 16, color: AppColors.primaryPurple), const SizedBox(width: 8), Expanded(child: Text(ride.destination.name, style: AppTextStyles.label))]),
              ],
            ),
          ),
          const Spacer(),
          // Action buttons based on status
          if (ride.status == DriverRideStatus.accepted)
            SizedBox(width: double.infinity, height: 54, child: ElevatedButton(onPressed: () => vm.updateStatus(ride.id, DriverRideStatus.arrived), style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryOrange), child: Text('Arrived at Pickup', style: AppTextStyles.button))),
          if (ride.status == DriverRideStatus.arrived)
            SizedBox(width: double.infinity, height: 54, child: ElevatedButton(onPressed: () => vm.updateStatus(ride.id, DriverRideStatus.started), style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryPurple), child: Text('Start Trip', style: AppTextStyles.button))),
          if (ride.status == DriverRideStatus.started)
            SizedBox(width: double.infinity, height: 54, child: ElevatedButton(onPressed: () => vm.updateStatus(ride.id, DriverRideStatus.completed), style: ElevatedButton.styleFrom(backgroundColor: AppColors.success), child: Text('End Trip • Collect ₹${ride.fare.toStringAsFixed(0)}', style: AppTextStyles.button))),
          const SizedBox(height: 12),
          SizedBox(width: double.infinity, child: OutlinedButton(onPressed: () => vm.updateStatus(ride.id, DriverRideStatus.cancelledByDriver), style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.error)), child: Text('Cancel Ride', style: AppTextStyles.label.copyWith(color: AppColors.error)))),
        ],
      ),
    );
  }
}
