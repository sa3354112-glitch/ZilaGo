import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_text_styles.dart';
import '../../../viewmodels/driver/driver_dashboard_viewmodel.dart';

class DriverEarningsView extends StatefulWidget {
  final String driverId;
  const DriverEarningsView({super.key, required this.driverId});

  @override
  State<DriverEarningsView> createState() => _DriverEarningsViewState();
}

class _DriverEarningsViewState extends State<DriverEarningsView> with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 3, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text('Earnings', style: AppTextStyles.h2), bottom: TabBar(controller: _tabCtrl, labelColor: AppColors.primaryOrange, unselectedLabelColor: AppColors.textTertiary, indicatorColor: AppColors.primaryOrange, tabs: const [Tab(text: 'Today'), Tab(text: 'Weekly'), Tab(text: 'Monthly')])),
      body: StreamBuilder(
        stream: context.read<DriverDashboardViewModel>().streamEarnings(widget.driverId),
        builder: (context, snapshot) {
          final earning = snapshot.data;
          return TabBarView(
            controller: _tabCtrl,
            children: [
              _EarningsTab(today: earning?.todayEarnings ?? 0, rides: earning?.todayRides ?? 0, total: earning?.todayEarnings ?? 0, label: 'Today'),
              _EarningsTab(today: earning?.weeklyEarnings ?? 0, rides: earning?.totalRides ?? 0, total: earning?.weeklyEarnings ?? 0, label: 'This Week'),
              _EarningsTab(today: earning?.monthlyEarnings ?? 0, rides: earning?.totalRides ?? 0, total: earning?.monthlyEarnings ?? 0, label: 'This Month'),
            ],
          );
        },
      ),
    );
  }
}

class _EarningsTab extends StatelessWidget {
  final double today;
  final int rides;
  final double total;
  final String label;
  const _EarningsTab({required this.today, required this.rides, required this.total, required this.label});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(gradient: AppColors.primaryGradient, borderRadius: BorderRadius.circular(16)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: AppTextStyles.taglineSmall.copyWith(color: Colors.white70)),
                const SizedBox(height: 8),
                Text('₹${total.toStringAsFixed(0)}', style: AppTextStyles.logoLarge.copyWith(color: Colors.white, fontSize: 36)),
                const SizedBox(height: 8),
                Text('$rides rides completed', style: AppTextStyles.bodySmall.copyWith(color: Colors.white70)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: _StatCard(title: 'Rides', value: '$rides', icon: Icons.local_taxi_rounded)),
              const SizedBox(width: 12),
              Expanded(child: _StatCard(title: 'Distance', value: '${(rides * 3.5).toStringAsFixed(1)} km', icon: Icons.route_rounded)),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _StatCard(title: 'Rating', value: '4.8 ★', icon: Icons.star_rounded)),
              const SizedBox(width: 12),
              Expanded(child: _StatCard(title: 'Balance', value: '₹${total.toStringAsFixed(0)}', icon: Icons.account_balance_wallet_rounded)),
            ],
          ),
          const SizedBox(height: 24),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Payout Details', style: AppTextStyles.h3),
                const SizedBox(height: 12),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Total Earnings', style: AppTextStyles.bodySmall), Text('₹${total.toStringAsFixed(0)}', style: AppTextStyles.label)]),
                const SizedBox(height: 8),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('ZilaGo Commission (10%)', style: AppTextStyles.bodySmall), Text('- ₹${(total * 0.1).toStringAsFixed(0)}', style: AppTextStyles.bodySmall.copyWith(color: AppColors.error))]),
                const Divider(color: AppColors.divider, height: 20),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Net Payable', style: AppTextStyles.label), Text('₹${(total * 0.9).toStringAsFixed(0)}', style: AppTextStyles.label.copyWith(color: AppColors.success))]),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  const _StatCard({required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: AppColors.primaryOrange),
          const SizedBox(height: 8),
          Text(value, style: AppTextStyles.h3),
          Text(title, style: AppTextStyles.bodySmall),
        ],
      ),
    );
  }
}
