import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_text_styles.dart';

class DriverProfileView extends StatelessWidget {
  final String driverId;
  const DriverProfileView({super.key, required this.driverId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text('Driver Profile', style: AppTextStyles.h2)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            CircleAvatar(radius: 50, backgroundColor: AppColors.surfaceVariant, child: const Icon(Icons.person_rounded, size: 50, color: AppColors.textTertiary)),
            const SizedBox(height: 12),
            Text('Driver Name', style: AppTextStyles.h2),
            Text('+91 98765 43210 • Auto Driver', style: AppTextStyles.bodySmall),
            const SizedBox(height: 8),
            Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: AppColors.success.withOpacity(0.15), borderRadius: BorderRadius.circular(20)), child: Row(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.verified_rounded, size: 14, color: AppColors.success), const SizedBox(width: 4), Text('KYC Verified', style: AppTextStyles.taglineSmall.copyWith(color: AppColors.success))])),
            const SizedBox(height: 24),
            _ProfileTile(icon: Icons.badge_rounded, title: 'KYC Documents', subtitle: 'Aadhaar, License, RC, Insurance', onTap: () => Navigator.pushNamed(context, '/driver-kyc')),
            _ProfileTile(icon: Icons.directions_car_rounded, title: 'My Vehicles', subtitle: 'Manage your vehicles', onTap: () {}),
            _ProfileTile(icon: Icons.history_rounded, title: 'Ride History', subtitle: 'View all rides', onTap: () => Navigator.pushNamed(context, '/driver-ride-history')),
            _ProfileTile(icon: Icons.star_rounded, title: 'Ratings & Reviews', subtitle: '4.8 ★ (127 reviews)', onTap: () {}),
            _ProfileTile(icon: Icons.account_balance_wallet_rounded, title: 'Earnings', subtitle: 'Daily, weekly, monthly', onTap: () => Navigator.pushNamed(context, '/driver-earnings')),
            _ProfileTile(icon: Icons.notifications_rounded, title: 'Notifications', subtitle: 'Ride alerts & updates', onTap: () {}),
            _ProfileTile(icon: Icons.help_rounded, title: 'Help & Support', subtitle: 'Contact ZilaGo support', onTap: () {}),
            const SizedBox(height: 24),
            SizedBox(width: double.infinity, height: 50, child: OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.logout_rounded, color: AppColors.error), label: Text('Logout', style: AppTextStyles.label.copyWith(color: AppColors.error)), style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.error)))),
          ],
        ),
      ),
    );
  }
}

class _ProfileTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _ProfileTile({required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
      child: ListTile(
        leading: Container(width: 40, height: 40, decoration: BoxDecoration(color: AppColors.surfaceVariant, borderRadius: BorderRadius.circular(8)), child: Icon(icon, color: AppColors.primaryOrange, size: 20)),
        title: Text(title, style: AppTextStyles.label.copyWith(fontSize: 14)),
        subtitle: Text(subtitle, style: AppTextStyles.bodySmall),
        trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: AppColors.textTertiary),
        onTap: onTap,
      ),
    );
  }
}
