import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_text_styles.dart';
import '../../../viewmodels/driver/driver_dashboard_viewmodel.dart';
import '../../../models/driver/driver_ride_model.dart';

class DriverRideHistoryView extends StatefulWidget {
  final String driverId;
  const DriverRideHistoryView({super.key, required this.driverId});

  @override
  State<DriverRideHistoryView> createState() => _DriverRideHistoryViewState();
}

class _DriverRideHistoryViewState extends State<DriverRideHistoryView> {
  List<DriverRideRequestModel> _rides = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final vm = context.read<DriverDashboardViewModel>();
    final rides = await vm.getRideHistory(widget.driverId);
    setState(() {
      _rides = rides;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text('Ride History', style: AppTextStyles.h2)),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primaryOrange))
          : _rides.isEmpty
              ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.history_rounded, size: 64, color: AppColors.textTertiary), const SizedBox(height: 12), Text('No rides yet', style: AppTextStyles.h3), Text('Complete rides to see history', style: AppTextStyles.bodySmall)]))
              : ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: _rides.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, i) {
                    final ride = _rides[i];
                    final isCompleted = ride.status == DriverRideStatus.completed;
                    return Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: isCompleted ? AppColors.success.withOpacity(0.15) : AppColors.error.withOpacity(0.15), borderRadius: BorderRadius.circular(6)), child: Text(ride.status.name.toUpperCase(), style: AppTextStyles.taglineSmall.copyWith(color: isCompleted ? AppColors.success : AppColors.error, fontSize: 10))),
                              Text('₹${ride.fare.toStringAsFixed(0)}', style: AppTextStyles.h3.copyWith(color: AppColors.primaryOrange)),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text('${ride.userName} • ${ride.userPhone}', style: AppTextStyles.label.copyWith(fontSize: 13)),
                          const SizedBox(height: 8),
                          Row(children: [const Icon(Icons.circle, size: 10, color: AppColors.primaryOrange), const SizedBox(width: 8), Expanded(child: Text(ride.pickup.name, style: AppTextStyles.bodySmall.copyWith(color: AppColors.textPrimary)))]),
                          const SizedBox(height: 6),
                          Row(children: [const Icon(Icons.location_on, size: 12, color: AppColors.primaryPurple), const SizedBox(width: 8), Expanded(child: Text(ride.destination.name, style: AppTextStyles.bodySmall.copyWith(color: AppColors.textPrimary)))]),
                          const Divider(color: AppColors.divider, height: 20),
                          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('${ride.distanceKm.toStringAsFixed(1)} km • ${ride.durationMin.toStringAsFixed(0)} min', style: AppTextStyles.bodySmall), Text('${ride.requestedAt.day}/${ride.requestedAt.month}/${ride.requestedAt.year}', style: AppTextStyles.bodySmall)]),
                        ],
                      ),
                    );
                  },
                ),
    );
  }
}
