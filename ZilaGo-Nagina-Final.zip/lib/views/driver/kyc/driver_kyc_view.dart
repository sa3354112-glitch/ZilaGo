import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_text_styles.dart';
import '../../../widgets/primary_button.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../viewmodels/driver/driver_kyc_viewmodel.dart';
import '../../../models/driver/kyc_model.dart';
import 'package:image_picker/image_picker.dart';

class DriverKycView extends StatefulWidget {
  final String driverId;
  const DriverKycView({super.key, required this.driverId});

  @override
  State<DriverKycView> createState() => _DriverKycViewState();
}

class _DriverKycViewState extends State<DriverKycView> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() => context.read<DriverKycViewModel>().loadKyc(widget.driverId));
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<DriverKycViewModel>();
    final kyc = vm.kycModel;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text('KYC Verification', style: AppTextStyles.h3)),
      body: vm.isLoading && kyc == null
          ? const Center(child: CircularProgressIndicator(color: AppColors.primaryOrange))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Progress
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
                    child: Column(
                      children: [
                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('KYC Progress', style: AppTextStyles.label), Text('${kyc?.completionPercentage.toStringAsFixed(0) ?? 0}%', style: AppTextStyles.label.copyWith(color: AppColors.primaryOrange))]),
                        const SizedBox(height: 8),
                        LinearProgressIndicator(value: (kyc?.completionPercentage ?? 0) / 100, backgroundColor: AppColors.surfaceVariant, valueColor: const AlwaysStoppedAnimation(AppColors.primaryOrange)),
                        const SizedBox(height: 8),
                        Text('Status: ${kyc?.overallStatus.name ?? 'pending'}', style: AppTextStyles.bodySmall),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  _KycTile(title: 'Aadhaar Card', subtitle: 'Front & Back required', doc: kyc?.aadhaar, type: KycDocumentType.aadhaar, driverId: widget.driverId),
                  _KycTile(title: 'Driving License', subtitle: 'Valid DL required', doc: kyc?.license, type: KycDocumentType.license, driverId: widget.driverId),
                  _KycTile(title: 'RC (Registration Certificate)', subtitle: 'Vehicle RC', doc: kyc?.rc, type: KycDocumentType.rc, driverId: widget.driverId),
                  _KycTile(title: 'Insurance', subtitle: 'Valid insurance', doc: kyc?.insurance, type: KycDocumentType.insurance, driverId: widget.driverId),
                  _KycTileProfilePhoto(photoUrl: kyc?.profilePhotoUrl, driverId: widget.driverId),
                ],
              ),
            ),
    );
  }
}

class _KycTile extends StatefulWidget {
  final String title;
  final String subtitle;
  final KycDocumentModel? doc;
  final KycDocumentType type;
  final String driverId;
  const _KycTile({required this.title, required this.subtitle, this.doc, required this.type, required this.driverId});

  @override
  State<_KycTile> createState() => _KycTileState();
}

class _KycTileState extends State<_KycTile> {
  final _numberCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final statusColor = widget.doc?.status == KycStatus.approved ? AppColors.success : widget.doc?.status == KycStatus.rejected ? AppColors.error : AppColors.warning;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(width: 40, height: 40, decoration: BoxDecoration(color: statusColor.withOpacity(0.15), borderRadius: BorderRadius.circular(8)), child: Icon(Icons.badge_rounded, color: statusColor, size: 20)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(widget.title, style: AppTextStyles.label), Text(widget.subtitle, style: AppTextStyles.bodySmall)])),
              Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: statusColor.withOpacity(0.15), borderRadius: BorderRadius.circular(6)), child: Text(widget.doc?.status.name ?? 'pending', style: AppTextStyles.taglineSmall.copyWith(color: statusColor))),
            ],
          ),
          if (widget.doc == null || widget.doc?.status == KycStatus.rejected) ...[
            const SizedBox(height: 12),
            TextField(controller: _numberCtrl, decoration: InputDecoration(hintText: '${widget.title} Number', filled: true, fillColor: AppColors.background, border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none)), style: AppTextStyles.body),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: OutlinedButton.icon(onPressed: () => _upload(true), icon: const Icon(Icons.camera_alt_rounded, size: 16), label: const Text('Front'))),
                const SizedBox(width: 8),
                Expanded(child: OutlinedButton.icon(onPressed: () => _upload(false), icon: const Icon(Icons.camera_alt_rounded, size: 16), label: const Text('Back'))),
              ],
            ),
          ],
          if (widget.doc != null) ...[
            const SizedBox(height: 8),
            Text('Doc No: ${widget.doc!.documentNumber}', style: AppTextStyles.bodySmall),
            if (widget.doc!.rejectionReason != null) Text('Reason: ${widget.doc!.rejectionReason}', style: AppTextStyles.bodySmall.copyWith(color: AppColors.error)),
          ],
        ],
      ),
    );
  }

  Future<void> _upload(bool isFront) async {
    if (_numberCtrl.text.isEmpty && widget.doc == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter document number')));
      return;
    }
    final vm = context.read<DriverKycViewModel>();
    await vm.uploadDocument(driverId: widget.driverId, type: widget.type, documentNumber: _numberCtrl.text.isNotEmpty ? _numberCtrl.text : widget.doc!.documentNumber, isFrontImage: isFront, imageSource: ImageSource.camera);
  }
}

class _KycTileProfilePhoto extends StatelessWidget {
  final String? photoUrl;
  final String driverId;
  const _KycTileProfilePhoto({this.photoUrl, required this.driverId});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
      child: Row(
        children: [
          CircleAvatar(radius: 24, backgroundColor: AppColors.surfaceVariant, backgroundImage: photoUrl != null ? NetworkImage(photoUrl!) : null, child: photoUrl == null ? const Icon(Icons.person_rounded) : null),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Profile Photo', style: AppTextStyles.label), Text('Clear face photo', style: AppTextStyles.bodySmall)])),
          ElevatedButton(onPressed: () {}, style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryOrange), child: Text(photoUrl == null ? 'Upload' : 'Change', style: AppTextStyles.bodySmall.copyWith(color: Colors.white))),
        ],
      ),
    );
  }
}
