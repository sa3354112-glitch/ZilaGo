
import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import 'package:firebase_auth/firebase_auth.dart';
class SettingsView extends StatelessWidget {
  const SettingsView({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text('Settings', style: AppTextStyles.h2)),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        ListTile(leading: const Icon(Icons.person, color: AppColors.primaryOrange), title: Text('Profile', style: AppTextStyles.label), tileColor: AppColors.surface, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
        const SizedBox(height: 10),
        ListTile(leading: const Icon(Icons.logout, color: AppColors.error), title: Text('Logout', style: AppTextStyles.label.copyWith(color: AppColors.error)), tileColor: AppColors.surface, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), onTap: () async { await FirebaseAuth.instance.signOut(); if(context.mounted) Navigator.pushNamedAndRemoveUntil(context, '/', (_) => false); }),
      ]),
    );
  }
}
