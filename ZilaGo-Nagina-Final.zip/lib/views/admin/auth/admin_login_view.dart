import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_text_styles.dart';
import '../../../widgets/primary_button.dart';
import '../../../widgets/custom_text_field.dart';
import '../../../viewmodels/admin/admin_viewmodels.dart';
import '../../../utils/validators.dart';

class AdminLoginView extends StatefulWidget {
  const AdminLoginView({super.key});

  @override
  State<AdminLoginView> createState() => _AdminLoginViewState();
}

class _AdminLoginViewState extends State<AdminLoginView> {
  final _emailCtrl = TextEditingController(text: 'admin@zilago.in');
  final _passCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _obscure = true;

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<AdminAuthViewModel>();
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Center(
        child: Container(
          width: 420,
          padding: const EdgeInsets.all(32),
          decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(width: 64, height: 64, decoration: BoxDecoration(gradient: AppColors.logoGradient, borderRadius: BorderRadius.circular(16)), child: const Center(child: Text('Z', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: Colors.white)))),
                const SizedBox(height: 16),
                Text('ZilaGo Admin Panel', style: AppTextStyles.h2),
                Text('Nagina • Bijnor • UP', style: AppTextStyles.bodySmall),
                const SizedBox(height: 32),
                CustomTextField(controller: _emailCtrl, label: 'Admin Email', hint: 'admin@zilago.in', prefixIcon: Icons.email_rounded, validator: AppValidators.validateEmail),
                const SizedBox(height: 16),
                CustomTextField(controller: _passCtrl, label: 'Password', hint: '••••••••', prefixIcon: Icons.lock_rounded, obscureText: _obscure, suffixIcon: _obscure ? Icons.visibility_off_rounded : Icons.visibility_rounded, onSuffixTap: () => setState(() => _obscure = !_obscure), validator: AppValidators.validatePassword),
                if (vm.error != null) ...[const SizedBox(height: 12), Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: AppColors.error.withOpacity(0.1), borderRadius: BorderRadius.circular(8)), child: Row(children: [const Icon(Icons.error_rounded, color: AppColors.error, size: 16), const SizedBox(width: 8), Expanded(child: Text(vm.error!, style: AppTextStyles.bodySmall.copyWith(color: AppColors.error)))]))],
                const SizedBox(height: 24),
                PrimaryButton(text: 'Login to Dashboard', isLoading: vm.isLoading, onPressed: () async {
                  if (!_formKey.currentState!.validate()) return;
                  final success = await vm.login(_emailCtrl.text.trim(), _passCtrl.text.trim());
                  if (success && context.mounted) Navigator.pushReplacementNamed(context, '/admin-dashboard');
                }),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
