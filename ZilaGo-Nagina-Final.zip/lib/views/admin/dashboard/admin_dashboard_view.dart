import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:firebase_database/firebase_database.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_text_styles.dart';
import '../../../viewmodels/admin/admin_viewmodels.dart';
import '../../../services/admin/admin_services.dart';

class AdminDashboardView extends StatefulWidget {
  const AdminDashboardView({super.key});

  @override
  State<AdminDashboardView> createState() => _AdminDashboardViewState();
}

class _AdminDashboardViewState extends State<AdminDashboardView> {
  int _selectedIndex = 0;

  final _pages = [
    _DashboardHome(),
    _LiveMapView(),
    _CustomersView(),
    _DriversView(),
    _KycApprovalView(),
    _RidesMonitoringView(),
    _EarningsView(),
    _CouponsView(),
    _SupportTicketsView(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Row(
        children: [
          // Sidebar
          Container(
            width: 260,
            color: AppColors.surface,
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(20),
                  child: Row(children: [Container(width: 40, height: 40, decoration: BoxDecoration(gradient: AppColors.logoGradient, borderRadius: BorderRadius.circular(10)), child: const Center(child: Text('Z', style: TextStyle(fontWeight: FontWeight.w900, color: Colors.white)))), const SizedBox(width: 10), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('ZilaGo Admin', style: AppTextStyles.h3.copyWith(fontSize: 16)), Text('Super Admin', style: AppTextStyles.bodySmall.copyWith(fontSize: 11))])]),
                ),
                const Divider(color: AppColors.divider),
                Expanded(
                  child: ListView(
                    children: [
                      _SideItem(icon: Icons.dashboard_rounded, title: 'Dashboard', index: 0, selected: _selectedIndex, onTap: (i) => setState(() => _selectedIndex = i)),
                      _SideItem(icon: Icons.map_rounded, title: 'Live Map', index: 1, selected: _selectedIndex, onTap: (i) => setState(() => _selectedIndex = i)),
                      _SideItem(icon: Icons.people_rounded, title: 'Customers', index: 2, selected: _selectedIndex, onTap: (i) => setState(() => _selectedIndex = i)),
                      _SideItem(icon: Icons.local_taxi_rounded, title: 'Drivers', index: 3, selected: _selectedIndex, onTap: (i) => setState(() => _selectedIndex = i)),
                      _SideItem(icon: Icons.verified_user_rounded, title: 'KYC Approval', index: 4, selected: _selectedIndex, onTap: (i) => setState(() => _selectedIndex = i)),
                      _SideItem(icon: Icons.local_shipping_rounded, title: 'Live Rides', index: 5, selected: _selectedIndex, onTap: (i) => setState(() => _selectedIndex = i)),
                      _SideItem(icon: Icons.account_balance_wallet_rounded, title: 'Earnings', index: 6, selected: _selectedIndex, onTap: (i) => setState(() => _selectedIndex = i)),
                      _SideItem(icon: Icons.local_offer_rounded, title: 'Coupons', index: 7, selected: _selectedIndex, onTap: (i) => setState(() => _selectedIndex = i)),
                      _SideItem(icon: Icons.support_agent_rounded, title: 'Support', index: 8, selected: _selectedIndex, onTap: (i) => setState(() => _selectedIndex = i)),
                    ],
                  ),
                ),
                const Divider(color: AppColors.divider),
                ListTile(leading: const Icon(Icons.logout_rounded, color: AppColors.error), title: Text('Logout', style: AppTextStyles.label.copyWith(color: AppColors.error)), onTap: () => Navigator.pushReplacementNamed(context, '/admin-login')),
              ],
            ),
          ),
          // Main content
          Expanded(child: _pages[_selectedIndex]),
        ],
      ),
    );
  }
}

class _SideItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final int index;
  final int selected;
  final Function(int) onTap;
  const _SideItem({required this.icon, required this.title, required this.index, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isSel = index == selected;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(color: isSel ? AppColors.primaryOrange.withOpacity(0.15) : null, borderRadius: BorderRadius.circular(8)),
      child: ListTile(leading: Icon(icon, color: isSel ? AppColors.primaryOrange : AppColors.textTertiary, size: 20), title: Text(title, style: AppTextStyles.label.copyWith(fontSize: 13, color: isSel ? AppColors.primaryOrange : AppColors.textSecondary)), onTap: () => onTap(index)),
    );
  }
}

class _DashboardHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final vm = context.watch<AdminDashboardViewModel>();
    final stats = vm.stats;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Dashboard Overview', style: AppTextStyles.h1),
          Text('Nagina, Bijnor - Live Stats', style: AppTextStyles.bodySmall),
          const SizedBox(height: 20),
          if (vm.loading) const LinearProgressIndicator(color: AppColors.primaryOrange),
          if (stats != null) ...[
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 4,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              childAspectRatio: 1.6,
              children: [
                _StatCard(title: 'Total Customers', value: '${stats.totalCustomers}', icon: Icons.people_rounded, color: AppColors.info),
                _StatCard(title: 'Total Drivers', value: '${stats.totalDrivers}', icon: Icons.local_taxi_rounded, color: AppColors.primaryOrange),
                _StatCard(title: 'Online Drivers', value: '${stats.onlineDrivers}', icon: Icons.online_prediction_rounded, color: AppColors.success),
                _StatCard(title: 'Active Rides', value: '${stats.activeRides}', icon: Icons.route_rounded, color: AppColors.primaryPurple),
                _StatCard(title: 'Today Rides', value: '${stats.todayRides}', icon: Icons.receipt_rounded, color: AppColors.warning),
                _StatCard(title: 'Today Earnings', value: '₹${stats.todayEarnings.toStringAsFixed(0)}', icon: Icons.currency_rupee_rounded, color: AppColors.success),
                _StatCard(title: 'Commission', value: '₹${stats.commissionEarned.toStringAsFixed(0)}', icon: Icons.account_balance_wallet_rounded, color: AppColors.primaryOrange),
                _StatCard(title: 'Pending KYC', value: '${stats.pendingKyc}', icon: Icons.pending_rounded, color: AppColors.error),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color color;
  const _StatCard({required this.title, required this.value, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Container(width: 36, height: 36, decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(8)), child: Icon(icon, color: color, size: 18)), const Icon(Icons.more_horiz_rounded, color: AppColors.textTertiary, size: 16)]),
          const Spacer(),
          Text(value, style: AppTextStyles.h2.copyWith(fontSize: 22)),
          Text(title, style: AppTextStyles.bodySmall.copyWith(fontSize: 11)),
        ],
      ),
    );
  }
}

class _LiveMapView extends StatefulWidget {
  @override
  State<_LiveMapView> createState() => _LiveMapViewState();
}

class _LiveMapViewState extends State<_LiveMapView> {
  Set<Marker> _markers = {};
  GoogleMapController? _mapController;

  @override
  void initState() {
    super.initState();
    _listenDrivers();
  }

  void _listenDrivers() {
    FirebaseDatabase.instance.ref('driver_locations').onValue.listen((event) {
      final data = event.snapshot.value as Map<dynamic, dynamic>?;
      if (data == null) return;
      final Set<Marker> newMarkers = {};
      data.forEach((key, value) {
        final loc = Map<String, dynamic>.from(value as Map);
        if (loc['isOnline'] == true) {
          newMarkers.add(Marker(markerId: MarkerId(key.toString()), position: LatLng((loc['lat'] as num).toDouble(), (loc['lng'] as num).toDouble()), icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueOrange), infoWindow: InfoWindow(title: 'Driver $key')));
        }
      });
      setState(() => _markers = newMarkers);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        GoogleMap(initialCameraPosition: const CameraPosition(target: LatLng(29.4457, 78.4425), zoom: 13), markers: _markers, onMapCreated: (c) => _mapController = c),
        Positioned(top: 16, left: 16, child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(8)), child: Text('Live Drivers: ${_markers.length} • Nagina', style: AppTextStyles.label))),
      ],
    );
  }
}

// Placeholder simple views for speed - production Firestore queries
class _CustomersView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder(stream: AdminUserManagementService().streamCustomers(), builder: (context, snap) {
      final docs = snap.data?.docs ?? [];
      return _TableView(title: 'Customers (${docs.length})', docs: docs, isDriver: false);
    });
  }
}

class _DriversView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder(stream: AdminUserManagementService().streamDrivers(), builder: (context, snap) {
      final docs = snap.data?.docs ?? [];
      return _TableView(title: 'Drivers (${docs.length})', docs: docs, isDriver: true);
    });
  }
}

class _TableView extends StatelessWidget {
  final String title;
  final List<dynamic> docs;
  final bool isDriver;
  const _TableView({required this.title, required this.docs, required this.isDriver});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: AppTextStyles.h2),
          const SizedBox(height: 16),
          Expanded(
            child: Container(
              decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
              child: ListView.separated(
                itemCount: docs.length,
                separatorBuilder: (_, __) => const Divider(color: AppColors.divider, height: 1),
                itemBuilder: (context, i) {
                  final data = docs[i].data() as Map<String, dynamic>;
                  return ListTile(
                    leading: CircleAvatar(backgroundColor: AppColors.surfaceVariant, child: Text((data['name'] ?? 'U')[0], style: const TextStyle(color: Colors.white))),
                    title: Text(data['name'] ?? 'Unknown', style: AppTextStyles.label),
                    subtitle: Text('${data['phone'] ?? ''} • ${data['isBanned'] == true ? 'BANNED' : 'Active'}', style: AppTextStyles.bodySmall),
                    trailing: PopupMenuButton(itemBuilder: (c) => [PopupMenuItem(child: Text(isDriver ? 'View KYC' : 'View Rides')), PopupMenuItem(child: Text(data['isBanned'] == true ? 'Unban' : 'Ban'))], onSelected: (v) {}),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _KycApprovalView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final vm = context.watch<AdminKycViewModel>();
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [Text('KYC Approval Queue', style: AppTextStyles.h2), const Spacer(), ElevatedButton(onPressed: () => vm.loadPending(), child: const Text('Refresh'))]),
          const SizedBox(height: 16),
          Expanded(
            child: StreamBuilder(stream: AdminKycService().streamPendingKyc(), builder: (context, snap) {
              final docs = snap.data ?? [];
              return ListView.builder(
                itemCount: docs.length,
                itemBuilder: (context, i) {
                  final doc = docs[i];
                  final data = doc.data() as Map<String, dynamic>;
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
                    child: Row(
                      children: [
                        CircleAvatar(child: Text((data['name'] ?? 'D')[0])),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(data['name'] ?? 'Driver', style: AppTextStyles.label), Text('${data['phone']} • ${data['kycStatus']}', style: AppTextStyles.bodySmall)])),
                        ElevatedButton(onPressed: () => Navigator.pushNamed(context, '/admin-kyc-detail', arguments: doc.id), style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryOrange), child: Text('Review', style: AppTextStyles.bodySmall.copyWith(color: Colors.white))),
                      ],
                    ),
                  );
                },
              );
            }),
          ),
        ],
      ),
    );
  }
}

class _RidesMonitoringView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder(stream: AdminRideMonitoringService().streamActiveRides(), builder: (context, snap) {
      final docs = snap.data?.docs ?? [];
      return Padding(padding: const EdgeInsets.all(24), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Live Rides Monitoring (${docs.length})', style: AppTextStyles.h2), const SizedBox(height: 16), Expanded(child: ListView.builder(itemCount: docs.length, itemBuilder: (c, i) {
        final data = docs[i].data() as Map<String, dynamic>;
        return ListTile(tileColor: AppColors.surface, title: Text('${data['pickup']?['name']} → ${data['destination']?['name']}', style: AppTextStyles.label), subtitle: Text('₹${data['fare']} • ${data['status']} • ${data['category']}', style: AppTextStyles.bodySmall));
      }))]));
    });
  }
}

class _EarningsView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(padding: const EdgeInsets.all(24), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Earnings & Commission', style: AppTextStyles.h2), const SizedBox(height: 16), GridView.count(crossAxisCount: 3, shrinkWrap: true, crossAxisSpacing: 16, mainAxisSpacing: 16, children: [_StatCard(title: 'Total Earnings', value: '₹12,450', icon: Icons.currency_rupee_rounded, color: AppColors.success), _StatCard(title: 'Commission (10%)', value: '₹1,245', icon: Icons.percent_rounded, color: AppColors.primaryOrange), _StatCard(title: 'Driver Payouts', value: '₹11,205', icon: Icons.payments_rounded, color: AppColors.info)])]));
  }
}

class _CouponsView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(padding: const EdgeInsets.all(24), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Text('Coupons & Promo Codes', style: AppTextStyles.h2), const Spacer(), ElevatedButton.icon(onPressed: () {}, icon: const Icon(Icons.add_rounded), label: const Text('Create Coupon'), style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryOrange))]), const SizedBox(height: 16), Expanded(child: Container(decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)), child: const Center(child: Text('No coupons - Create first coupon for Nagina'))))]));
  }
}

class _SupportTicketsView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder(stream: AdminSupportService().streamTickets(), builder: (context, snap) {
      final tickets = snap.data ?? [];
      return Padding(padding: const EdgeInsets.all(24), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Support Tickets (${tickets.length})', style: AppTextStyles.h2), const SizedBox(height: 16), Expanded(child: ListView.builder(itemCount: tickets.length, itemBuilder: (c, i) {
        final t = tickets[i];
        return ListTile(tileColor: AppColors.surface, title: Text(t.subject, style: AppTextStyles.label), subtitle: Text('${t.userType} • ${t.status} • ${t.priority}', style: AppTextStyles.bodySmall));
      }))]));
    });
  }
}
