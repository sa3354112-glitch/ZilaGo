import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../viewmodels/onboarding_viewmodel.dart';
import '../../widgets/primary_button.dart';

class OnboardingView extends StatelessWidget {
  const OnboardingView({super.key});

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<OnboardingViewModel>();
    final w = MediaQuery.of(context).size.width;

    final pages = [
      _OnboardPage(
        icon: Icons.location_on_rounded,
        title: 'Apni Zila Ki Sawari',
        desc: 'Nagina, Bijnor ke liye bani local ride service. Fast, safe aur affordable.',
        gradient: [AppColors.primaryOrange, AppColors.primaryPurple],
      ),
      _OnboardPage(
        icon: Icons.groups_rounded,
        title: 'Local Drivers, Apne Log',
        desc: 'Aapke sheher ke trusted drivers, jo har gali ko jaante hain.',
        gradient: [AppColors.primaryPurple, AppColors.primaryPurpleLight],
      ),
      _OnboardPage(
        icon: Icons.electric_rickshaw_rounded,
        title: 'Ek Tap Par Ride',
        desc: 'Auto, E-Rickshaw, Bike ya Cab - sab kuch ZilaGo par, 24x7.',
        gradient: [AppColors.primaryOrangeLight, AppColors.primaryOrange],
      ),
    ];

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            // Skip
            Align(
              alignment: Alignment.topRight,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: TextButton(
                  onPressed: () => vm.skip(context),
                  child: Text('Skip', style: AppTextStyles.bodySmall.copyWith(color: AppColors.textSecondary)),
                ),
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: vm.pageController,
                onPageChanged: vm.onPageChanged,
                itemCount: pages.length,
                itemBuilder: (_, i) => pages[i],
              ),
            ),
            // Dots
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(3, (i) {
                final isActive = i == vm.currentIndex;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: isActive ? 24 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: isActive ? AppColors.primaryOrange : AppColors.surfaceVariant,
                    borderRadius: BorderRadius.circular(4),
                  ),
                );
              }),
            ),
            const SizedBox(height: 32),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: w < 360 ? 16 : 24),
              child: PrimaryButton(
                text: vm.currentIndex == 2 ? 'Get Started' : 'Next',
                onPressed: () {
                  if (vm.currentIndex == 2) {
                    vm.finish(context);
                  } else {
                    vm.nextPage();
                  }
                },
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

class _OnboardPage extends StatelessWidget {
  final IconData icon;
  final String title;
  final String desc;
  final List<Color> gradient;

  const _OnboardPage({required this.icon, required this.title, required this.desc, required this.gradient});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: gradient, begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(32),
            ),
            child: Icon(icon, size: 56, color: Colors.white),
          ),
          const SizedBox(height: 40),
          Text(title, style: AppTextStyles.onboardingTitle, textAlign: TextAlign.center),
          const SizedBox(height: 16),
          Text(desc, style: AppTextStyles.onboardingDesc, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}
