import 'package:flutter/material.dart';
import '../utils/constants.dart';
import '../utils/app_routes.dart';

/// Splash Controller - MVVM
/// Handles business logic separately from UI
class SplashController extends ChangeNotifier {
  bool _isLoading = true;
  bool get isLoading => _isLoading;

  /// Navigate to Login after delay
  void initSplash(BuildContext context) {
    Future.delayed(AppConstants.splashDuration, () {
      if (context.mounted) {
        _isLoading = false;
        notifyListeners();
        Navigator.pushReplacementNamed(context, AppRoutes.login);
      }
    });
  }
}
