import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../viewmodels/admin/admin_viewmodels.dart';
import '../../views/admin/auth/admin_login_view.dart';
import '../../views/admin/dashboard/admin_dashboard_view.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ZilaGoAdminApp());
}

class ZilaGoAdminApp extends StatelessWidget {
  const ZilaGoAdminApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AdminAuthViewModel()),
        ChangeNotifierProvider(create: (_) => AdminDashboardViewModel()),
        ChangeNotifierProvider(create: (_) => AdminKycViewModel()),
      ],
      child: MaterialApp(
        title: 'ZilaGo Admin - Nagina',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.darkTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.dark,
        initialRoute: '/admin-login',
        routes: {
          '/admin-login': (_) => const AdminLoginView(),
          '/admin-dashboard': (_) => const AdminDashboardView(),
        },
      ),
    );
  }
}
