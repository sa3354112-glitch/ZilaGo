import 'package:flutter/material.dart';

/// ZilaGo - Premium Color Palette
/// Orange + Purple + Black premium theme
class AppColors {
  AppColors._();

  // Primary Brand Colors
  static const Color primaryOrange = Color(0xFFFF6B00); // ZilaGo Saffron
  static const Color primaryOrangeLight = Color(0xFFFF8C38);
  static const Color primaryOrangeDark = Color(0xFFE65100);

  static const Color primaryPurple = Color(0xFF5B21B6); // Deep Purple
  static const Color primaryPurpleLight = Color(0xFF7C3AED);
  static const Color primaryPurpleDark = Color(0xFF1E1B4B); // Indigo dark

  // Background - Dark Theme
  static const Color background = Color(0xFF0A0A0A); // Premium Black
  static const Color backgroundLight = Color(0xFF141414);
  static const Color surface = Color(0xFF1E1E1E);
  static const Color surfaceVariant = Color(0xFF2A2A2A);
  static const Color surfaceElevated = Color(0xFF323232);

  // Gradient
  static const LinearGradient primaryGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [primaryOrange, primaryPurple],
  );

  static const LinearGradient splashGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Color(0xFF0A0A0A), Color(0xFF1E1B4B), Color(0xFF0A0A0A)],
  );

  static const LinearGradient logoGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [primaryOrange, primaryOrangeLight, primaryPurpleLight],
  );

  // Text
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFFA1A1AA);
  static const Color textTertiary = Color(0xFF71717A);
  static const Color textOnPrimary = Color(0xFFFFFFFF);

  // Border & Divider
  static const Color border = Color(0xFF27272A);
  static const Color divider = Color(0xFF27272A);

  // Status
  static const Color success = Color(0xFF22C55E);
  static const Color error = Color(0xFFEF4444);
  static const Color warning = Color(0xFFF59E0B);
}
