import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'app_colors.dart';

/// ZilaGo Typography - Premium & Modern
class AppTextStyles {
  AppTextStyles._();

  static final _baseFont = GoogleFonts.plusJakartaSans;

  // Display - For Logo
  static TextStyle get logoLarge => _baseFont(
        fontSize: 42,
        fontWeight: FontWeight.w800,
        letterSpacing: -1.5,
        color: AppColors.textPrimary,
      );

  static TextStyle get logoMedium => _baseFont(
        fontSize: 32,
        fontWeight: FontWeight.w800,
        letterSpacing: -1.0,
        color: AppColors.textPrimary,
      );

  // Tagline
  static TextStyle get tagline => _baseFont(
        fontSize: 14,
        fontWeight: FontWeight.w500,
        letterSpacing: 2.5,
        color: AppColors.textSecondary,
      );

  static TextStyle get taglineSmall => _baseFont(
        fontSize: 11,
        fontWeight: FontWeight.w600,
        letterSpacing: 3.0,
        color: AppColors.textTertiary,
      );

  // Headings
  static TextStyle get h1 => _baseFont(
        fontSize: 28,
        fontWeight: FontWeight.w700,
        color: AppColors.textPrimary,
      );

  static TextStyle get h2 => _baseFont(
        fontSize: 22,
        fontWeight: FontWeight.w600,
        color: AppColors.textPrimary,
      );

  static TextStyle get body => _baseFont(
        fontSize: 16,
        fontWeight: FontWeight.w400,
        color: AppColors.textSecondary,
      );

  static TextStyle get bodySmall => _baseFont(
        fontSize: 13,
        fontWeight: FontWeight.w400,
        color: AppColors.textTertiary,
      );

  // For Coming Soon
  static TextStyle get comingSoon => _baseFont(
        fontSize: 24,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.5,
        color: AppColors.textPrimary,
      );
}
