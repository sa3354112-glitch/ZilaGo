import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/ride/ride_model.dart';
import '../models/ride/place_model.dart';
import '../models/ride/ride_category_model.dart';

/// Ride Repository - Firestore + Mock for Phase 3
class RideRepository {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // In-memory ride history for demo (replace with Firestore in production)
  final List<RideModel> _mockHistory = [];

  Future<RideModel> bookRide({
    required String userId,
    required PlaceModel pickup,
    required PlaceModel destination,
    required RideCategoryModel category,
    required double distance,
    required double duration,
    required double fare,
  }) async {
    final ride = RideModel(
      id: 'ride_${DateTime.now().millisecondsSinceEpoch}',
      userId: userId,
      pickup: pickup,
      destination: destination,
      category: category,
      status: RideStatus.searching,
      distanceKm: distance,
      durationMin: duration,
      fare: fare,
      createdAt: DateTime.now(),
    );

    // Mock save to Firestore
    try {
      await _firestore.collection('rides').doc(ride.id).set(ride.toJson());
    } catch (e) {
      // Firestore not configured yet - use local
      _mockHistory.insert(0, ride);
    }

    return ride;
  }

  Future<RideModel> updateRideStatus(String rideId, RideStatus status, {DriverModel? driver}) async {
    // Mock update
    final index = _mockHistory.indexWhere((r) => r.id == rideId);
    if (index != -1) {
      final updated = _mockHistory[index].copyWith(status: status, driver: driver, acceptedAt: status == RideStatus.accepted ? DateTime.now() : null);
      _mockHistory[index] = updated;
      return updated;
    }

    // If not in mock, create dummy
    throw Exception('Ride not found');
  }

  Future<void> cancelRide(String rideId, String reason) async {
    final index = _mockHistory.indexWhere((r) => r.id == rideId);
    if (index != -1) {
      _mockHistory[index] = _mockHistory[index].copyWith(status: RideStatus.cancelled, cancelReason: reason);
    }
    try {
      await _firestore.collection('rides').doc(rideId).update({'status': 'cancelled', 'cancelReason': reason});
    } catch (_) {}
  }

  Future<List<RideModel>> getRideHistory(String userId) async {
    try {
      final snap = await _firestore.collection('rides').where('userId', isEqualTo: userId).orderBy('createdAt', descending: true).get();
      return snap.docs.map((d) {
        // Simplified parsing for demo
        return _mockHistory.firstWhere((r) => r.id == d.id, orElse: () => _mockHistory.first);
      }).toList();
    } catch (_) {
      // Return mock history with sample rides
      if (_mockHistory.isEmpty) {
        return _generateMockHistory(userId);
      }
      return _mockHistory;
    }
  }

  List<RideModel> _generateMockHistory(String userId) {
    final pickup = PlaceModel(id: 'bus_stand', name: 'Bus Stand, Nagina', address: 'Nagina', lat: 29.444, lng: 78.440);
    final dest = PlaceModel(id: 'kotwali', name: 'Kotwali, Nagina', address: 'Nagina', lat: 29.447, lng: 78.438);
    final cat = RideCategoryModel.fromType(RideCategoryType.auto);
    return List.generate(5, (i) {
      return RideModel(
        id: 'history_$i',
        userId: userId,
        pickup: pickup,
        destination: dest,
        category: cat,
        status: i == 0 ? RideStatus.completed : RideStatus.completed,
        distanceKm: 2.5 + i * 0.5,
        durationMin: 8 + i * 2,
        fare: 45 + i * 10,
        createdAt: DateTime.now().subtract(Duration(days: i)),
        completedAt: DateTime.now().subtract(Duration(days: i)),
        driver: DriverModel.mock(i, RideCategoryType.auto),
      );
    });
  }

  // Favorites
  Future<List<PlaceModel>> getFavoritePlaces(String userId) async {
    // Mock favorites
    return [
      FavoritePlaceModel(id: 'home', name: 'Home', address: 'Puraini, Nagina', lat: 29.450, lng: 78.445, placeType: 'home'),
      FavoritePlaceModel(id: 'work', name: 'Work', address: 'Bus Stand, Nagina', lat: 29.444, lng: 78.440, placeType: 'work'),
    ];
  }

  Future<void> saveFavoritePlace(String userId, PlaceModel place) async {
    try {
      await _firestore.collection('users').doc(userId).collection('favorites').doc(place.id).set(place.toJson());
    } catch (_) {}
  }
}
