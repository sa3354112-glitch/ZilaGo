import '../services/auth_service.dart';
import '../models/user_model_new.dart';

/// Repository Pattern - Clean Architecture
/// Handles data logic between ViewModel and Service
class AuthRepository {
  final AuthService _authService;

  AuthRepository({AuthService? authService}) : _authService = authService ?? AuthService();

  // Phone Auth
  Future<void> sendOTP({
    required String phone,
    required Function(String) onCodeSent,
    required Function(String) onError,
    required Function() onAutoVerified,
  }) {
    final fullPhone = phone.startsWith('+91') ? phone : '+91$phone';
    return _authService.sendOTP(
      phoneNumber: fullPhone,
      onCodeSent: onCodeSent,
      onError: onError,
      onAutoVerified: onAutoVerified,
    );
  }

  Future<UserModel?> verifyOTPAndGetUser(String otp, UserType userType) async {
    final cred = await _authService.verifyOTP(otp);
    final uid = cred.user!.uid;
    final existing = await _authService.getUserFromFirestore(uid);
    if (existing != null) return existing;

    // Create temp user if new
    final newUser = UserModel(
      uid: uid,
      name: cred.user?.displayName ?? '',
      phone: cred.user?.phoneNumber ?? '',
      userType: userType,
      createdAt: DateTime.now(),
      isProfileComplete: false,
    );
    await _authService.saveUserToFirestore(newUser);
    return newUser;
  }

  Future<UserModel?> signInWithEmail(String email, String pass) async {
    final cred = await _authService.signInWithEmail(email, pass);
    return await _authService.getUserFromFirestore(cred.user!.uid);
  }

  Future<UserModel?> signUpWithEmail(String email, String pass, UserType type, String name, String phone) async {
    final cred = await _authService.signUpWithEmail(email, pass);
    final user = UserModel(
      uid: cred.user!.uid,
      name: name,
      phone: phone,
      email: email,
      userType: type,
      createdAt: DateTime.now(),
      isProfileComplete: false,
    );
    await _authService.saveUserToFirestore(user);
    return user;
  }

  Future<void> sendPasswordReset(String email) => _authService.sendPasswordResetEmail(email);

  Future<UserModel?> signInWithGoogle(UserType type) async {
    final cred = await _authService.signInWithGoogle();
    if (cred == null) return null;
    final existing = await _authService.getUserFromFirestore(cred.user!.uid);
    if (existing != null) return existing;

    final newUser = UserModel(
      uid: cred.user!.uid,
      name: cred.user!.displayName ?? '',
      phone: cred.user!.phoneNumber ?? '',
      email: cred.user!.email,
      photoUrl: cred.user!.photoURL,
      userType: type,
      createdAt: DateTime.now(),
      isProfileComplete: false,
    );
    await _authService.saveUserToFirestore(newUser);
    return newUser;
  }

  Future<void> completeProfile(UserModel user) async {
    final updated = user.copyWith(isProfileComplete: true);
    await _authService.saveUserToFirestore(updated);
  }

  Future<void> logout() => _authService.signOut();

  Future<UserModel?> getCurrentUserModel() async {
    final fbUser = _authService.currentUser;
    if (fbUser == null) return null;
    return await _authService.getUserFromFirestore(fbUser.uid);
  }
}
