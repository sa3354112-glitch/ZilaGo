import 'package:flutter/material.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_text_styles.dart';
import '../../utils/constants.dart';

/// Phase 1: Empty Login Screen
/// Requirement: Only AppBar + "Coming Soon"
/// No design yet - placeholder for Phase 2
class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        title: Text(
          AppConstants.appName,
          style: AppTextStyles.h2.copyWith(fontWeight: FontWeight.w800),
        ),
        centerTitle: true,
        // Premium orange accent line bottom
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            decoration: const BoxDecoration(
              gradient: AppColors.primaryGradient,
            ),
          ),
        ),
      ),
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: AppColors.splashGradient,
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Icon placeholder
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.border),
                ),
                child: const Icon(
                  Icons.construction_rounded,
                  size: 36,
                  color: AppColors.primaryOrange,
                ),
              ),
              const SizedBox(height: 24),
              Text(
                AppStrings.comingSoon,
                style: AppTextStyles.comingSoon,
              ),
              const SizedBox(height: 12),
              Text(
                AppStrings.loginComingSoonDesc,
                style: AppTextStyles.bodySmall,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.border),
                ),
                child: Text(
                  'Phase 2 • Authentication',
                  style: AppTextStyles.taglineSmall,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
