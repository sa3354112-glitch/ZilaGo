import 'package:flutter/material.dart';
import '../core/constants/app_constants.dart';

class SplashViewModel extends ChangeNotifier {
  bool _isLoading = true;
  bool get isLoading => _isLoading;

  void init(BuildContext context) {
    Future.delayed(AppConstants.splashDuration, () {
      if (!context.mounted) return;
      // Check onboarding
      final seenOnboarding = false; // TODO: read from SharedPreferences
      if (!seenOnboarding) {
        Navigator.pushReplacementNamed(context, '/onboarding');
      } else {
        Navigator.pushReplacementNamed(context, '/customer-login');
      }
    });
  }
}
