import 'package:flutter/material.dart';
import '../repositories/auth_repository.dart';
import '../models/user_model_new.dart';

enum AuthStatus { initial, loading, success, error }

class AuthViewModel extends ChangeNotifier {
  final AuthRepository _repo;
  AuthViewModel({AuthRepository? repository}) : _repo = repository ?? AuthRepository();

  AuthStatus _status = AuthStatus.initial;
  String? _errorMessage;
  String? _verificationId;
  UserType _selectedUserType = UserType.customer;
  UserModel? _currentUser;

  // Getters
  AuthStatus get status => _status;
  String? get errorMessage => _errorMessage;
  String? get verificationId => _verificationId;
  UserType get selectedUserType => _selectedUserType;
  UserModel? get currentUser => _currentUser;
  bool get isLoading => _status == AuthStatus.loading;

  void setUserType(UserType type) {
    _selectedUserType = type;
    notifyListeners();
  }

  void _setLoading() {
    _status = AuthStatus.loading;
    _errorMessage = null;
    notifyListeners();
  }

  void _setError(String message) {
    _status = AuthStatus.error;
    _errorMessage = message;
    notifyListeners();
  }

  void _setSuccess() {
    _status = AuthStatus.success;
    notifyListeners();
  }

  // ========== PHONE AUTH ==========
  Future<void> sendOTP(String phone) async {
    _setLoading();
    try {
      await _repo.sendOTP(
        phone: phone,
        onCodeSent: (vid) {
          _verificationId = vid;
          _setSuccess();
        },
        onError: (err) => _setError(err),
        onAutoVerified: () => _setSuccess(),
      );
    } catch (e) {
      _setError(e.toString());
    }
  }

  Future<bool> verifyOTP(String otp, BuildContext context) async {
    _setLoading();
    try {
      final user = await _repo.verifyOTPAndGetUser(otp, _selectedUserType);
      _currentUser = user;
      _setSuccess();
      return true;
    } catch (e) {
      _setError('Invalid OTP: ${e.toString()}');
      return false;
    }
  }

  // ========== EMAIL ==========
  Future<bool> loginWithEmail(String email, String pass) async {
    _setLoading();
    try {
      final user = await _repo.signInWithEmail(email, pass);
      _currentUser = user;
      _setSuccess();
      return user != null;
    } catch (e) {
      _setError('Login failed: ${e.toString()}');
      return false;
    }
  }

  Future<bool> signUpWithEmail(String email, String pass, String name, String phone) async {
    _setLoading();
    try {
      final user = await _repo.signUpWithEmail(email, pass, _selectedUserType, name, phone);
      _currentUser = user;
      _setSuccess();
      return true;
    } catch (e) {
      _setError('Signup failed: ${e.toString()}');
      return false;
    }
  }

  Future<bool> sendPasswordReset(String email) async {
    _setLoading();
    try {
      await _repo.sendPasswordReset(email);
      _setSuccess();
      return true;
    } catch (e) {
      _setError(e.toString());
      return false;
    }
  }

  // ========== GOOGLE ==========
  Future<bool> loginWithGoogle() async {
    _setLoading();
    try {
      final user = await _repo.signInWithGoogle(_selectedUserType);
      if (user == null) {
        _status = AuthStatus.initial;
        notifyListeners();
        return false;
      }
      _currentUser = user;
      _setSuccess();
      return true;
    } catch (e) {
      _setError('Google Sign-In failed');
      return false;
    }
  }

  // ========== PROFILE ==========
  Future<bool> completeProfile({required String name, String? email, String? vehicleNo, String? license, String? area}) async {
    if (_currentUser == null) return false;
    _setLoading();
    try {
      final updated = _currentUser!.copyWith(
        name: name,
        email: email,
        vehicleNumber: vehicleNo,
        licenseNumber: license,
        area: area,
        isProfileComplete: true,
      );
      await _repo.completeProfile(updated);
      _currentUser = updated;
      _setSuccess();
      return true;
    } catch (e) {
      _setError(e.toString());
      return false;
    }
  }

  Future<void> logout() async {
    await _repo.logout();
    _currentUser = null;
    _status = AuthStatus.initial;
    notifyListeners();
  }

  Future<void> loadCurrentUser() async {
    _currentUser = await _repo.getCurrentUserModel();
    notifyListeners();
  }
}
