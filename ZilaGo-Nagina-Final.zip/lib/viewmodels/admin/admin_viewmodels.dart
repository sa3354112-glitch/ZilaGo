import 'package:flutter/material.dart';
import '../../services/admin/admin_services.dart';
import '../../models/admin/admin_models.dart';

class AdminAuthViewModel extends ChangeNotifier {
  final AdminAuthService _authService = AdminAuthService();
  bool _isLoading = false;
  AdminUserModel? _admin;
  String? _error;

  bool get isLoading => _isLoading;
  AdminUserModel? get admin => _admin;
  String? get error => _error;

  Future<bool> login(String email, String password) async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      _admin = await _authService.loginAdmin(email, password);
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> logout() async {
    await _authService.logout();
    _admin = null;
    notifyListeners();
  }
}

class AdminDashboardViewModel extends ChangeNotifier {
  final AdminDashboardService _service = AdminDashboardService();
  DashboardStatsModel? _stats;
  bool _loading = true;

  DashboardStatsModel? get stats => _stats;
  bool get loading => _loading;

  Future<void> loadStats() async {
    _loading = true;
    notifyListeners();
    _stats = await _service.getDashboardStats();
    _loading = false;
    notifyListeners();
  }

  Stream<DashboardStatsModel> streamStats() => _service.streamStats();
}

class AdminKycViewModel extends ChangeNotifier {
  final AdminKycService _service = AdminKycService();
  bool _loading = false;
  List<dynamic> _pending = [];

  bool get loading => _loading;
  List<dynamic> get pending => _pending;

  Future<void> loadPending() async {
    _loading = true;
    notifyListeners();
    _pending = await _service.getPendingKycRequests();
    _loading = false;
    notifyListeners();
  }

  Future<void> approve(String driverId, String docType) async {
    await _service.approveKycDocument(driverId: driverId, docType: docType);
    await loadPending();
  }

  Future<void> reject(String driverId, String docType, String reason) async {
    await _service.rejectKycDocument(driverId: driverId, docType: docType, reason: reason);
    await loadPending();
  }
}
