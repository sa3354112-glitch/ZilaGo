import 'package:flutter/material.dart';

class OnboardingViewModel extends ChangeNotifier {
  int _currentIndex = 0;
  int get currentIndex => _currentIndex;

  final PageController pageController = PageController();

  void onPageChanged(int index) {
    _currentIndex = index;
    notifyListeners();
  }

  void nextPage() {
    if (_currentIndex < 2) {
      pageController.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
    }
  }

  void skip(BuildContext context) {
    Navigator.pushReplacementNamed(context, '/customer-login');
  }

  void finish(BuildContext context) {
    // TODO: Save onboarding seen to SharedPreferences
    Navigator.pushReplacementNamed(context, '/customer-login');
  }

  @override
  void dispose() {
    pageController.dispose();
    super.dispose();
  }
}
