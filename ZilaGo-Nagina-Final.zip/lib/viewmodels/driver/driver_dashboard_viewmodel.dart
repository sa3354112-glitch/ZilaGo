import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../../services/driver/driver_location_service.dart';
import '../../services/driver/driver_ride_service.dart';
import '../../services/driver/vehicle_service.dart';
import '../../services/driver/earnings_service.dart';
import '../../models/driver/vehicle_model.dart';
import '../../models/driver/driver_ride_model.dart';

class DriverDashboardViewModel extends ChangeNotifier {
  final DriverLocationService _locationService = DriverLocationService();
  final DriverRideService _rideService = DriverRideService();
  final VehicleService _vehicleService = VehicleService();
  final EarningsService _earningsService = EarningsService();

  bool _isOnline = false;
  bool _isLoading = false;
  VehicleModel? _activeVehicle;
  DriverRideRequestModel? _currentRide;
  List<VehicleModel> _vehicles = [];
  EarningsModel? _earnings;

  bool get isOnline => _isOnline;
  bool get isLoading => _isLoading;
  VehicleModel? get activeVehicle => _activeVehicle;
  DriverRideRequestModel? get currentRide => _currentRide;
  List<VehicleModel> get vehicles => _vehicles;
  EarningsModel? get earnings => _earnings;

  Future<void> initDriver(String driverId) async {
    _isLoading = true;
    notifyListeners();
    try {
      _vehicles = await _vehicleService.getVehicles(driverId);
      if (_vehicles.isNotEmpty) {
        _activeVehicle = _vehicles.firstWhere((v) => v.isActive, orElse: () => _vehicles.first);
      }
      _earnings = await _earningsService.getEarnings(driverId);
      // Check online status from Firestore
      // Assume loaded
    } catch (e) {
      debugPrint('Init driver error: $e');
    }
    _isLoading = false;
    notifyListeners();
  }

  Future<void> toggleOnline(String driverId) async {
    _isLoading = true;
    notifyListeners();
    try {
      if (_isOnline) {
        await _locationService.stopTracking(driverId);
        _isOnline = false;
      } else {
        final perm = await Geolocator.checkPermission();
        if (perm == LocationPermission.denied) await Geolocator.requestPermission();
        await _locationService.startTracking(driverId);
        _isOnline = true;
      }
    } catch (e) {
      debugPrint('Toggle online error: $e');
    }
    _isLoading = false;
    notifyListeners();
  }

  Stream<List<DriverRideRequestModel>> streamRequests(String driverId) {
    if (_activeVehicle == null) return const Stream.empty();
    return _rideService.streamRideRequests(driverId, _activeVehicle!.type.name);
  }

  Stream<DriverRideRequestModel?> streamCurrentRide(String driverId) => _rideService.streamCurrentRide(driverId);

  Future<void> acceptRide(String rideId, String driverId) async {
    _isLoading = true;
    notifyListeners();
    try {
      await _rideService.acceptRide(rideId, driverId);
    } catch (e) {
      debugPrint('Accept error: $e');
    }
    _isLoading = false;
    notifyListeners();
  }

  Future<void> updateStatus(String rideId, DriverRideStatus status) async {
    await _rideService.updateRideStatus(rideId, status);
    if (status == DriverRideStatus.completed) {
      // Add earning
      if (_currentRide != null) {
        await _earningsService.addEarningFromRide(_currentRide!.driverId ?? '', _currentRide!);
      }
    }
  }

  void setCurrentRide(DriverRideRequestModel? ride) {
    _currentRide = ride;
    notifyListeners();
  }

  Stream<EarningsModel> streamEarnings(String driverId) => _earningsService.streamEarnings(driverId);

  Future<List<DriverRideRequestModel>> getRideHistory(String driverId) => _earningsService.getRideHistory(driverId);
}
