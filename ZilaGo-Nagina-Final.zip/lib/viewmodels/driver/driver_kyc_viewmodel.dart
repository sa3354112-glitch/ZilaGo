import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/driver/kyc_service.dart';
import '../../models/driver/kyc_model.dart';

class DriverKycViewModel extends ChangeNotifier {
  final KycService _kycService = KycService();

  bool _isLoading = false;
  DriverKycModel? _kycModel;
  String? _error;

  bool get isLoading => _isLoading;
  DriverKycModel? get kycModel => _kycModel;
  String? get error => _error;

  Future<void> loadKyc(String driverId) async {
    _isLoading = true;
    notifyListeners();
    try {
      _kycModel = await _kycService.getKycStatus(driverId);
    } catch (e) {
      _error = e.toString();
    }
    _isLoading = false;
    notifyListeners();
  }

  Future<bool> uploadDocument({required String driverId, required KycDocumentType type, required String documentNumber, required bool isFrontImage, required dynamic imageSource}) async {
    _isLoading = true;
    notifyListeners();
    try {
      final picked = await _kycService.pickImage(source: imageSource);
      if (picked == null) {
        _isLoading = false;
        notifyListeners();
        return false;
      }
      final url = await _kycService.uploadDocumentImage(driverId: driverId, type: type, file: picked, isFront: isFrontImage);

      final existing = _kycModel;
      KycDocumentModel? existingDoc;
      switch (type) {
        case KycDocumentType.aadhaar:
          existingDoc = existing?.aadhaar;
          break;
        case KycDocumentType.license:
          existingDoc = existing?.license;
          break;
        case KycDocumentType.rc:
          existingDoc = existing?.rc;
          break;
        case KycDocumentType.insurance:
          existingDoc = existing?.insurance;
          break;
        default:
          break;
      }

      final newDoc = KycDocumentModel(
        type: type,
        documentNumber: documentNumber,
        frontImageUrl: isFrontImage ? url : (existingDoc?.frontImageUrl ?? url),
        backImageUrl: !isFrontImage ? url : existingDoc?.backImageUrl,
        status: KycStatus.underReview,
        uploadedAt: DateTime.now(),
      );

      await _kycService.saveKycDocument(driverId: driverId, document: newDoc);
      await loadKyc(driverId);
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Stream<DriverKycModel> streamKyc(String driverId) => _kycService.streamKycStatus(driverId);
}
