import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../../core/constants/map_constants.dart';
import '../../models/ride/place_model.dart';
import '../../models/ride/ride_category_model.dart';
import '../../models/ride/ride_model.dart';
import '../../services/maps/location_service.dart';
import '../../services/maps/map_service.dart';
import '../../repositories/ride/ride_repository.dart';

/// Home ViewModel - Manages Maps + Ride Flow
class CustomerHomeViewModel extends ChangeNotifier {
  final LocationService _locationService = LocationService.instance;
  final MapService _mapService = MapService.instance;
  final RideRepository _rideRepo = RideRepository();

  // Map
  GoogleMapController? _mapController;
  LatLng _currentLatLng = const LatLng(MapConstants.naginaLat, MapConstants.naginaLng);
  PlaceModel? _currentPlace;
  PlaceModel? _pickupPlace;
  PlaceModel? _destinationPlace;
  Set<Marker> _markers = {};
  Set<Polyline> _polylines = {};
  List<DriverModel> _nearbyDrivers = [];

  // Ride
  List<RideCategoryModel> _rideCategories = [];
  RideCategoryModel? _selectedCategory;
  double _distanceKm = 0;
  double _durationMin = 0;
  double _estimatedFare = 0;
  RideModel? _currentRide;

  // State
  bool _isLoadingLocation = true;
  bool _isSearching = false;
  int _bottomSheetIndex = 0; // 0: search, 1: categories, 2: confirm, 3: searching driver, 4: tracking

  // Getters
  LatLng get currentLatLng => _currentLatLng;
  PlaceModel? get currentPlace => _currentPlace;
  PlaceModel? get pickupPlace => _pickupPlace;
  PlaceModel? get destinationPlace => _destinationPlace;
  Set<Marker> get markers => _markers;
  Set<Polyline> get polylines => _polylines;
  List<DriverModel> get nearbyDrivers => _nearbyDrivers;
  List<RideCategoryModel> get rideCategories => _rideCategories;
  RideCategoryModel? get selectedCategory => _selectedCategory;
  double get distanceKm => _distanceKm;
  double get durationMin => _durationMin;
  double get estimatedFare => _estimatedFare;
  RideModel? get currentRide => _currentRide;
  bool get isLoadingLocation => _isLoadingLocation;
  bool get isSearching => _isSearching;
  int get bottomSheetIndex => _bottomSheetIndex;

  CustomerHomeViewModel() {
    _initRideCategories();
    _initLocation();
  }

  void _initRideCategories() {
    _rideCategories = [
      RideCategoryModel.fromType(RideCategoryType.bike, selected: false),
      RideCategoryModel.fromType(RideCategoryType.auto, selected: true),
      RideCategoryModel.fromType(RideCategoryType.miniMetro),
      RideCategoryModel.fromType(RideCategoryType.cab),
      RideCategoryModel.fromType(RideCategoryType.xl),
    ];
    _selectedCategory = _rideCategories[1];
    notifyListeners();
  }

  Future<void> _initLocation() async {
    _isLoadingLocation = true;
    notifyListeners();

    final place = await _locationService.getCurrentPlace();
    if (place != null) {
      _currentPlace = place;
      _pickupPlace = place;
      _currentLatLng = LatLng(place.lat, place.lng);
      _updateMarkers();
    }

    // Mock nearby drivers
    _nearbyDrivers = _mapService.getNearbyDrivers(RideCategoryType.auto, count: 6);
    _updateMarkers();

    _isLoadingLocation = false;
    notifyListeners();

    _animateToCurrentLocation();
  }

  void setMapController(GoogleMapController controller) {
    _mapController = controller;
  }

  void _animateToCurrentLocation() {
    _mapController?.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(target: _currentLatLng, zoom: MapConstants.defaultZoom)));
  }

  void _updateMarkers() {
    _markers = _mapService.createMarkers(pickup: _pickupPlace, destination: _destinationPlace, nearbyDrivers: _nearbyDrivers);
    notifyListeners();
  }

  void selectCategory(RideCategoryType type) {
    _rideCategories = _rideCategories.map((c) => c.copyWith(isSelected: c.type == type)).toList();
    _selectedCategory = _rideCategories.firstWhere((c) => c.type == type);
    _calculateFare();
    _nearbyDrivers = _mapService.getNearbyDrivers(type, count: 6);
    _updateMarkers();
  }

  void setPickup(PlaceModel place) {
    _pickupPlace = place;
    _calculateRoute();
  }

  void setDestination(PlaceModel place) {
    _destinationPlace = place;
    _calculateRoute();
  }

  Future<void> _calculateRoute() async {
    if (_pickupPlace == null || _destinationPlace == null) return;

    _isSearching = true;
    notifyListeners();

    // Calculate distance
    final distance = _locationService.calculateDistance(_pickupPlace!.lat, _pickupPlace!.lng, _destinationPlace!.lat, _destinationPlace!.lng);
    _distanceKm = distance == 0 ? 2.5 : distance; // minimum 2.5km for demo
    _durationMin = _mapService.estimateDuration(_distanceKm);

    // Polyline
    final points = await _mapService.getPolylinePoints(_pickupPlace!, _destinationPlace!);
    _polylines = {
      Polyline(
        polylineId: const PolylineId('route'),
        points: points,
        color: const Color(0xFFFF6B00),
        width: 5,
        patterns: [],
      ),
    };

    _calculateFare();
    _updateMarkers();

    // Fit bounds
    _fitBounds();

    _isSearching = false;
    notifyListeners();
  }

  void _calculateFare() {
    if (_selectedCategory != null && _distanceKm > 0) {
      _estimatedFare = _mapService.estimateFare(_selectedCategory!, _distanceKm, _durationMin);
    }
    notifyListeners();
  }

  void _fitBounds() {
    if (_pickupPlace == null || _destinationPlace == null) return;
    final bounds = LatLngBounds(
      southwest: LatLng(_pickupPlace!.lat < _destinationPlace!.lat ? _pickupPlace!.lat : _destinationPlace!.lat, _pickupPlace!.lng < _destinationPlace!.lng ? _pickupPlace!.lng : _destinationPlace!.lng),
      northeast: LatLng(_pickupPlace!.lat > _destinationPlace!.lat ? _pickupPlace!.lat : _destinationPlace!.lat, _pickupPlace!.lng > _destinationPlace!.lng ? _pickupPlace!.lng : _destinationPlace!.lng),
    );
    _mapController?.animateCamera(CameraUpdate.newLatLngBounds(bounds, 80));
  }

  // Bottom sheet navigation
  void setBottomSheetIndex(int index) {
    _bottomSheetIndex = index;
    notifyListeners();
  }

  void goToCategorySelection() {
    if (_pickupPlace != null && _destinationPlace != null) {
      setBottomSheetIndex(1);
    }
  }

  void goToConfirmation() => setBottomSheetIndex(2);
  void goToSearching() => setBottomSheetIndex(3);
  void goToTracking() => setBottomSheetIndex(4);
  void goToSearch() => setBottomSheetIndex(0);

  // Book ride flow
  Future<void> bookRide(String userId) async {
    if (_pickupPlace == null || _destinationPlace == null || _selectedCategory == null) return;

    goToSearching();

    // Simulate booking
    final ride = await _rideRepo.bookRide(
      userId: userId,
      pickup: _pickupPlace!,
      destination: _destinationPlace!,
      category: _selectedCategory!,
      distance: _distanceKm,
      duration: _durationMin,
      fare: _estimatedFare,
    );

    _currentRide = ride;
    notifyListeners();

    // Simulate driver acceptance after 4 seconds
    Future.delayed(const Duration(seconds: 4), () async {
      final driver = DriverModel.mock(0, _selectedCategory!.type);
      _currentRide = ride.copyWith(status: RideStatus.accepted, driver: driver, acceptedAt: DateTime.now());
      goToTracking();
      notifyListeners();

      // Simulate driver moving
      _simulateDriverMovement();
    });
  }

  void _simulateDriverMovement() {
    // Mock driver tracking - move driver marker towards pickup
    if (_currentRide?.driver == null) return;
    // In production, listen to Firestore driver location stream
  }

  Future<void> cancelCurrentRide(String reason) async {
    if (_currentRide != null) {
      await _rideRepo.cancelRide(_currentRide!.id, reason);
      _currentRide = _currentRide!.copyWith(status: RideStatus.cancelled, cancelReason: reason);
      goToSearch();
      _polylines = {};
      _destinationPlace = null;
      _updateMarkers();
      notifyListeners();
    }
  }

  // Favorites & History
  List<PlaceModel> _favorites = [];
  List<PlaceModel> get favorites => _favorites;

  Future<void> loadFavorites(String userId) async {
    _favorites = await _rideRepo.getFavoritePlaces(userId);
    notifyListeners();
  }

  void swapPickupDestination() {
    final temp = _pickupPlace;
    _pickupPlace = _destinationPlace;
    _destinationPlace = temp;
    _calculateRoute();
  }
}
