/// ZilaGo App Constants
class AppConstants {
  AppConstants._();

  // App Info
  static const String appName = 'ZilaGo';
  static const String tagline = 'Apni Zila, Apni Sawari';
  static const String taglineEnglish = 'Your District, Your Ride';

  // Splash
  static const Duration splashDuration = Duration(seconds: 3);
  static const Duration animationDuration = Duration(milliseconds: 800);

  // Location
  static const String primaryCity = 'Nagina';
  static const String district = 'Bijnor';
  static const String state = 'Uttar Pradesh';

  // Firebase Collections (Ready for Phase 2)
  static const String usersCollection = 'users';
  static const String driversCollection = 'drivers';
  static const String ridesCollection = 'rides';
}

class AppStrings {
  AppStrings._();
  static const String loading = 'Loading...';
  static const String comingSoon = 'Coming Soon';
  static const String loginComingSoonDesc = 'We are building something amazing for Nagina';
}
