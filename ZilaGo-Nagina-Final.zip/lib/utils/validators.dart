/// Validation Utilities - Production Ready
class AppValidators {
  AppValidators._();

  static String? validatePhone(String? value) {
    if (value == null || value.isEmpty) return 'Phone number required';
    final cleaned = value.replaceAll(RegExp(r'[^0-9]'), '');
    if (cleaned.length != 10) return 'Enter valid 10-digit number';
    if (!RegExp(r'^[6-9]').hasMatch(cleaned)) return 'Enter valid Indian number';
    return null;
  }

  static String? validateEmail(String? value) {
    if (value == null || value.isEmpty) return 'Email required';
    final emailRegex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    if (!emailRegex.hasMatch(value.trim())) return 'Enter valid email';
    return null;
  }

  static String? validatePassword(String? value) {
    if (value == null || value.isEmpty) return 'Password required';
    if (value.length < 6) return 'Minimum 6 characters';
    return null;
  }

  static String? validateName(String? value) {
    if (value == null || value.isEmpty) return 'Name required';
    if (value.trim().length < 2) return 'Enter valid name';
    if (!RegExp(r'^[a-zA-Z\s]+$').hasMatch(value.trim())) return 'Only alphabets allowed';
    return null;
  }

  static String? validateOTP(String? value) {
    if (value == null || value.isEmpty) return 'OTP required';
    if (value.length != 6) return 'Enter 6-digit OTP';
    if (!RegExp(r'^[0-9]+$').hasMatch(value)) return 'Only numbers';
    return null;
  }
}
