import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../models/admin/admin_models.dart';

/// Admin Auth Service - Firebase Auth with custom claims
class AdminAuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<AdminUserModel?> loginAdmin(String email, String password) async {
    final cred = await _auth.signInWithEmailAndPassword(email: email, password: password);
    final uid = cred.user!.uid;

    // Check admin collection
    final adminDoc = await _firestore.collection('admins').doc(uid).get();
    if (!adminDoc.exists) {
      await _auth.signOut();
      throw Exception('Not authorized as admin');
    }

    final admin = AdminUserModel.fromJson({'id': uid, ...adminDoc.data()!});
    if (!admin.isActive) {
      await _auth.signOut();
      throw Exception('Admin account suspended');
    }

    await _firestore.collection('admins').doc(uid).update({'lastLoginAt': Timestamp.now()});
    return admin;
  }

  Future<void> logout() => _auth.signOut();

  Future<AdminUserModel?> getCurrentAdmin() async {
    final user = _auth.currentUser;
    if (user == null) return null;
    final doc = await _firestore.collection('admins').doc(user.uid).get();
    if (!doc.exists) return null;
    return AdminUserModel.fromJson({'id': user.uid, ...doc.data()!});
  }
}

/// Dashboard Service - Real-time stats aggregation
class AdminDashboardService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<DashboardStatsModel> getDashboardStats() async {
    final customersCount = await _firestore.collection('users').where('userType', isEqualTo: 'customer').count().get();
    final driversCount = await _firestore.collection('users').where('userType', isEqualTo: 'driver').count().get();
    final onlineDrivers = await _firestore.collection('drivers').where('isOnline', isEqualTo: true).count().get();
    final activeRides = await _firestore.collection('ride_requests').where('status', whereIn: ['accepted', 'arrived', 'started']).count().get();
    final pendingKyc = await _firestore.collection('drivers').where('kycStatus', isEqualTo: 'underReview').count().get();
    final openTickets = await _firestore.collection('support_tickets').where('status', isEqualTo: 'open').count().get();

    // Today earnings - aggregate from earnings collection
    final todayStart = DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day);
    final todayRidesSnap = await _firestore.collection('ride_requests').where('completedAt', isGreaterThanOrEqualTo: Timestamp.fromDate(todayStart)).where('status', isEqualTo: 'completed').get();

    double todayEarnings = 0;
    for (var doc in todayRidesSnap.docs) {
      todayEarnings += (doc.data()['fare'] as num?)?.toDouble() ?? 0;
    }

    return DashboardStatsModel(
      totalCustomers: customersCount.count ?? 0,
      totalDrivers: driversCount.count ?? 0,
      onlineDrivers: onlineDrivers.count ?? 0,
      activeRides: activeRides.count ?? 0,
      todayRides: todayRidesSnap.size,
      todayEarnings: todayEarnings,
      totalEarnings: todayEarnings * 30, // simplified, in prod use separate aggregation
      commissionEarned: todayEarnings * 0.1,
      pendingKyc: pendingKyc.count ?? 0,
      openTickets: openTickets.count ?? 0,
    );
  }

  Stream<DashboardStatsModel> streamStats() {
    return _firestore.collection('admin_stats').doc('realtime').snapshots().map((doc) {
      if (!doc.exists) return DashboardStatsModel(totalCustomers: 0, totalDrivers: 0, onlineDrivers: 0, activeRides: 0, todayRides: 0, todayEarnings: 0, totalEarnings: 0, commissionEarned: 0, pendingKyc: 0, openTickets: 0);
      return DashboardStatsModel.fromMap(doc.data()!);
    });
  }
}

/// KYC Approval Service
class AdminKycService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<DocumentSnapshot>> getPendingKycRequests() async {
    final snap = await _firestore.collection('drivers').where('kycStatus', isEqualTo: 'underReview').orderBy('updatedAt', descending: true).get();
    return snap.docs;
  }

  Stream<List<DocumentSnapshot>> streamPendingKyc() {
    return _firestore.collection('drivers').where('kycStatus', whereIn: ['pending', 'underReview']).snapshots().map((s) => s.docs);
  }

  Future<void> approveKycDocument({required String driverId, required String docType}) async {
    await _firestore.collection('drivers').doc(driverId).collection('kyc').doc(docType).update({'status': 'approved', 'verifiedAt': Timestamp.now(), 'verifiedBy': FirebaseAuth.instance.currentUser?.uid});
    await _checkAndApproveOverall(driverId);
  }

  Future<void> rejectKycDocument({required String driverId, required String docType, required String reason}) async {
    await _firestore.collection('drivers').doc(driverId).collection('kyc').doc(docType).update({'status': 'rejected', 'rejectionReason': reason, 'verifiedAt': Timestamp.now(), 'verifiedBy': FirebaseAuth.instance.currentUser?.uid});
    await _firestore.collection('drivers').doc(driverId).update({'kycStatus': 'rejected', 'kycRejectionReason': reason});
  }

  Future<void> _checkAndApproveOverall(String driverId) async {
    final kycSnap = await _firestore.collection('drivers').doc(driverId).collection('kyc').get();
    final allApproved = kycSnap.docs.length >= 4 && kycSnap.docs.every((d) => d.data()['status'] == 'approved');
    if (allApproved) {
      await _firestore.collection('drivers').doc(driverId).update({'kycStatus': 'approved', 'isKycApproved': true, 'kycApprovedAt': Timestamp.now()});
      // Notify driver
      await _firestore.collection('notifications').add({'userId': driverId, 'title': 'KYC Approved', 'body': 'Your KYC is approved! You can now go online and accept rides.', 'type': 'kyc_approved', 'createdAt': Timestamp.now(), 'isRead': false});
    }
  }
}

/// Customer & Driver Management
class AdminUserManagementService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<QuerySnapshot> streamCustomers() => _firestore.collection('users').where('userType', isEqualTo: 'customer').snapshots();
  Stream<QuerySnapshot> streamDrivers() => _firestore.collection('drivers').snapshots();

  Future<void> banUser(String userId, String reason) async {
    await _firestore.collection('users').doc(userId).update({'isBanned': true, 'banReason': reason, 'bannedAt': Timestamp.now(), 'bannedBy': FirebaseAuth.instance.currentUser?.uid});
    await _firestore.collection('drivers').doc(userId).update({'isBanned': true, 'banReason': reason}).catchError((_) {});
  }

  Future<void> unbanUser(String userId) async {
    await _firestore.collection('users').doc(userId).update({'isBanned': false, 'banReason': null, 'bannedAt': null});
    await _firestore.collection('drivers').doc(userId).update({'isBanned': false}).catchError((_) {});
  }

  Future<void> suspendDriver(String driverId, int days, String reason) async {
    final until = DateTime.now().add(Duration(days: days));
    await _firestore.collection('drivers').doc(driverId).update({'isSuspended': true, 'suspendedUntil': Timestamp.fromDate(until), 'suspendReason': reason});
  }
}

/// Ride Monitoring
class AdminRideMonitoringService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<QuerySnapshot> streamActiveRides() => _firestore.collection('ride_requests').where('status', whereIn: ['requested', 'accepted', 'arrived', 'started']).orderBy('requestedAt', descending: true).snapshots();
  Stream<QuerySnapshot> streamAllRides() => _firestore.collection('ride_requests').orderBy('requestedAt', descending: true).limit(100).snapshots();

  Future<List<DocumentSnapshot>> getTripHistory({DateTime? start, DateTime? end, String? city}) async {
    Query query = _firestore.collection('ride_requests').where('status', isEqualTo: 'completed').orderBy('completedAt', descending: true);
    if (start != null) query = query.where('completedAt', isGreaterThanOrEqualTo: Timestamp.fromDate(start));
    if (end != null) query = query.where('completedAt', isLessThanOrEqualTo: Timestamp.fromDate(end));
    final snap = await query.limit(100).get();
    return snap.docs;
  }
}
