import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import '../../models/admin/admin_models.dart';

/// Coupon Management
class AdminCouponService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> createCoupon(CouponModel coupon) async => await _firestore.collection('coupons').doc(coupon.id).set(coupon.toJson());
  Future<void> updateCoupon(String id, Map<String, dynamic> data) async => await _firestore.collection('coupons').doc(id).update(data);
  Future<void> deleteCoupon(String id) async => await _firestore.collection('coupons').doc(id).delete();
  Stream<List<CouponModel>> streamCoupons() => _firestore.collection('coupons').orderBy('createdAt', descending: true).snapshots().map((s) => s.docs.map((d) => CouponModel.fromFirestore(d)).toList());

  Future<double> validateAndApplyCoupon(String code, double fare, String city) async {
    final snap = await _firestore.collection('coupons').where('code', isEqualTo: code.toUpperCase()).where('isActive', isEqualTo: true).limit(1).get();
    if (snap.docs.isEmpty) throw Exception('Invalid coupon');
    final coupon = CouponModel.fromFirestore(snap.docs.first);
    if (coupon.expiryDate.isBefore(DateTime.now())) throw Exception('Coupon expired');
    if (coupon.usedCount >= coupon.totalUses) throw Exception('Coupon limit reached');
    if (fare < coupon.minFare) throw Exception('Min fare ₹${coupon.minFare} required');
    double discount = fare * (coupon.discountPercent / 100);
    if (discount > coupon.maxDiscount) discount = coupon.maxDiscount;
    return discount;
  }
}

/// Wallet Management
class AdminWalletService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<List<WalletTransactionModel>> streamWalletTransactions(String userId) => _firestore.collection('wallet_transactions').where('userId', isEqualTo: userId).orderBy('createdAt', descending: true).snapshots().map((s) => s.docs.map((d) => WalletTransactionModel.fromFirestore(d)).toList());

  Future<void> addMoneyToWallet({required String userId, required String userType, required double amount, required String reason}) async {
    final batch = _firestore.batch();
    final walletRef = _firestore.collection('wallets').doc(userId);
    final txRef = _firestore.collection('wallet_transactions').doc();

    batch.set(walletRef, {'userId': userId, 'userType': userType, 'balance': FieldValue.increment(amount), 'updatedAt': Timestamp.now()}, SetOptions(merge: true));
    batch.set(txRef, {'id': txRef.id, 'userId': userId, 'userType': userType, 'amount': amount, 'type': 'credit', 'reason': reason, 'createdAt': Timestamp.now()});
    await batch.commit();
  }

  Future<void> deductFromWallet({required String userId, required String userType, required double amount, required String reason}) async {
    final batch = _firestore.batch();
    final walletRef = _firestore.collection('wallets').doc(userId);
    final txRef = _firestore.collection('wallet_transactions').doc();
    batch.set(walletRef, {'userId': userId, 'balance': FieldValue.increment(-amount), 'updatedAt': Timestamp.now()}, SetOptions(merge: true));
    batch.set(txRef, {'id': txRef.id, 'userId': userId, 'userType': userType, 'amount': amount, 'type': 'debit', 'reason': reason, 'createdAt': Timestamp.now()});
    await batch.commit();
  }
}

/// Fare Rules & Dynamic Pricing
class AdminFareService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> createOrUpdateFareRule(FareRuleModel rule) async => await _firestore.collection('fare_rules').doc(rule.id).set(rule.toJson(), SetOptions(merge: true));
  Stream<List<FareRuleModel>> streamFareRules(String cityId) => _firestore.collection('fare_rules').where('cityId', isEqualTo: cityId).snapshots().map((s) => s.docs.map((d) => FareRuleModel.fromFirestore(d)).toList());

  Future<double> getFareForCity({required String cityId, required String vehicleType, required double distance, required double duration}) async {
    final snap = await _firestore.collection('fare_rules').where('cityId', isEqualTo: cityId).where('vehicleType', isEqualTo: vehicleType).where('isActive', isEqualTo: true).limit(1).get();
    if (snap.docs.isEmpty) throw Exception('Fare rule not found');
    final rule = FareRuleModel.fromFirestore(snap.docs.first);
    return rule.calculateFare(distance, duration, DateTime.now());
  }
}

/// Push Notifications - FCM
class AdminNotificationService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;

  Future<void> sendToUser({required String userId, required String title, required String body, Map<String, dynamic>? data}) async {
    // Get user FCM token
    final userDoc = await _firestore.collection('users').doc(userId).get();
    final token = userDoc.data()?['fcmToken'];
    if (token == null) return;

    await _firestore.collection('notifications').add({'userId': userId, 'title': title, 'body': body, 'data': data, 'createdAt': Timestamp.now(), 'isRead': false, 'type': data?['type'] ?? 'general'});

    // In production, Cloud Function sends FCM via Admin SDK
    // Here we log to fcm_queue for Cloud Function to pick
    await _firestore.collection('fcm_queue').add({'token': token, 'title': title, 'body': body, 'data': data, 'createdAt': Timestamp.now(), 'status': 'pending'});
  }

  Future<void> sendToAllDriversInCity({required String cityId, required String title, required String body}) async {
    final drivers = await _firestore.collection('drivers').where('cityId', isEqualTo: cityId).where('isOnline', isEqualTo: true).get();
    for (var doc in drivers.docs) {
      await sendToUser(userId: doc.id, title: title, body: body, data: {'type': 'broadcast', 'cityId': cityId});
    }
  }

  Future<void> sendToAllUsers({required String title, required String body, String? cityId}) async {
    Query query = _firestore.collection('users');
    if (cityId != null) query = query.where('cityId', isEqualTo: cityId);
    final users = await query.get();
    for (var doc in users.docs) {
      await sendToUser(userId: doc.id, title: title, body: body, data: {'type': 'announcement'});
    }
  }
}

/// Support Tickets
class AdminSupportService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<List<SupportTicketModel>> streamTickets({String? status}) {
    Query query = _firestore.collection('support_tickets').orderBy('createdAt', descending: true);
    if (status != null) query = query.where('status', isEqualTo: status);
    return query.snapshots().map((s) => s.docs.map((d) => SupportTicketModel.fromFirestore(d)).toList());
  }

  Future<void> updateTicketStatus(String ticketId, String status, {String? assignedTo}) async {
    await _firestore.collection('support_tickets').doc(ticketId).update({'status': status, 'assignedTo': assignedTo, 'updatedAt': Timestamp.now()});
  }

  Future<void> addTicketResponse(String ticketId, String adminId, String message) async {
    await _firestore.collection('support_tickets').doc(ticketId).collection('responses').add({'adminId': adminId, 'message': message, 'createdAt': Timestamp.now(), 'isAdmin': true});
    await _firestore.collection('support_tickets').doc(ticketId).update({'updatedAt': Timestamp.now()});
  }
}

/// Multi-city Support
class AdminCityService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> createCity(CityModel city) async => await _firestore.collection('cities').doc(city.id).set(city.toJson());
  Stream<List<CityModel>> streamCities() => _firestore.collection('cities').orderBy('name').snapshots().map((s) => s.docs.map((d) => CityModel.fromFirestore(d)).toList());
  Future<void> toggleCityStatus(String cityId, bool isActive) async => await _firestore.collection('cities').doc(cityId).update({'isActive': isActive});
}
