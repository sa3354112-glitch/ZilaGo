
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/chat/chat_model.dart';

class ChatService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<List<ChatMessageModel>> streamMessages(String rideId) {
    return _firestore.collection('ride_chats').doc(rideId).collection('messages').orderBy('createdAt', descending: false).snapshots().map((s) => s.docs.map((d) => ChatMessageModel.fromFirestore(d)).toList());
  }

  Future<void> sendMessage({required String rideId, required String senderId, required String senderType, required String message}) async {
    final ref = _firestore.collection('ride_chats').doc(rideId).collection('messages').doc();
    await ref.set({'id': ref.id, 'rideId': rideId, 'senderId': senderId, 'senderType': senderType, 'message': message, 'type': 'text', 'createdAt': Timestamp.now(), 'isRead': false});
    await _firestore.collection('ride_requests').doc(rideId).update({'lastMessage': message, 'lastMessageAt': Timestamp.now()});
  }

  Future<void> markAsRead(String rideId, String userId) async {
    final unread = await _firestore.collection('ride_chats').doc(rideId).collection('messages').where('senderId', isNotEqualTo: userId).where('isRead', isEqualTo: false).get();
    for (var doc in unread.docs) {
      await doc.reference.update({'isRead': true});
    }
  }
}
