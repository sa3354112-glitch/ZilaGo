
import 'package:cloud_firestore/cloud_firestore.dart';

enum PaymentMethod { wallet, cash, upi, card }
enum PaymentStatus { pending, success, failed }

class PaymentService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<Map<String, dynamic>> createPaymentOrder({required String rideId, required double amount, required PaymentMethod method}) async {
    final orderId = 'order_\${DateTime.now().millisecondsSinceEpoch}';
    await _firestore.collection('payments').doc(orderId).set({
      'orderId': orderId,
      'rideId': rideId,
      'amount': amount,
      'method': method.name,
      'status': PaymentStatus.pending.name,
      'createdAt': Timestamp.now(),
    });
    return {'orderId': orderId, 'amount': amount};
  }

  Future<void> verifyPayment({required String orderId, required bool success}) async {
    await _firestore.collection('payments').doc(orderId).update({
      'status': success ? PaymentStatus.success.name : PaymentStatus.failed.name,
      'verifiedAt': Timestamp.now(),
    });
  }

  Future<void> processCashPayment(String rideId, double amount) async {
    await _firestore.collection('ride_requests').doc(rideId).update({'paymentStatus': 'completed', 'paymentMethod': 'cash'});
  }
}
