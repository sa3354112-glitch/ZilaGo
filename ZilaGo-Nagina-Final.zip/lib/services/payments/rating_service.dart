
import 'package:cloud_firestore/cloud_firestore.dart';

class RatingService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> submitRating({required String rideId, required String driverId, required String userId, required String userName, required double rating, String? review}) async {
    final batch = _firestore.batch();
    final ratingRef = _firestore.collection('drivers').doc(driverId).collection('ratings').doc(rideId);
    batch.set(ratingRef, {'id': rideId, 'driverId': driverId, 'userId': userId, 'userName': userName, 'rating': rating, 'review': review, 'createdAt': Timestamp.now()});
    
    // Update driver avg rating
    final driverRef = _firestore.collection('drivers').doc(driverId);
    final driverSnap = await driverRef.get();
    final currentAvg = (driverSnap.data()?['avgRating'] as num?)?.toDouble() ?? 5.0;
    final totalRatings = (driverSnap.data()?['totalRatings'] as num?)?.toInt() ?? 0;
    final newAvg = ((currentAvg * totalRatings) + rating) / (totalRatings + 1);
    batch.update(driverRef, {'avgRating': newAvg, 'totalRatings': totalRatings + 1});
    
    await batch.commit();
  }

  Stream<List<Map<String, dynamic>>> streamDriverRatings(String driverId) {
    return _firestore.collection('drivers').doc(driverId).collection('ratings').orderBy('createdAt', descending: true).snapshots().map((s) => s.docs.map((d) => d.data()).toList());
  }
}
