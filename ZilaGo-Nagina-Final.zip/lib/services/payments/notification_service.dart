
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class NotificationService {
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> init() async {
    await _fcm.requestPermission(alert: true, badge: true, sound: true);
    final token = await _fcm.getToken();
    if (token != null) {
      final userId = FirebaseAuth.instance.currentUser?.uid;
      if (userId != null) {
        await _firestore.collection('users').doc(userId).set({'fcmToken': token, 'updatedAt': Timestamp.now()}, SetOptions(merge: true));
        await _firestore.collection('drivers').doc(userId).set({'fcmToken': token}, SetOptions(merge: true)).catchError((_) {});
      }
    }

    FirebaseMessaging.onMessage.listen((message) {
      // Show foreground notification - use flutter_local_notifications in production
      print('FCM Foreground: \${message.notification?.title}');
    });
  }

  Stream<QuerySnapshot> streamNotifications(String userId) {
    return _firestore.collection('notifications').where('userId', isEqualTo: userId).orderBy('createdAt', descending: true).snapshots();
  }

  Future<void> markAsRead(String notifId) async {
    await _firestore.collection('notifications').doc(notifId).update({'isRead': true});
  }
}
