
import 'package:cloud_firestore/cloud_firestore.dart';

class ReferralService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<String> getOrCreateReferralCode(String userId) async {
    final userDoc = await _firestore.collection('users').doc(userId).get();
    if (userDoc.data()?['referralCode'] != null) return userDoc.data()!['referralCode'];
    final code = 'ZILA\${userId.substring(0,4).toUpperCase()}\${DateTime.now().millisecondsSinceEpoch.toString().substring(9)}';
    await _firestore.collection('users').doc(userId).update({'referralCode': code});
    return code;
  }

  Future<void> applyReferralCode({required String referredId, required String code}) async {
    final refUserSnap = await _firestore.collection('users').where('referralCode', isEqualTo: code).limit(1).get();
    if (refUserSnap.docs.isEmpty) throw Exception('Invalid referral code');
    final referrerId = refUserSnap.docs.first.id;
    if (referrerId == referredId) throw Exception('Cannot use own code');

    final existing = await _firestore.collection('referrals').where('referredId', isEqualTo: referredId).limit(1).get();
    if (existing.docs.isNotEmpty) throw Exception('Referral already used');

    await _firestore.collection('referrals').add({
      'referrerId': referrerId,
      'referredId': referredId,
      'status': 'pending',
      'referrerReward': 50,
      'referredReward': 30,
      'createdAt': Timestamp.now(),
    });
  }
}
