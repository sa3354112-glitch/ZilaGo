import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/driver/vehicle_model.dart';

/// Vehicle Management - Firestore CRUD
class VehicleService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> addVehicle(VehicleModel vehicle) async {
    await _firestore.collection('drivers').doc(vehicle.driverId).collection('vehicles').doc(vehicle.id).set(vehicle.toJson());
    // Set as active vehicle if first
    final driverDoc = await _firestore.collection('drivers').doc(vehicle.driverId).get();
    if (driverDoc.data()?['activeVehicleId'] == null) {
      await _firestore.collection('drivers').doc(vehicle.driverId).update({'activeVehicleId': vehicle.id, 'vehicleNumber': vehicle.vehicleNumber, 'vehicleType': vehicle.type.name});
    }
  }

  Future<void> updateVehicle(VehicleModel vehicle) async {
    await _firestore.collection('drivers').doc(vehicle.driverId).collection('vehicles').doc(vehicle.id).update(vehicle.toJson());
  }

  Future<void> setActiveVehicle(String driverId, String vehicleId) async {
    final vehicles = await getVehicles(driverId);
    final vehicle = vehicles.firstWhere((v) => v.id == vehicleId);

    // Deactivate all
    final batch = _firestore.batch();
    for (var v in vehicles) {
      batch.update(_firestore.collection('drivers').doc(driverId).collection('vehicles').doc(v.id), {'isActive': v.id == vehicleId});
    }
    await batch.commit();

    await _firestore.collection('drivers').doc(driverId).update({'activeVehicleId': vehicleId, 'vehicleNumber': vehicle.vehicleNumber, 'vehicleType': vehicle.type.name, 'updatedAt': Timestamp.now()});
  }

  Future<List<VehicleModel>> getVehicles(String driverId) async {
    final snap = await _firestore.collection('drivers').doc(driverId).collection('vehicles').get();
    return snap.docs.map((d) => VehicleModel.fromJson(d.data())).toList();
  }

  Stream<List<VehicleModel>> streamVehicles(String driverId) {
    return _firestore.collection('drivers').doc(driverId).collection('vehicles').snapshots().map((snap) => snap.docs.map((d) => VehicleModel.fromJson(d.data())).toList());
  }

  Future<void> deleteVehicle(String driverId, String vehicleId) async {
    await _firestore.collection('drivers').doc(driverId).collection('vehicles').doc(vehicleId).delete();
  }
}
