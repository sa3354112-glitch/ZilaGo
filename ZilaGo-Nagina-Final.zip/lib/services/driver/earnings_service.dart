import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/driver/driver_ride_model.dart';

/// Earnings Service - Real Firestore aggregation
class EarningsService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<EarningsModel> getEarnings(String driverId) async {
    final doc = await _firestore.collection('driver_earnings').doc(driverId).get();
    if (!doc.exists) {
      return EarningsModel(driverId: driverId, todayEarnings: 0, weeklyEarnings: 0, monthlyEarnings: 0, totalEarnings: 0, todayRides: 0, totalRides: 0, balance: 0, lastUpdated: DateTime.now());
    }
    return EarningsModel.fromJson(doc.data()!);
  }

  Stream<EarningsModel> streamEarnings(String driverId) {
    return _firestore.collection('driver_earnings').doc(driverId).snapshots().map((doc) {
      if (!doc.exists) {
        return EarningsModel(driverId: driverId, todayEarnings: 0, weeklyEarnings: 0, monthlyEarnings: 0, totalEarnings: 0, todayRides: 0, totalRides: 0, balance: 0, lastUpdated: DateTime.now());
      }
      return EarningsModel.fromJson(doc.data()!);
    });
  }

  Future<void> addEarningFromRide(String driverId, DriverRideRequestModel ride) async {
    final earningRef = _firestore.collection('driver_earnings').doc(driverId);
    final historyRef = _firestore.collection('driver_earnings').doc(driverId).collection('history').doc(ride.id);

    await _firestore.runTransaction((tx) async {
      final earningSnap = await tx.get(earningRef);
      EarningsModel current;
      if (!earningSnap.exists) {
        current = EarningsModel(driverId: driverId, todayEarnings: 0, weeklyEarnings: 0, monthlyEarnings: 0, totalEarnings: 0, todayRides: 0, totalRides: 0, balance: 0, lastUpdated: DateTime.now());
      } else {
        current = EarningsModel.fromJson(earningSnap.data()!);
      }

      final now = DateTime.now();
      final isToday = current.lastUpdated.day == now.day;

      tx.set(earningRef, {
        'driverId': driverId,
        'todayEarnings': isToday ? current.todayEarnings + ride.fare : ride.fare,
        'weeklyEarnings': current.weeklyEarnings + ride.fare,
        'monthlyEarnings': current.monthlyEarnings + ride.fare,
        'totalEarnings': current.totalEarnings + ride.fare,
        'todayRides': isToday ? current.todayRides + 1 : 1,
        'totalRides': current.totalRides + 1,
        'balance': current.balance + ride.fare,
        'lastUpdated': Timestamp.fromDate(now),
      }, SetOptions(merge: true));

      tx.set(historyRef, {'rideId': ride.id, 'fare': ride.fare, 'distance': ride.distanceKm, 'pickup': ride.pickup.name, 'destination': ride.destination.name, 'completedAt': Timestamp.fromDate(now), 'userName': ride.userName});
    });
  }

  Future<List<Map<String, dynamic>>> getDailyReport(String driverId, DateTime date) async {
    final start = DateTime(date.year, date.month, date.day);
    final end = start.add(const Duration(days: 1));
    final snap = await _firestore.collection('driver_earnings').doc(driverId).collection('history').where('completedAt', isGreaterThanOrEqualTo: Timestamp.fromDate(start)).where('completedAt', isLessThan: Timestamp.fromDate(end)).orderBy('completedAt', descending: true).get();
    return snap.docs.map((d) => d.data()).toList();
  }

  Future<List<Map<String, dynamic>>> getWeeklyReport(String driverId) async {
    final now = DateTime.now();
    final weekStart = now.subtract(Duration(days: now.weekday - 1));
    final start = DateTime(weekStart.year, weekStart.month, weekStart.day);
    final snap = await _firestore.collection('driver_earnings').doc(driverId).collection('history').where('completedAt', isGreaterThanOrEqualTo: Timestamp.fromDate(start)).orderBy('completedAt', descending: true).get();
    return snap.docs.map((d) => d.data()).toList();
  }

  Future<List<DriverRideRequestModel>> getRideHistory(String driverId) async {
    final snap = await _firestore.collection('ride_requests').where('driverId', isEqualTo: driverId).where('status', whereIn: ['completed', 'cancelledByDriver', 'cancelledByUser']).orderBy('requestedAt', descending: true).limit(50).get();
    return snap.docs.map((d) => DriverRideRequestModel.fromFirestore(d)).toList();
  }

  Future<List<RatingModel>> getRatings(String driverId) async {
    final snap = await _firestore.collection('drivers').doc(driverId).collection('ratings').orderBy('createdAt', descending: true).limit(50).get();
    return snap.docs.map((d) {
      final data = d.data();
      return RatingModel(id: d.id, driverId: driverId, userId: data['userId'], userName: data['userName'], rating: (data['rating'] as num).toDouble(), review: data['review'], createdAt: (data['createdAt'] as Timestamp).toDate());
    }).toList();
  }
}
