import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/driver/driver_ride_model.dart';

/// Driver Ride Service - Accept/Reject/Start/End with Firestore
class DriverRideService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// Stream incoming ride requests for this driver (based on vehicle type and location)
  Stream<List<DriverRideRequestModel>> streamRideRequests(String driverId, String vehicleType) {
    // Query rides with status requested and matching vehicle type, within Nagina area
    return _firestore
        .collection('ride_requests')
        .where('status', isEqualTo: 'requested')
        .where('category', isEqualTo: vehicleType)
        .where('driverId', isNull: true) // not yet assigned
        .orderBy('requestedAt', descending: true)
        .limit(20)
        .snapshots()
        .map((snap) => snap.docs.map((d) => DriverRideRequestModel.fromFirestore(d)).toList());
  }

  /// Accept ride - transactional to prevent double booking
  Future<void> acceptRide(String rideId, String driverId) async {
    final rideRef = _firestore.collection('ride_requests').doc(rideId);
    final driverRef = _firestore.collection('drivers').doc(driverId);

    await _firestore.runTransaction((transaction) async {
      final rideSnap = await transaction.get(rideRef);
      if (!rideSnap.exists) throw Exception('Ride not found');
      final data = rideSnap.data()!;
      if (data['status'] != 'requested') throw Exception('Ride already taken');

      final driverSnap = await transaction.get(driverRef);
      final driverData = driverSnap.data()!;

      transaction.update(rideRef, {
        'status': 'accepted',
        'driverId': driverId,
        'driverName': driverData['name'],
        'driverPhone': driverData['phone'],
        'driverPhotoUrl': driverData['profilePhotoUrl'],
        'vehicleNumber': driverData['vehicleNumber'],
        'acceptedAt': Timestamp.now(),
      });

      transaction.update(driverRef, {'currentRideId': rideId, 'isOnRide': true, 'lastRideAt': Timestamp.now()});
    });
  }

  Future<void> rejectRide(String rideId, String driverId) async {
    await _firestore.collection('ride_requests').doc(rideId).collection('rejections').doc(driverId).set({'driverId': driverId, 'rejectedAt': Timestamp.now()});
  }

  Future<void> updateRideStatus(String rideId, DriverRideStatus status) async {
    final Map<String, dynamic> update = {'status': status.name};
    switch (status) {
      case DriverRideStatus.arrived:
        update['arrivedAt'] = Timestamp.now();
        break;
      case DriverRideStatus.started:
        update['startedAt'] = Timestamp.now();
        break;
      case DriverRideStatus.completed:
        update['completedAt'] = Timestamp.now();
        break;
      default:
        break;
    }
    await _firestore.collection('ride_requests').doc(rideId).update(update);

    if (status == DriverRideStatus.completed || status == DriverRideStatus.cancelledByDriver) {
      // Free driver
      final rideDoc = await _firestore.collection('ride_requests').doc(rideId).get();
      final driverId = rideDoc.data()?['driverId'];
      if (driverId != null) {
        await _firestore.collection('drivers').doc(driverId).update({'currentRideId': null, 'isOnRide': false});
      }
    }
  }

  Future<void> cancelRideByDriver(String rideId, String reason) async {
    await _firestore.collection('ride_requests').doc(rideId).update({'status': 'cancelledByDriver', 'cancelReason': reason, 'cancelledAt': Timestamp.now()});
    final rideDoc = await _firestore.collection('ride_requests').doc(rideId).get();
    final driverId = rideDoc.data()?['driverId'];
    if (driverId != null) {
      await _firestore.collection('drivers').doc(driverId).update({'currentRideId': null, 'isOnRide': false});
    }
  }

  Stream<DriverRideRequestModel?> streamCurrentRide(String driverId) {
    return _firestore.collection('drivers').doc(driverId).snapshots().asyncMap((driverSnap) async {
      final currentRideId = driverSnap.data()?['currentRideId'];
      if (currentRideId == null) return null;
      final rideSnap = await _firestore.collection('ride_requests').doc(currentRideId).get();
      if (!rideSnap.exists) return null;
      return DriverRideRequestModel.fromFirestore(rideSnap);
    });
  }
}
