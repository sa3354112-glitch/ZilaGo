import 'dart:async';
import 'package:firebase_database/firebase_database.dart';
import 'package:geolocator/geolocator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

/// Live Location Updates - Firebase Realtime Database + Firestore
/// Realtime DB for high-frequency location, Firestore for driver status
class DriverLocationService {
  final FirebaseDatabase _realtimeDb = FirebaseDatabase.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  StreamSubscription<Position>? _positionSubscription;
  bool _isTracking = false;

  /// Start tracking and pushing to Firebase Realtime Database
  Future<void> startTracking(String driverId) async {
    if (_isTracking) return;
    _isTracking = true;

    const locationSettings = LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 10);

    _positionSubscription = Geolocator.getPositionStream(locationSettings: locationSettings).listen((Position position) async {
      await _updateLocation(driverId, position);
    });

    // Set online status
    await _firestore.collection('drivers').doc(driverId).update({'isOnline': true, 'lastActive': Timestamp.now(), 'isTracking': true});
    await _realtimeDb.ref('driver_locations/$driverId').update({'isOnline': true, 'lastUpdate': ServerValue.timestamp});
  }

  Future<void> stopTracking(String driverId) async {
    await _positionSubscription?.cancel();
    _positionSubscription = null;
    _isTracking = false;

    await _firestore.collection('drivers').doc(driverId).update({'isOnline': false, 'lastActive': Timestamp.now(), 'isTracking': false});
    await _realtimeDb.ref('driver_locations/$driverId').update({'isOnline': false, 'lastUpdate': ServerValue.timestamp});
  }

  Future<void> _updateLocation(String driverId, Position position) async {
    try {
      // Realtime DB - for live tracking (low latency)
      await _realtimeDb.ref('driver_locations/$driverId').set({
        'lat': position.latitude,
        'lng': position.longitude,
        'heading': position.heading,
        'speed': position.speed,
        'accuracy': position.accuracy,
        'timestamp': ServerValue.timestamp,
        'isOnline': true,
      });

      // Firestore - for queries and history (update every 30s to save writes)
      await _firestore.collection('drivers').doc(driverId).update({'lat': position.latitude, 'lng': position.longitude, 'heading': position.heading, 'speed': position.speed, 'lastLocationUpdate': Timestamp.now()});
    } catch (e) {
      // Handle offline - queue for later
    }
  }

  /// Stream driver location from Realtime DB
  Stream<Map<String, dynamic>> streamDriverLocation(String driverId) {
    return _realtimeDb.ref('driver_locations/$driverId').onValue.map((event) {
      final data = event.snapshot.value as Map<dynamic, dynamic>?;
      if (data == null) return {};
      return Map<String, dynamic>.from(data);
    });
  }

  /// Update ride-specific location (for customer tracking)
  Future<void> updateRideLocation(String rideId, String driverId, Position position) async {
    await _realtimeDb.ref('ride_locations/$rideId').set({
      'driverId': driverId,
      'lat': position.latitude,
      'lng': position.longitude,
      'heading': position.heading,
      'timestamp': ServerValue.timestamp,
    });
  }

  Stream<Map<String, dynamic>> streamRideLocation(String rideId) {
    return _realtimeDb.ref('ride_locations/$rideId').onValue.map((event) {
      final data = event.snapshot.value as Map<dynamic, dynamic>?;
      return data != null ? Map<String, dynamic>.from(data) : {};
    });
  }
}
