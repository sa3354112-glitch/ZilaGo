import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import '../../models/driver/kyc_model.dart';

/// KYC Service - Real Firebase Storage + Firestore
class KycService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final ImagePicker _picker = ImagePicker();

  Future<XFile?> pickImage({required ImageSource source}) async {
    return await _picker.pickImage(source: source, imageQuality: 70);
  }

  Future<String> uploadDocumentImage({required String driverId, required KycDocumentType type, required XFile file, required bool isFront}) async {
    final ref = _storage.ref().child('drivers/$driverId/kyc/${type.name}_${isFront ? 'front' : 'back'}_${DateTime.now().millisecondsSinceEpoch}.jpg');
    final uploadTask = await ref.putFile(File(file.path));
    return await uploadTask.ref.getDownloadURL();
  }

  Future<void> saveKycDocument({required String driverId, required KycDocumentModel document}) async {
    await _firestore.collection('drivers').doc(driverId).collection('kyc').doc(document.type.name).set(document.toJson(), SetOptions(merge: true));
    await _updateOverallStatus(driverId);
  }

  Future<void> saveProfilePhoto({required String driverId, required String photoUrl}) async {
    await _firestore.collection('drivers').doc(driverId).update({'profilePhotoUrl': photoUrl, 'updatedAt': Timestamp.now()});
  }

  Future<DriverKycModel> getKycStatus(String driverId) async {
    final snap = await _firestore.collection('drivers').doc(driverId).collection('kyc').get();
    final docs = {for (var d in snap.docs) d.id: d.data()};

    KycDocumentModel? parse(String key) => docs.containsKey(key) ? KycDocumentModel.fromJson(docs[key]!) : null;

    final driverDoc = await _firestore.collection('drivers').doc(driverId).get();
    final profilePhoto = driverDoc.data()?['profilePhotoUrl'];

    final aadhaar = parse('aadhaar');
    final license = parse('license');
    final rc = parse('rc');
    final insurance = parse('insurance');

    int completed = 0;
    if (aadhaar != null) completed++;
    if (license != null) completed++;
    if (rc != null) completed++;
    if (insurance != null) completed++;
    if (profilePhoto != null) completed++;

    double percentage = (completed / 5) * 100;

    KycStatus overall = KycStatus.pending;
    if (completed == 5) {
      final allApproved = [aadhaar, license, rc, insurance].every((d) => d?.status == KycStatus.approved);
      if (allApproved) overall = KycStatus.approved;
      else if ([aadhaar, license, rc, insurance].any((d) => d?.status == KycStatus.rejected)) overall = KycStatus.rejected;
      else overall = KycStatus.underReview;
    }

    return DriverKycModel(
      driverId: driverId,
      aadhaar: aadhaar,
      license: license,
      rc: rc,
      insurance: insurance,
      profilePhotoUrl: profilePhoto,
      overallStatus: overall,
      completionPercentage: percentage,
    );
  }

  Future<void> _updateOverallStatus(String driverId) async {
    final kyc = await getKycStatus(driverId);
    await _firestore.collection('drivers').doc(driverId).update({'kycStatus': kyc.overallStatus.name, 'kycCompletion': kyc.completionPercentage, 'updatedAt': Timestamp.now()});
  }

  Stream<DriverKycModel> streamKycStatus(String driverId) {
    return _firestore.collection('drivers').doc(driverId).collection('kyc').snapshots().asyncMap((_) => getKycStatus(driverId));
  }
}
