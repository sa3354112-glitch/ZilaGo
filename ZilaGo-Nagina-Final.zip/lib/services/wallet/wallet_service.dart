
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/wallet/wallet_model.dart';

class WalletService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<WalletModel> streamWallet(String userId) {
    return _firestore.collection('wallets').doc(userId).snapshots().map((doc) {
      if (!doc.exists) return WalletModel(userId: userId, balance: 0, totalEarned: 0, totalSpent: 0, updatedAt: DateTime.now());
      return WalletModel.fromJson(doc.data()!);
    });
  }

  Stream<List<WalletTx>> streamTransactions(String userId) {
    return _firestore.collection('wallet_transactions').where('userId', isEqualTo: userId).orderBy('createdAt', descending: true).limit(50).snapshots().map((s) => s.docs.map((d) => WalletTx.fromFirestore(d)).toList());
  }

  Future<void> addMoney({required String userId, required double amount, required String reason}) async {
    final walletRef = _firestore.collection('wallets').doc(userId);
    final txRef = _firestore.collection('wallet_transactions').doc();
    final batch = _firestore.batch();
    batch.set(walletRef, {'userId': userId, 'balance': FieldValue.increment(amount), 'totalEarned': FieldValue.increment(amount), 'updatedAt': Timestamp.now()}, SetOptions(merge: true));
    batch.set(txRef, {'id': txRef.id, 'userId': userId, 'amount': amount, 'type': 'credit', 'reason': reason, 'createdAt': Timestamp.now()});
    await batch.commit();
  }

  Future<void> payForRide({required String userId, required String rideId, required double fare, double walletUse = 0}) async {
    if (walletUse <= 0) return;
    final walletRef = _firestore.collection('wallets').doc(userId);
    final txRef = _firestore.collection('wallet_transactions').doc();
    final batch = _firestore.batch();
    batch.set(walletRef, {'userId': userId, 'balance': FieldValue.increment(-walletUse), 'totalSpent': FieldValue.increment(walletUse), 'updatedAt': Timestamp.now()}, SetOptions(merge: true));
    batch.set(txRef, {'id': txRef.id, 'userId': userId, 'amount': walletUse, 'type': 'debit', 'reason': 'ride_payment', 'rideId': rideId, 'createdAt': Timestamp.now()});
    await batch.commit();
  }
}
