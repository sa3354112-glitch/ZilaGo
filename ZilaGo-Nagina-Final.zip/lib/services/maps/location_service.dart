import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../core/constants/map_constants.dart';
import '../models/ride/place_model.dart';

/// Location Service - Live Current Location
class LocationService {
  LocationService._();
  static final LocationService instance = LocationService._();

  Future<bool> checkAndRequestPermission() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return false;

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return false;
    }
    if (permission == LocationPermission.deniedForever) return false;
    return true;
  }

  Future<Position?> getCurrentPosition() async {
    try {
      final hasPermission = await checkAndRequestPermission();
      if (!hasPermission) return null;

      return await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    } catch (e) {
      return null;
    }
  }

  Stream<Position> getPositionStream() {
    const LocationSettings settings = LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 10);
    return Geolocator.getPositionStream(locationSettings: settings);
  }

  Future<PlaceModel?> getPlaceFromLatLng(double lat, double lng) async {
    try {
      List<Placemark> placemarks = await placemarkFromCoordinates(lat, lng);
      if (placemarks.isEmpty) return null;
      final place = placemarks.first;
      return PlaceModel(
        id: '${lat}_$lng',
        name: place.street ?? place.name ?? 'Current Location',
        address: '${place.street}, ${place.locality}, ${place.administrativeArea}',
        lat: lat,
        lng: lng,
      );
    } catch (e) {
      return PlaceModel(id: 'current', name: 'Current Location', address: 'Nagina, Bijnor', lat: lat, lng: lng);
    }
  }

  Future<PlaceModel?> getCurrentPlace() async {
    final pos = await getCurrentPosition();
    if (pos == null) {
      // Fallback to Nagina
      return PlaceModel(id: 'nagina_bus_stand', name: 'Bus Stand, Nagina', address: 'Bus Stand, Nagina, Bijnor', lat: MapConstants.naginaLat, lng: MapConstants.naginaLng);
    }
    return await getPlaceFromLatLng(pos.latitude, pos.longitude);
  }

  double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    return Geolocator.distanceBetween(lat1, lon1, lat2, lon2) / 1000; // km
  }
}
