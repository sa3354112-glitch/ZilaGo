import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import '../core/constants/map_constants.dart';
import '../core/theme/app_colors.dart';
import '../models/ride/place_model.dart';
import '../models/ride/ride_model.dart';
import '../models/ride/ride_category_model.dart';

/// Map Service - Polyline, Markers, Fare Estimation
class MapService {
  MapService._();
  static final MapService instance = MapService._();

  // TODO: Replace with your Google Maps API Key
  static const String googleApiKey = 'YOUR_GOOGLE_MAPS_API_KEY';

  /// Get polyline points between two places (mock if no API key)
  Future<List<LatLng>> getPolylinePoints(PlaceModel pickup, PlaceModel destination) async {
    if (googleApiKey == 'YOUR_GOOGLE_MAPS_API_KEY') {
      // Mock polyline - straight line with slight curve for Nagina
      return _generateMockPolyline(pickup, destination);
    }

    try {
      PolylinePoints polylinePoints = PolylinePoints();
      PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
        googleApiKey,
        PointLatLng(pickup.lat, pickup.lng),
        PointLatLng(destination.lat, destination.lng),
        travelMode: TravelMode.driving,
      );

      if (result.points.isEmpty) return _generateMockPolyline(pickup, destination);

      return result.points.map((p) => LatLng(p.latitude, p.longitude)).toList();
    } catch (e) {
      return _generateMockPolyline(pickup, destination);
    }
  }

  List<LatLng> _generateMockPolyline(PlaceModel pickup, PlaceModel dest) {
    // Create curved mock path for visual appeal
    final List<LatLng> points = [];
    final steps = 20;
    for (int i = 0; i <= steps; i++) {
      double t = i / steps;
      // Add slight curve
      double lat = pickup.lat + (dest.lat - pickup.lat) * t + sin(t * 3.14) * 0.002;
      double lng = pickup.lng + (dest.lng - pickup.lng) * t + cos(t * 3.14) * 0.001;
      points.add(LatLng(lat, lng));
    }
    return points;
  }

  /// Fare estimation logic
  double estimateFare(RideCategoryModel category, double distanceKm, double durationMin) {
    double fare = category.baseFare + (category.perKm * distanceKm) + (category.perMin * durationMin);
    // Nagina surge - minimal
    if (distanceKm > 15) fare *= 1.1;
    return (fare).ceilToDouble();
  }

  /// Duration estimation (mock)
  double estimateDuration(double distanceKm) {
    // Average 25 km/h in Nagina town
    return (distanceKm / 25 * 60).ceilToDouble();
  }

  /// Create markers
  Set<Marker> createMarkers({required PlaceModel? pickup, required PlaceModel? destination, List<DriverModel> nearbyDrivers = const []}) {
    final Set<Marker> markers = {};

    if (pickup != null) {
      markers.add(Marker(
        markerId: const MarkerId('pickup'),
        position: LatLng(pickup.lat, pickup.lng),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueOrange),
        infoWindow: InfoWindow(title: 'Pickup', snippet: pickup.name),
      ));
    }

    if (destination != null) {
      markers.add(Marker(
        markerId: const MarkerId('destination'),
        position: LatLng(destination.lat, destination.lng),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueViolet),
        infoWindow: InfoWindow(title: 'Destination', snippet: destination.name),
      ));
    }

    for (var driver in nearbyDrivers) {
      markers.add(Marker(
        markerId: MarkerId(driver.id),
        position: LatLng(driver.lat, driver.lng),
        icon: BitmapDescriptor.defaultMarkerWithHue(driver.vehicleType == RideCategoryType.bike ? BitmapDescriptor.hueYellow : BitmapDescriptor.hueGreen),
        infoWindow: InfoWindow(title: driver.name, snippet: driver.vehicleNumber),
        rotation: 0,
      ));
    }

    return markers;
  }

  /// Generate mock nearby drivers
  List<DriverModel> getNearbyDrivers(RideCategoryType type, {int count = 5}) {
    return List.generate(count, (i) => DriverModel.mock(i, type));
  }
}
