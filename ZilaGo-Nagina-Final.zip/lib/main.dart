import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'core/theme/app_theme.dart';
import 'core/routes/unified_routes.dart';
import 'viewmodels/splash_viewmodel.dart';
import 'viewmodels/onboarding_viewmodel.dart';
import 'viewmodels/auth_viewmodel.dart';
import 'viewmodels/home/customer_home_viewmodel.dart';
import 'viewmodels/driver/driver_kyc_viewmodel.dart';
import 'viewmodels/driver/driver_dashboard_viewmodel.dart';
import 'viewmodels/admin/admin_viewmodels.dart';

/// ZilaGo - Final Unified App Entry
/// Customer + Driver + Admin in Single APK
/// Role-based auto routing after login
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  try {
    await Firebase.initializeApp();
    debugPrint('🔥 Firebase Initialized - ZilaGo Production Ready');
  } catch (e) {
    debugPrint('⚠️ Firebase not configured yet: $e - Run flutterfire configure');
  }

  runApp(const ZilaGoUnifiedApp());
}

class ZilaGoUnifiedApp extends StatelessWidget {
  const ZilaGoUnifiedApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SplashViewModel()),
        ChangeNotifierProvider(create: (_) => OnboardingViewModel()),
        ChangeNotifierProvider(create: (_) => AuthViewModel()),
        ChangeNotifierProvider(create: (_) => CustomerHomeViewModel()),
        ChangeNotifierProvider(create: (_) => DriverKycViewModel()),
        ChangeNotifierProvider(create: (_) => DriverDashboardViewModel()),
        ChangeNotifierProvider(create: (_) => AdminAuthViewModel()),
        ChangeNotifierProvider(create: (_) => AdminDashboardViewModel()),
        ChangeNotifierProvider(create: (_) => AdminKycViewModel()),
      ],
      child: MaterialApp(
        title: 'ZilaGo - Apni Zila, Apni Sawari',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.darkTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.dark,
        initialRoute: UnifiedRoutes.splash,
        routes: UnifiedRoutes.routes,
        onGenerateRoute: UnifiedRoutes.onGenerateRoute,
        navigatorObservers: [RouteObserver()],
      ),
    );
  }
}

/// Role-based Splash Logic
class UnifiedSplashView extends StatefulWidget {
  const UnifiedSplashView({super.key});
  @override
  State<UnifiedSplashView> createState() => _UnifiedSplashViewState();
}

class _UnifiedSplashViewState extends State<UnifiedSplashView> {
  @override
  void initState() {
    super.initState();
    _checkAuthAndRoute();
  }

  Future<void> _checkAuthAndRoute() async {
    await Future.delayed(const Duration(seconds: 2));
    if (!mounted) return;

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      // Check onboarding seen
      Navigator.pushReplacementNamed(context, UnifiedRoutes.onboarding);
      return;
    }

    try {
      // Check if admin
      final adminDoc = await FirebaseFirestore.instance.collection('admins').doc(user.uid).get();
      if (adminDoc.exists) {
        Navigator.pushReplacementNamed(context, UnifiedRoutes.adminDashboard);
        return;
      }

      // Check user type
      final userDoc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      final driverDoc = await FirebaseFirestore.instance.collection('drivers').doc(user.uid).get();

      if (driverDoc.exists || userDoc.data()?['userType'] == 'driver') {
        // Driver - check KYC
        final kycStatus = driverDoc.data()?['kycStatus'] ?? userDoc.data()?['kycStatus'];
        if (kycStatus != 'approved') {
          Navigator.pushReplacementNamed(context, UnifiedRoutes.driverKyc, arguments: user.uid);
        } else {
          Navigator.pushReplacementNamed(context, UnifiedRoutes.driverDashboard, arguments: user.uid);
        }
        return;
      }

      // Default customer
      Navigator.pushReplacementNamed(context, UnifiedRoutes.customerHome);
    } catch (e) {
      Navigator.pushReplacementNamed(context, UnifiedRoutes.customerLogin);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(width: 100, height: 100, decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFFFF6B00), Color(0xFF8B5CF6)]), borderRadius: BorderRadius.circular(28)), child: const Center(child: Text('Z', style: TextStyle(fontSize: 50, fontWeight: FontWeight.w900, color: Colors.white)))),
            const SizedBox(height: 20),
            const Text('ZilaGo', style: TextStyle(fontSize: 36, fontWeight: FontWeight.w800, color: Colors.white)),
            const Text('Apni Zila, Apni Sawari', style: TextStyle(color: Colors.white54)),
            const SizedBox(height: 40),
            const CircularProgressIndicator(color: Color(0xFFFF6B00)),
          ],
        ),
      ),
    );
  }
}
