import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'core/theme/app_colors.dart';
import 'core/theme/app_text_styles.dart';
import 'core/constants/map_constants.dart';
import 'models/ride/place_model.dart';
import 'models/ride/ride_category_model.dart';
import 'viewmodels/auth_viewmodel.dart';

/// NAGINA MVP - NO GOOGLE MAPS KEY NEEDED
/// Works with localities list only + Firebase + Phone Call
/// Launch in Nagina TODAY
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try { await Firebase.initializeApp(); } catch (e) { debugPrint('Firebase not configured: $e'); }
  runApp(const NaginaMVPApp());
}

class NaginaMVPApp extends StatelessWidget {
  const NaginaMVPApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [ChangeNotifierProvider(create: (_) => AuthViewModel())],
      child: MaterialApp(
        title: 'ZilaGo - Nagina',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark().copyWith(scaffoldBackgroundColor: AppColors.background),
        home: const NaginaRoleSelector(),
      ),
    );
  }
}

class NaginaRoleSelector extends StatelessWidget {
  const NaginaRoleSelector({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const SizedBox(height: 30),
              Container(width: 80, height: 80, decoration: BoxDecoration(gradient: AppColors.logoGradient, borderRadius: BorderRadius.circular(20)), child: const Center(child: Text('Z', style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, color: Colors.white)))),
              const SizedBox(height: 12),
              Text('ZilaGo', style: AppTextStyles.logoLarge),
              Text('Nagina • Abhi Start Karo', style: AppTextStyles.tagline.copyWith(color: AppColors.primaryOrange)),
              const SizedBox(height: 30),
              _NaginaCard(icon: Icons.person_rounded, title: 'Customer - Ride Book Karo', subtitle: 'Nagina ke 8 areas', color: AppColors.primaryOrange, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NaginaCustomerHome()))),
              const SizedBox(height: 12),
              _NaginaCard(icon: Icons.local_taxi_rounded, title: 'Driver - Kamao ₹1500/day', subtitle: 'Auto / E-Rickshaw / Bike', color: AppColors.success, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NaginaDriverHome()))),
              const Spacer(),
              Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12)), child: Column(children: [Text('NAGINA MVP MODE', style: AppTextStyles.label.copyWith(color: AppColors.success)), const SizedBox(height: 4), Text('No Maps Key Needed • Firebase + Phone Call se chalega • Aaj hi 5 auto walon ko jod do', style: AppTextStyles.bodySmall, textAlign: TextAlign.center)])),
            ],
          ),
        ),
      ),
    );
  }
}

class _NaginaCard extends StatelessWidget {
  final IconData icon; final String title; final String subtitle; final Color color; final VoidCallback onTap;
  const _NaginaCard({required this.icon, required this.title, required this.subtitle, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: color.withOpacity(0.4))), child: Row(children: [Container(width: 48, height: 48, decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: color)), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: AppTextStyles.h3.copyWith(fontSize: 15)), Text(subtitle, style: AppTextStyles.bodySmall)])), const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: Colors.white24)])),
    );
  }
}

// CUSTOMER MVP - No Map, Only Nagina Localities Dropdown
class NaginaCustomerHome extends StatefulWidget {
  const NaginaCustomerHome({super.key});
  @override
  State<NaginaCustomerHome> createState() => _NaginaCustomerHomeState();
}

class _NaginaCustomerHomeState extends State<NaginaCustomerHome> {
  PlaceModel? pickup;
  PlaceModel? destination;
  RideCategoryType selectedType = RideCategoryType.auto;
  final List<PlaceModel> places = NaginaPlaces.localities.map((e) => PlaceModel.fromNaginaLocality(e)).toList();

  @override
  void initState() { super.initState(); pickup = places.first; destination = places[1]; }

  double get fare {
    if (pickup == null || destination == null) return 0;
    final cat = RideCategoryModel.fromType(selectedType);
    // Simple distance calc based on index diff + random
    double dist = (places.indexOf(destination!) - places.indexOf(pickup!)).abs() * 0.8 + 1.5;
    return cat.calculateFare(dist, dist * 3);
  }

  Future<void> bookRide() async {
    if (destination == null) return;
    final user = FirebaseAuth.instance.currentUser;
    final rideId = 'ride_${DateTime.now().millisecondsSinceEpoch}';
    await FirebaseFirestore.instance.collection('ride_requests').doc(rideId).set({
      'id': rideId,
      'userId': user?.uid ?? 'guest_${DateTime.now().millisecondsSinceEpoch}',
      'userName': user?.displayName ?? 'Nagina Customer',
      'userPhone': user?.phoneNumber ?? '9876543210',
      'pickup': pickup!.toJson(),
      'destination': destination!.toJson(),
      'category': selectedType.name,
      'distanceKm': 2.5,
      'durationMin': 8,
      'fare': fare,
      'status': 'requested',
      'cityId': 'nagina',
      'requestedAt': Timestamp.now(),
    });
    if (!mounted) return;
    showDialog(context: context, builder: (_) => AlertDialog(backgroundColor: AppColors.surface, title: Text('Ride Booked! ✓', style: AppTextStyles.h2), content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${pickup!.name} → ${destination!.name}', style: AppTextStyles.label), const SizedBox(height: 8), Text('Fare: ₹${fare.toStringAsFixed(0)} • ${RideCategoryModel.fromType(selectedType).name}', style: AppTextStyles.body), const SizedBox(height: 12), Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: AppColors.success.withOpacity(0.15), borderRadius: BorderRadius.circular(8)), child: Text('Driver 2 min me call karega! Nagina ke drivers ko notification gaya hai.', style: AppTextStyles.bodySmall.copyWith(color: AppColors.success)))]), actions: [ElevatedButton(onPressed: () => Navigator.pop(context), style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryOrange), child: const Text('OK'))]));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(backgroundColor: AppColors.background, title: Text('Book Ride - Nagina', style: AppTextStyles.h3)),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Kaha se?', style: AppTextStyles.label), const SizedBox(height: 8),
            DropdownButtonFormField<PlaceModel>(value: pickup, decoration: InputDecoration(filled: true, fillColor: AppColors.surface, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)), items: places.map((p) => DropdownMenuItem(value: p, child: Text(p.name, style: const TextStyle(fontSize: 13)))).toList(), onChanged: (v) => setState(() => pickup = v)),
            const SizedBox(height: 16),
            Text('Kaha jana hai?', style: AppTextStyles.label), const SizedBox(height: 8),
            DropdownButtonFormField<PlaceModel>(value: destination, decoration: InputDecoration(filled: true, fillColor: AppColors.surface, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)), items: places.map((p) => DropdownMenuItem(value: p, child: Text(p.name, style: const TextStyle(fontSize: 13)))).toList(), onChanged: (v) => setState(() => destination = v)),
            const SizedBox(height: 20),
            Text('Ride Chuno', style: AppTextStyles.label), const SizedBox(height: 8),
            SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: RideCategoryType.values.map((t) { final cat = RideCategoryModel.fromType(t); final isSel = selectedType == t; return GestureDetector(onTap: () => setState(() => selectedType = t), child: Container(margin: const EdgeInsets.only(right: 10), padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10), decoration: BoxDecoration(color: isSel ? AppColors.primaryOrange.withOpacity(0.2) : AppColors.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: isSel ? AppColors.primaryOrange : AppColors.border)), child: Row(children: [Text(cat.icon), const SizedBox(width: 6), Text(cat.name, style: TextStyle(color: isSel ? AppColors.primaryOrange : Colors.white, fontWeight: FontWeight.w600, fontSize: 12))]))); }).toList())),
            const Spacer(),
            Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14)), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${pickup?.name} → ${destination?.name}', style: AppTextStyles.bodySmall, maxLines: 1), Text('₹${fare.toStringAsFixed(0)} • ${RideCategoryModel.fromType(selectedType).name}', style: AppTextStyles.h3.copyWith(color: AppColors.primaryOrange))]), const Icon(Icons.arrow_forward_rounded, color: AppColors.primaryOrange)])),
            const SizedBox(height: 12),
            SizedBox(width: double.infinity, height: 54, child: ElevatedButton(onPressed: bookRide, style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryOrange, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), child: Text('Book Now • ₹${fare.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w700, color: Colors.white)))),
          ],
        ),
      ),
    );
  }
}

// DRIVER MVP - Simple Online + See Requests + Call Customer
class NaginaDriverHome extends StatefulWidget {
  const NaginaDriverHome({super.key});
  @override
  State<NaginaDriverHome> createState() => _NaginaDriverHomeState();
}

class _NaginaDriverHomeState extends State<NaginaDriverHome> {
  bool isOnline = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(backgroundColor: AppColors.background, title: Text('Driver - Nagina', style: AppTextStyles.h3)),
      body: Column(
        children: [
          Container(margin: const EdgeInsets.all(16), padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: isOnline ? AppColors.success.withOpacity(0.15) : AppColors.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: isOnline ? AppColors.success : AppColors.border)), child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(isOnline ? 'ONLINE - Ride Aa Rahi Hai' : 'OFFLINE', style: AppTextStyles.h3.copyWith(color: isOnline ? AppColors.success : Colors.white)), Text(isOnline ? 'Nagina me active ho' : 'Online jao ride pane ke liye', style: AppTextStyles.bodySmall)])), Switch(value: isOnline, activeColor: AppColors.success, onChanged: (v) => setState(() => isOnline = v))])),
          Expanded(
            child: !isOnline
                ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [const Icon(Icons.power_settings_new_rounded, size: 64, color: Colors.white24), const SizedBox(height: 12), Text('Offline ho', style: AppTextStyles.h3), Text('Online jao, Nagina ke customers ka ride dekhega', style: AppTextStyles.bodySmall)]))
                : StreamBuilder<QuerySnapshot>(stream: FirebaseFirestore.instance.collection('ride_requests').where('status', isEqualTo: 'requested').where('cityId', isEqualTo: 'nagina').orderBy('requestedAt', descending: true).snapshots(), builder: (context, snap) {
                    final docs = snap.data?.docs ?? [];
                    if (docs.isEmpty) return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [const CircularProgressIndicator(color: AppColors.primaryOrange), const SizedBox(height: 12), Text('Nagina me ride search ho rahi hai...', style: AppTextStyles.body)]));
                    return ListView.builder(padding: const EdgeInsets.all(16), itemCount: docs.length, itemBuilder: (c, i) {
                      final data = docs[i].data() as Map<String, dynamic>;
                      return Container(margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.primaryOrange.withOpacity(0.3))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('₹${(data['fare'] as num).toStringAsFixed(0)}', style: AppTextStyles.h3.copyWith(color: AppColors.primaryOrange)), Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: AppColors.success.withOpacity(0.15), borderRadius: BorderRadius.circular(6)), child: Text((data['category'] as String).toUpperCase(), style: const TextStyle(fontSize: 10, color: AppColors.success)))]), const SizedBox(height: 8), Text('${data['pickup']?['name']} → ${data['destination']?['name']}', style: AppTextStyles.label.copyWith(fontSize: 13)), const SizedBox(height: 8), Text('Customer: ${data['userName']} • ${data['userPhone']}', style: AppTextStyles.bodySmall), const SizedBox(height: 12), Row(children: [Expanded(child: OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.call_rounded, size: 16), label: const Text('Call'))), const SizedBox(width: 8), Expanded(child: ElevatedButton(onPressed: () async { await FirebaseFirestore.instance.collection('ride_requests').doc(docs[i].id).update({'status': 'accepted', 'driverId': FirebaseAuth.instance.currentUser?.uid ?? 'driver_mvp'}); if(context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Ride Accepted! Customer ko call karo'))); }, style: ElevatedButton.styleFrom(backgroundColor: AppColors.success), child: const Text('Accept', style: TextStyle(color: Colors.white))))])]));
                    });
                  }),
          ),
        ],
      ),
    );
  }
}
