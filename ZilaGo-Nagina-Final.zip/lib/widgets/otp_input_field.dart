import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';

/// OTP Input Field - 6 boxes
class OtpInputField extends StatelessWidget {
  final TextEditingController controller;
  final Function(String)? onCompleted;

  const OtpInputField({super.key, required this.controller, this.onCompleted});

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      keyboardType: TextInputType.number,
      maxLength: 6,
      textAlign: TextAlign.center,
      style: const TextStyle(fontSize: 22, letterSpacing: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
      decoration: InputDecoration(
        hintText: '------',
        counterText: '',
        hintStyle: TextStyle(letterSpacing: 12, color: AppColors.textTertiary),
      ),
      onChanged: (val) {
        if (val.length == 6) {
          onCompleted?.call(val);
        }
      },
    );
  }
}
