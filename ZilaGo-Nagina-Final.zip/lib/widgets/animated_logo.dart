import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

/// Premium Animated Logo Widget - Black background compatible
class AnimatedLogo extends StatelessWidget {
  final Animation<double> scaleAnimation;
  final Animation<double> fadeAnimation;

  const AnimatedLogo({
    super.key,
    required this.scaleAnimation,
    required this.fadeAnimation,
  });

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: fadeAnimation,
      child: ScaleTransition(
        scale: scaleAnimation,
        child: Container(
          width: 110,
          height: 110,
          decoration: BoxDecoration(
            gradient: AppColors.logoGradient,
            borderRadius: BorderRadius.circular(28),
            boxShadow: [
              BoxShadow(
                color: AppColors.primaryOrange.withOpacity(0.35),
                blurRadius: 30,
                spreadRadius: 2,
                offset: const Offset(0, 10),
              ),
              BoxShadow(
                color: AppColors.primaryPurple.withOpacity(0.25),
                blurRadius: 30,
                spreadRadius: 2,
                offset: const Offset(0, -5),
              ),
            ],
          ),
          child: const Center(
            child: Text(
              'Z',
              style: TextStyle(
                fontSize: 58,
                fontWeight: FontWeight.w900,
                color: Colors.white,
                letterSpacing: -2,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
