import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../models/ride/ride_model.dart';

/// Driver Info Card - Accepted Screen
class DriverInfoCard extends StatelessWidget {
  final DriverModel driver;
  final double fare;
  final VoidCallback onCall;
  final VoidCallback onCancel;

  const DriverInfoCard({super.key, required this.driver, required this.fare, required this.onCall, required this.onCancel});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(color: AppColors.surfaceVariant, shape: BoxShape.circle, border: Border.all(color: AppColors.border)),
                child: const Icon(Icons.person_rounded, size: 28, color: AppColors.textSecondary),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(driver.name, style: AppTextStyles.h3),
                    Row(
                      children: [
                        const Icon(Icons.star_rounded, size: 16, color: Colors.amber),
                        const SizedBox(width: 4),
                        Text('${driver.rating} • ${driver.totalRides} rides', style: AppTextStyles.bodySmall),
                      ],
                    ),
                    Text(driver.vehicleNumber, style: AppTextStyles.bodySmall.copyWith(color: AppColors.textPrimary, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(color: AppColors.success.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
                child: Text('₹${fare.toStringAsFixed(0)}', style: AppTextStyles.label.copyWith(color: AppColors.success)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: onCancel,
                  icon: const Icon(Icons.close_rounded, size: 18),
                  label: Text('Cancel', style: AppTextStyles.label.copyWith(fontSize: 13)),
                  style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.border), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: onCall,
                  icon: const Icon(Icons.call_rounded, size: 18),
                  label: Text('Call', style: AppTextStyles.button.copyWith(fontSize: 13)),
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.success, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// Searching Animation Widget
class DriverSearchingAnimation extends StatefulWidget {
  const DriverSearchingAnimation({super.key});

  @override
  State<DriverSearchingAnimation> createState() => _DriverSearchingAnimationState();
}

class _DriverSearchingAnimationState extends State<DriverSearchingAnimation> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 180,
      child: Stack(
        alignment: Alignment.center,
        children: [
          ...List.generate(3, (i) {
            return ScaleTransition(
              scale: Tween<double>(begin: 0.5, end: 1.5).animate(CurvedAnimation(parent: _controller, curve: Interval(i * 0.2, 1.0, curve: Curves.easeOut))),
              child: Container(
                width: 80 + i * 40,
                height: 80 + i * 40,
                decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: AppColors.primaryOrange.withOpacity(0.3 - i * 0.08), width: 1.5)),
              ),
            );
          }),
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(gradient: AppColors.logoGradient, shape: BoxShape.circle, boxShadow: [BoxShadow(color: AppColors.primaryOrange.withOpacity(0.4), blurRadius: 20)]),
            child: const Center(child: Text('Z', style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900, color: Colors.white))),
          ),
        ],
      ),
    );
  }
}
