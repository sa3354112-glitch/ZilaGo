import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../models/ride/ride_category_model.dart';

/// Ride Category Card - Premium UI
class RideCategoryCard extends StatelessWidget {
  final RideCategoryModel category;
  final VoidCallback onTap;
  final double estimatedFare;

  const RideCategoryCard({super.key, required this.category, required this.onTap, required this.estimatedFare});

  @override
  Widget build(BuildContext context) {
    final isSelected = category.isSelected;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primaryOrange.withOpacity(0.15) : AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: isSelected ? AppColors.primaryOrange : AppColors.border, width: isSelected ? 1.5 : 1),
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(color: isSelected ? AppColors.primaryOrange.withOpacity(0.2) : AppColors.surfaceVariant, borderRadius: BorderRadius.circular(10)),
              child: Center(child: Text(category.icon, style: const TextStyle(fontSize: 24))),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(category.name, style: AppTextStyles.label.copyWith(fontWeight: FontWeight.w700)),
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(color: AppColors.surfaceVariant, borderRadius: BorderRadius.circular(6)),
                        child: Text(category.eta, style: AppTextStyles.taglineSmall.copyWith(fontSize: 10, color: AppColors.textSecondary)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text('${category.desc} • ${category.capacity}', style: AppTextStyles.bodySmall.copyWith(fontSize: 11)),
                ],
              ),
            ),
            Text('₹${estimatedFare.toStringAsFixed(0)}', style: AppTextStyles.h3.copyWith(color: isSelected ? AppColors.primaryOrange : AppColors.textPrimary, fontWeight: FontWeight.w800)),
          ],
        ),
      ),
    );
  }
}
