import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../models/ride/place_model.dart';

/// Search Location Card
class SearchLocationTile extends StatelessWidget {
  final PlaceModel place;
  final bool isPickup;
  final VoidCallback onTap;

  const SearchLocationTile({super.key, required this.place, required this.isPickup, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(color: isPickup ? AppColors.primaryOrange.withOpacity(0.15) : AppColors.primaryPurple.withOpacity(0.15), shape: BoxShape.circle),
        child: Icon(isPickup ? Icons.my_location_rounded : Icons.location_on_rounded, color: isPickup ? AppColors.primaryOrange : AppColors.primaryPurple, size: 18),
      ),
      title: Text(place.name, style: AppTextStyles.label.copyWith(fontSize: 14)),
      subtitle: Text(place.address, style: AppTextStyles.bodySmall, maxLines: 1, overflow: TextOverflow.ellipsis),
      onTap: onTap,
    );
  }
}

/// Favorite Place Chip
class FavoritePlaceChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  const FavoritePlaceChip({super.key, required this.label, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.border)),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 16, color: AppColors.textSecondary),
            const SizedBox(width: 6),
            Text(label, style: AppTextStyles.bodySmall.copyWith(color: AppColors.textPrimary, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }
}
