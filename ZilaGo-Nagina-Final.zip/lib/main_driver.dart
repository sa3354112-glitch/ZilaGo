import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../views/driver/dashboard/driver_dashboard_view.dart';
import '../../views/driver/kyc/driver_kyc_view.dart';
import '../../views/driver/earnings/driver_earnings_view.dart';
import '../../views/driver/ride/driver_history_view.dart';
import '../../views/driver/profile/driver_profile_view.dart';
import '../../viewmodels/driver/driver_kyc_viewmodel.dart';
import '../../viewmodels/driver/driver_dashboard_viewmodel.dart';

/// Driver App Entry - Phase 4
void mainDriver() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ZilaGoDriverApp());
}

class ZilaGoDriverApp extends StatelessWidget {
  const ZilaGoDriverApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => DriverKycViewModel()),
        ChangeNotifierProvider(create: (_) => DriverDashboardViewModel()),
      ],
      child: MaterialApp(
        title: 'ZilaGo Driver',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.darkTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.dark,
        initialRoute: '/driver-dashboard',
        routes: {
          '/driver-dashboard': (_) => const DriverDashboardView(driverId: 'driver_123'),
          '/driver-kyc': (_) => const DriverKycView(driverId: 'driver_123'),
          '/driver-earnings': (_) => const DriverEarningsView(driverId: 'driver_123'),
          '/driver-ride-history': (_) => const DriverRideHistoryView(driverId: 'driver_123'),
          '/driver-profile': (_) => const DriverProfileView(driverId: 'driver_123'),
        },
      ),
    );
  }
}
