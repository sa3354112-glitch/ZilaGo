
ZilaGo - Final Unified Project Structure
========================================
lib/
├── main.dart [UNIFIED ENTRY - Role-based routing]
├── main_final.dart [Backup unified]
├── main_driver.dart [Driver standalone]
├── main_admin.dart [Admin web]
├── core/
│   ├── constants/map_constants.dart (Nagina 29.4457,78.4425 + RideCategoryType Bike/Auto/MiniMetro/Cab/XL)
│   ├── routes/unified_routes.dart (All routes + onGenerateRoute with wallet/chat/rating/referral)
│   └── theme/app_colors.dart, app_text_styles.dart, app_theme.dart (Premium Orange/Purple/Black)
├── models/
│   ├── ride/place_model.dart, ride_category_model.dart, ride_model.dart
│   ├── driver/kyc_model.dart, vehicle_model.dart, driver_ride_model.dart (Earnings, Rating)
│   ├── admin/admin_models.dart (DashboardStats, Coupon, WalletTx, FareRule, SupportTicket, City, Referral)
│   ├── wallet/wallet_model.dart
│   └── chat/chat_model.dart
├── services/
│   ├── maps/location_service.dart (Geolocator permission + getCurrentPlace)
│   ├── maps/map_service.dart (Polyline + Fare estimation + Markers)
│   ├── driver/driver_location_service.dart (Realtime DB driver_locations + ride_locations + startTracking Stream)
│   ├── driver/driver_ride_service.dart (streamRideRequests transactional acceptRide)
│   ├── driver/kyc_service.dart (Storage upload + Firestore)
│   ├── driver/vehicle_service.dart (CRUD + setActive)
│   ├── driver/earnings_service.dart (Transactional aggregation)
│   ├── admin/admin_services.dart (Dashboard count(), KYC approve/reject, ban/suspend, RideMonitoring)
│   ├── admin/admin_extended_services.dart (Coupon validate, Wallet credit/debit batch, FareRules peakHours, FCM queue, Support, City)
│   ├── wallet/wallet_service.dart (streamWallet, streamTransactions, addMoney batch)
│   ├── chat/chat_service.dart (streamMessages, sendMessage)
│   ├── payments/rating_service.dart (submitRating + avg calc), referral_service.dart, payment_service.dart (Razorpay ready), notification_service.dart (FCM token init)
├── viewmodels/
│   ├── home/customer_home_viewmodel.dart (MapController, markers, polylines, distance calc, fare, bookRide, cancel, favorites)
│   ├── driver/driver_dashboard_viewmodel.dart (toggleOnline startTracking, streamRequests, acceptRide, streamEarnings)
│   ├── driver/driver_kyc_viewmodel.dart
│   └── admin/admin_viewmodels.dart (Auth, Dashboard, Kyc)
├── views/
│   ├── splash/splash_view.dart (Premium animated logo 3s)
│   ├── onboarding/onboarding_view.dart (3 screens)
│   ├── auth/customer_login_view.dart, driver_login_view.dart, otp_view.dart, email_login_view.dart, profile_setup_view.dart
│   ├── role_selector_view.dart (Customer/Driver/Admin cards)
│   ├── home/customer/customer_home_view.dart (GoogleMap + DraggableScrollableSheet 5 states), customer_search_view.dart, customer_tracking_view.dart
│   ├── home/history/ride_history_view.dart, favorite_places_view.dart
│   ├── driver/dashboard/driver_dashboard_view.dart (Online toggle + StreamBuilder currentRide else requests), kyc/driver_kyc_view.dart, earnings/driver_earnings_view.dart, ride/driver_history_view.dart, profile/driver_profile_view.dart
│   ├── admin/auth/admin_login_view.dart, dashboard/admin_dashboard_view.dart (Sidebar + Live Map RTDB + Customers/Drivers stream + KYC queue + Live Rides + Earnings + Coupons + Support)
│   ├── wallet/wallet_view.dart (Balance gradient + Tx list)
│   ├── chat/chat_view.dart (Stream messages + send)
│   ├── ratings/rating_view.dart (5 star + review submitRating)
│   ├── referral/referral_view.dart (Code generation)
│   └── settings/settings_view.dart (Logout)
├── widgets/home/ride_category_card.dart, search_widgets.dart, driver_widgets.dart (Searching animation pulsing rings)
└── widgets/admin/admin_stat_card.dart

firebase/
├── firestore.rules (Admin-only, users own, rides user/driver/admin, wallets admin, coupons public read admin write)
├── storage.rules (KYC driver+admin, profile public, vehicles public)
├── realtime_db_rules.json (driver_locations auth, ride_locations auth)
├── firestore.indexes.json (ride_requests status+requestedAt, driverId+requestedAt, wallet_transactions userId+createdAt)
└── firebase.json

functions/
├── index.js (onRideRequested notify nearby drivers FCM multicast, onRideAccepted notify customer, onRideCompleted commission + earnings transactional + referral reward + incentive 5 rides bonus + cleanup, processFcmQueue, preventBannedRide)
└── package.json

pubspec.yaml - All deps: firebase_core, auth, firestore, database, storage, messaging, google_sign_in, google_maps_flutter, geolocator, geocoding, polyline, image_picker, url_launcher, intl, provider, google_fonts, lottie, shimmer
