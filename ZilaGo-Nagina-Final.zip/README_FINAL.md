
# ZilaGo - Complete App Ready 🚖

## Single App, 3 Roles - Customer + Driver + Admin

### Run Commands:
```bash
# 1. Firebase Setup (One Time)
flutterfire configure --project=zilago-nagina

# 2. Get Dependencies
flutter pub get

# 3. Run Complete App (All Roles)
flutter run -t lib/main.dart

# Or Run Specific:
flutter run -t lib/main_final.dart        # Unified with auto role detection
flutter run -t lib/main_driver.dart       # Driver Only
flutter run -t lib/main_admin.dart -d chrome  # Admin Panel Web
```

### Architecture:
- lib/main.dart -> Unified Entry (Customer + Driver + Admin auto-routing)
- Firebase Auth -> Checks admins collection first, then drivers, then customers
- If KYC not approved -> Redirects to KYC
- Role Selector at /role-selector for manual selection

### Features Ready:
- Customer: Maps, Search, Ride Categories, Fare, Book, Tracking, History
- Driver: Online/Offline, Receive Requests, Accept/Reject, Live Location Firebase RTDB, Earnings
- Admin: Dashboard, Live Map, KYC Approval, Ride Monitoring, Coupons, Wallet, Support

### Firebase Deploy:
```bash
firebase deploy --only firestore:rules,storage,database,functions
```

### Google Maps API Key:
Add in:
- android/app/src/main/AndroidManifest.xml
- ios/Runner/AppDelegate.swift
- lib/services/maps/map_service.dart -> googleApiKey

### Cities Supported:
Nagina (Default), Bijnor, Dhampur - Add more via Admin Panel -> Cities

Made for Nagina, UP 246762 - Saqib Ansari
