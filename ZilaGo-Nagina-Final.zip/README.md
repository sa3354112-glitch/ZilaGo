# ZilaGo - Apni Zila, Apni Sawari
**Local ride-booking platform for Nagina, Bijnor, UP**

## Phase 1 - Completed
- ✅ Project structure (Clean Architecture + MVVM)
- ✅ Premium Dark Theme (Orange #FF6B00 + Purple #5B21B6 + Black #0A0A0A)
- ✅ Material 3
- ✅ Firebase Ready Structure
- ✅ Splash Screen with Animation (Logo scale + Text slide + 3s auto navigate)
- ✅ Empty Login Screen (AppBar + Coming Soon)

## Folder Structure
```
lib/
 ├── screens/
 │   ├── splash/splash_screen.dart
 │   └── auth/login_screen.dart
 ├── widgets/animated_logo.dart
 ├── models/user_model.dart
 ├── controllers/splash_controller.dart
 ├── services/firebase_service.dart
 ├── utils/constants.dart, app_routes.dart, responsive.dart
 ├── theme/app_colors.dart, app_text_styles.dart, app_theme.dart
 └── main.dart
```

## Run
```bash
flutter pub get
flutter run
```

## Next - Phase 2
- Firebase initialization
- Login UI + OTP
- Home + Map integration
- Ride booking flow

Made for Nagina ❤️
