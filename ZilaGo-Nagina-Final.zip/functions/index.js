/**
 * ZilaGo Cloud Functions - Ride Lifecycle, Earnings, Notifications, Incentives
 * Production-ready Firebase Functions v2
 */

const {onDocumentCreated, onDocumentUpdated} = require("firebase-functions/v2/firestore");
const {onValueCreated} = require("firebase-functions/v2/database");
const admin = require("firebase-admin");
admin.initializeApp();

const db = admin.firestore();
const rtdb = admin.database();
const messaging = admin.messaging();

// 1. Ride Created - Notify nearby drivers in Nagina
exports.onRideRequested = onDocumentCreated("ride_requests/{rideId}", async (event) => {
  const ride = event.data.data();
  const rideId = event.params.rideId;

  // Find nearby online drivers matching vehicle type
  const driversSnap = await db.collection("drivers")
    .where("vehicleType", "==", ride.category)
    .where("isOnline", "==", true)
    .where("isBanned", "!=", true)
    .where("cityId", "==", ride.pickup.cityId || "nagina")
    .limit(20)
    .get();

  const tokens = [];
  for (const doc of driversSnap.docs) {
    const driver = doc.data();
    if (driver.fcmToken) tokens.push(driver.fcmToken);
    // Create driver-specific notification doc
    await db.collection("driver_notifications").doc(`${rideId}_${doc.id}`).set({
      rideId, driverId: doc.id, status: "pending", createdAt: admin.firestore.FieldValue.serverTimestamp()
    });
  }

  if (tokens.length > 0) {
    await messaging.sendEachForMulticast({
      tokens, notification: {title: `New ${ride.category} Ride`, body: `${ride.pickup.name} → ${ride.destination.name} • ₹${ride.fare}`},
      data: {rideId, type: "new_ride_request", fare: String(ride.fare)}
    });
  }

  // Update admin stats
  await db.collection("admin_stats").doc("realtime").set({activeRides: admin.firestore.FieldValue.increment(1), todayRides: admin.firestore.FieldValue.increment(1)}, {merge: true});
});

// 2. Ride Accepted - Notify customer, remove other driver notifications
exports.onRideAccepted = onDocumentUpdated("ride_requests/{rideId}", async (event) => {
  const before = event.data.before.data();
  const after = event.data.after.data();
  if (before.status === "accepted" || after.status !== "accepted") return;

  const rideId = event.params.rideId;

  // Notify customer
  const customerDoc = await db.collection("users").doc(after.userId).get();
  const customerToken = customerDoc.data()?.fcmToken;
  if (customerToken) {
    await messaging.send({token: customerToken, notification: {title: "Driver Accepted!", body: `${after.driverName} is coming in ${after.vehicleNumber} • ${after.category}`}, data: {rideId, type: "ride_accepted"}});
  }

  // Delete other driver notification docs
  const notifSnap = await db.collection("driver_notifications").where("rideId", "==", rideId).get();
  const batch = db.batch();
  notifSnap.docs.forEach(d => { if (d.data().driverId !== after.driverId) batch.delete(d.ref); });
  await batch.commit();
});

// 3. Ride Completed - Calculate commission, earnings, incentives, referral
exports.onRideCompleted = onDocumentUpdated("ride_requests/{rideId}", async (event) => {
  const before = event.data.before.data();
  const after = event.data.after.data();
  if (after.status !== "completed" || before.status === "completed") return;

  const rideId = event.params.rideId;
  const driverId = after.driverId;
  const userId = after.userId;
  const fare = after.fare;

  // Get city commission
  const cityDoc = await db.collection("cities").doc(after.cityId || "nagina").get();
  const commissionPercent = cityDoc.data()?.commissionPercent || 10;

  const commission = fare * (commissionPercent / 100);
  const driverEarning = fare - commission;

  // Update driver earnings
  const earningRef = db.collection("driver_earnings").doc(driverId);
  const today = new Date(); today.setHours(0,0,0,0);
  await db.runTransaction(async (tx) => {
    const earnSnap = await tx.get(earningRef);
    const data = earnSnap.exists ? earnSnap.data() : {todayEarnings:0, weeklyEarnings:0, monthlyEarnings:0, totalEarnings:0, todayRides:0, totalRides:0, balance:0};
    const isToday = data.lastUpdated?.toDate()?.toDateString() === new Date().toDateString();
    tx.set(earningRef, {
      driverId, todayEarnings: isToday ? data.todayEarnings + driverEarning : driverEarning, weeklyEarnings: (data.weeklyEarnings||0)+driverEarning, monthlyEarnings: (data.monthlyEarnings||0)+driverEarning, totalEarnings: (data.totalEarnings||0)+driverEarning, todayRides: isToday ? (data.todayRides||0)+1 : 1, totalRides: (data.totalRides||0)+1, balance: (data.balance||0)+driverEarning, lastUpdated: admin.firestore.FieldValue.serverTimestamp()
    }, {merge:true});
  });

  // Add to history
  await earningRef.collection("history").doc(rideId).set({rideId, fare, driverEarning, commission, pickup: after.pickup.name, destination: after.destination.name, distance: after.distanceKm, completedAt: admin.firestore.FieldValue.serverTimestamp(), userName: after.userName});

  // Update admin stats - earnings
  await db.collection("admin_stats").doc("realtime").set({todayEarnings: admin.firestore.FieldValue.increment(fare), commissionEarned: admin.firestore.FieldValue.increment(commission), totalEarnings: admin.firestore.FieldValue.increment(fare)}, {merge:true});

  // Referral reward - if user first ride
  const userRides = await db.collection("ride_requests").where("userId", "==", userId).where("status", "==", "completed").count().get();
  if (userRides.data().count === 1) {
    const referralSnap = await db.collection("referrals").where("referredId", "==", userId).where("status", "==", "pending").limit(1).get();
    if (!referralSnap.empty) {
      const referral = referralSnap.docs[0];
      const refData = referral.data();
      // Reward both
      await db.collection("wallets").doc(refData.referrerId).set({balance: admin.firestore.FieldValue.increment(refData.referrerReward || 50)}, {merge:true});
      await db.collection("wallets").doc(userId).set({balance: admin.firestore.FieldValue.increment(refData.referredReward || 30)}, {merge:true});
      await referral.ref.update({status: "completed", completedAt: admin.firestore.FieldValue.serverTimestamp()});
    }
  }

  // Driver incentive - 5 rides per day bonus
  const driverEarningDoc = await earningRef.get();
  if (driverEarningDoc.data()?.todayRides >= 5) {
    const incentiveExists = await db.collection("driver_incentives").where("driverId", "==", driverId).where("date", "==", today.toISOString().split('T')[0]).get();
    if (incentiveExists.empty) {
      await db.collection("driver_incentives").add({driverId, type: "daily_5_rides", amount: 100, date: today.toISOString().split('T')[0], createdAt: admin.firestore.FieldValue.serverTimestamp()});
      await db.collection("wallets").doc(driverId).set({balance: admin.firestore.FieldValue.increment(100)}, {merge:true});
    }
  }

  // Cleanup realtime location
  await rtdb.ref(`ride_locations/${rideId}`).remove();
});

// 4. FCM Queue Processor - Sends from fcm_queue collection
exports.processFcmQueue = onDocumentCreated("fcm_queue/{queueId}", async (event) => {
  const data = event.data.data();
  try {
    await messaging.send({token: data.token, notification: {title: data.title, body: data.body}, data: data.data || {}});
    await event.data.ref.update({status: "sent", sentAt: admin.firestore.FieldValue.serverTimestamp()});
  } catch (e) {
    await event.data.ref.update({status: "failed", error: e.message});
  }
});

// 5. Ban check - Prevent banned users from creating rides
exports.preventBannedRide = onDocumentCreated("ride_requests/{rideId}", async (event) => {
  const ride = event.data.data();
  const userDoc = await db.collection("users").doc(ride.userId).get();
  if (userDoc.data()?.isBanned) {
    await event.data.ref.delete();
  }
});
