import 'package:flutter/material.dart';

enum RideCategoryType { bike, auto, car, eRickshaw }

class FavoritePlaceModel {
  final String id;
  final String name;
  final String address;
  final double lat;
  final double lng;
  final String placeType;
  FavoritePlaceModel({required this.id, required this.name, required this.address, required this.lat, required this.lng, required this.placeType});
}

class DriverModel {
  final String name;
  final RideCategoryType category;
  DriverModel(this.name, this.category);
  factory DriverModel.mock(int i, RideCategoryType type) {
    return DriverModel("Driver \${i+1}", type);
  }
}

class RideCategoryModel {
  final RideCategoryType type;
  final String title;
  final String price;
  RideCategoryModel(this.type, this.title, this.price);
  factory RideCategoryModel.fromType(RideCategoryType type) {
    switch(type) {
      case RideCategoryType.bike: return RideCategoryModel(type, "Bike", "₹30");
      case RideCategoryType.auto: return RideCategoryModel(type, "Auto", "₹50");
      case RideCategoryType.car: return RideCategoryModel(type, "Car", "₹90");
      case RideCategoryType.eRickshaw: return RideCategoryModel(type, "E-Rickshaw", "₹40");
    }
  }
}

class RideModel {
  final String id;
  final FavoritePlaceModel from;
  final FavoritePlaceModel to;
  final RideCategoryModel category;
  final DriverModel driver;
  RideModel({required this.id, required this.from, required this.to, required this.category, required this.driver});
}

class RideRepository {
  List<FavoritePlaceModel> getFavorites() {
    return [
      FavoritePlaceModel(id: 'home', name: 'Home', address: 'Puraini, Nagina', lat: 29.450, lng: 78.445, placeType: 'home'),
      FavoritePlaceModel(id: 'work', name: 'Work', address: 'Bus Stand, Nagina', lat: 29.444, lng: 78.440, placeType: 'work'),
    ];
  }

  List<RideModel> getMockRides() {
    final favs = getFavorites();
    return List.generate(4, (i) {
      final type = RideCategoryType.values[i % RideCategoryType.values.length];
      return RideModel(
        id: 'ride_\$i',
        from: favs[0],
        to: favs[1],
        category: RideCategoryModel.fromType(type),
        driver: DriverModel.mock(i, type),
      );
    });
  }
}

void main() { runApp(ZilaGoApp()); }

class ZilaGoApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ZilaGo Nagina',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.deepOrange, useMaterial3: true),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  final repo = RideRepository();
  @override
  Widget build(BuildContext context) {
    final places = repo.getFavorites();
    final rides = repo.getMockRides();
    return Scaffold(
      appBar: AppBar(title: Text("ZilaGo - Nagina"), centerTitle: true, backgroundColor: Colors.deepOrange, foregroundColor: Colors.white),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.orange.shade50, borderRadius: BorderRadius.circular(16)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text("Namaste Saqib! 🙏", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text("Nagina me apni ride book karo - Puraini se Bus Stand tak", style: TextStyle(color: Colors.grey.shade700)),
            ]),
          ),
          SizedBox(height: 20),
          Text("Favorite Places", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SizedBox(height: 8),
          ...places.map((p) => Card(child: ListTile(leading: Icon(p.placeType=='home'?Icons.home:Icons.work), title: Text(p.name), subtitle: Text(p.address), trailing: Text("\${p.lat}, \${p.lng}")))),
          SizedBox(height: 20),
          Text("Available Rides (Mock)", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SizedBox(height: 8),
          ...rides.map((r) => Card(
            child: ListTile(
              leading: CircleAvatar(child: Text(r.category.title[0])),
              title: Text("\${r.category.title} - \${r.category.price}"),
              subtitle: Text("\${r.from.name} -> \${r.to.name} | Driver: \${r.driver.name} (\${r.driver.category.name})"),
              trailing: Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Ride \${r.id} booked!"))),
            ),
          )),
          SizedBox(height: 30),
          ElevatedButton.icon(onPressed: (){}, icon: Icon(Icons.build), label: Text("APK Successfully Built!"), style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white, minimumSize: Size(double.infinity, 50))),
          SizedBox(height: 10),
          Text("Ye fixed version hai. Iske baad aap dheere-dheere Firebase, Maps add kar sakte ho.", textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
        ],
      ),
    );
  }
}